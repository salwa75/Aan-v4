const fs = require('fs');
const path = require('path');

// Lokasi file database
const dbPath = path.resolve(__dirname, './data.json');

// Struktur database awal
let db = {
    users: {},
    groups: {},
    settings: {
        anticall: false,
        autobio: false,
        autoread: false,
        autopromosi: false,
        autotyping: false,
        readsw: false,
        stockmarket: {} // Untuk fitur saham
    }
};

// Muat database jika sudah ada
if (fs.existsSync(dbPath)) {
    try {
        db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    } catch (error) {
        console.error('Gagal memuat database:', error);
    }
}

// Fungsi untuk menyimpan database ke file
const saveDB = () => {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
};

module.exports = {
    db,
    saveDB
};