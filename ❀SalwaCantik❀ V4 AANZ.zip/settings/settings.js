//sett Bot
global.nomorbot = '6289502445574'
global.namabot = '❀SalwaCantik❀'
global.namaowner = '❀SalwaCantik❀'
global.urlfoto = 'https://files.catbox.moe/et30hu.jpg'
global.link = false //' '
global.linkgrup = 'https://chat.whatsapp.com/KFKT5sKw26UBlGfaUyeqbY'
//Cpanel V1
global.domain = ''
global.apikey = ''
global.capikey = ''
//Cpanel V2
global.domain2 = ''
global.apikey2 = ''
global.capikey2 = ''
//Cpanel V3
global.domain3 = ''
global.apikey3 = ''
global.capikey3 = ''
global.eggs = '15'
global.locc = '1'
//Settings Payment
global.dana = '089502445574'
global.gopay = '089502445574'
global.ovo = '089502445574'
global.qris = 'https://files.catbox.moe/fkmk0i.jpg'

global.delayJpm = 2000
//Sett Buy Vps
global.digitalocean_apikey = 'dop_v1_93920dee0c05da7bb3cf03204e42ffc6f45c5fff3e4aee1be21974267164d074'
global.ram1 = '1'
global.ram2 = '2'
global.ram4 = '3'
global.ram8 = '50'
//Setting Gif
module.exports = {
    videoUrls: [
        'https://files.catbox.moe/rvrqwv.jpg',
        'https://files.catbox.moe/rvrqwv.jpg',
        'https://files.catbox.moe/rvrqwv.jpg',
    ],

    produkList: [
        {
            nama: 'Reseller Panel',
            harga: 10000, 
            linkGrup: 'https://chat.whatsapp.com/KFKT5sKw26UBlGfaUyeqbY'
        },
        {
            nama: 'Owner Panel',
            harga: 20000, 
            linkGrup: 'https://chat.whatsapp.com/KFKT5sKw26UBlGfaUyeqbY'
        },
        {
            nama: 'VIP Access',
            harga: 50000, 
            linkGrup: 'https://chat.whatsapp.com/KFKT5sKw26UBlGfaUyeqbY'
        }
    ],
// Setting Order Kuota Di Sini Yaw
    idmerchant: 'OK2060177', 
    qrisorkut: '00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214009121195553790303UMI51440014ID.CO.QRIS.WWW0215ID20243485064430303UMI5204541153033605802ID5923ANGGARA STORE OK20601776013JAKARTA BARAT61051111062070703A01630444F6', 
    apikeyorkut: '430694417318329852060177OKCT827C2279DDFCD8D6DD9E2D6C1BDC7D44',
    pwOrkut: 'angga7680',
    pinOrkut: '2006'
}
//Sett Domain Yaw
global.subdomain = {
"cupencrew.my.id": {
"zone": "505292d6fa0c31a0f3c179e31da8e3f5", 
"apitoken": "yKkh3VluAjlvyy8i3VM_jw-Pjsq_liBv4QVJZrm0"
}, 
"cupentamvan.biz.id": {
"zone": "cde563dd21c04e2770bb66993dd667a3", 
"apitoken": "YPhb9lXkwFu0PrHgiT1XwQSyN5Rf3eAYiMdt0zJ9"
}, 
"cupenpendiem.shop": {
"zone": "a70c572f7c8f8bc0ad5ac2552e42e516", 
"apitoken": "VEtKD6sBAvgwQd1pYBV957Rno1feXoxqXPo1biij"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}, 
"reseller-panel.me": {
"zone": "b1efab0f1d81a0137eb5d62e00d6e3f8",
"apitoken": "W3b66ootKk1pERNSB6DbyW383OXRCoakw3PQExyS"
},
"aditt-store.my.id": {
"zone": "7e91d270e6852dbcf3843d55f05f167f", 
"apitoken": "5mrHAyGUu4PcabM5d0S0aWOr3ScNxf27jL09ki0f"
}, 
"fayzaafx.my.id": {
"zone": "2688ec16cf017d8b76b056992ef77b15", 
"apitoken": "ijjFxobV49FkPMFw1ed-wrjMyRWMF31_0hg8Q0ch"
}, 
"fayzaafx.xyz": {
"zone": "5f4a582dd80c518fb2c7a425256fb491", 
"apitoken": "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby"
}, 
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
},
"fayzaafx.web.id": {
"zone": "422abe2ae8a9225fe824441da4b84645",
"apitoken": "QaeiWSZkabCabpdutbHJ09hAyGtjUpPbCywRiWz2"
},
"zcake.us.kg": {
"zone": "63729ecb4fb36abf6a546aa8d0f2090d", 
"apitoken": "5zL3j880znmlh3Avpm8lIkrfhdU-khI6njLmJsKH"
},
"market-panel.site": {
"zone": "d06bf5450ae51612a400bab1c4450283",
"apitoken": "kmb6AkpJ6XvHMzw2m0KbYKZOycIURNYMPA7Wm0BE",
},
"admin-panel.tech": {
"zone": "305d4757160a88486d3780785c7c9887",
"apitoken": "UH-aDtxu5Mm9oU8khMd5ZVg22f7nhnSkCORBn8zP",
},
"kang-panel.tech": {
"zone": "28baf36eb9ced4be271bdb6ea3320f41",
"apitoken": "MBiKuyoS0e0zJc8LKUjSXyLmgAf1IV9u86FJmVny",
},
"web-cabul.me": {
"zone": "4b24636040f0f2d799a8a1aaea568e57",
"apitoken": "OvRX-DghNjcPF9rlKElGCLIsPvv3Nd3khuDAUZ3q",
},

"king-hosting.live": {
"zone": "2e6eb183148e0ef9add390af271a8bb2",
"apitoken": "kcnnE1sESybx-P_nLkkiKtfZFqGhRmwFg9wL0cf6",
},
"tokopanel.software": {
"zone": "cc9638d4c289130ba070484625e6aefa",
"apitoken": "bcAP5z3gHvmQTlQ59qNB9BWmf0JiGt0C99FU6SXs",
},
"pannel-private.me": {
"zone": "71ad41d3c25085bd7b8a1135632c7c63",
"apitoken": "HfGKPUu1KrOVc3q51nkoJYZFQvIpA-AFOP-t6SNZ",
},
"hitam.systems": {
"zone": "cfaba3ef0065acc82facc17f1b79d50b",
"apitoken": "4o3tZAc5jOzA00joKpLYhG_616qCJxNLGlhawMEY",
},
"panel-run-bot.engineer": {
"zone": "678298eaac2e2a0dea25f693310ec6e0",
"apitoken": "8UmNiZZqEIAqWbM7XlcZofyvhc70NMs2_gXmmkug",
},
"uchiha.tech": {
"zone": "1b09e81ec29d760ff33e476a084de6ed",
"apitoken": "nzLwv-2uzMt3Ihsd5MVV2aLJ9EoovxrVK7Y4b2To",
},
"buyer-vps.site": {
"zone": "354e1c784bed5a8d93f458ec1ff86f35",
"apitoken": "rzOLIO1c-Me1X0owStLFUZ0ggfs_cxHDab2A7krF",
},
"arzanoffc.online": {
"zone": "43ca801f5c6a73a77da5f0243f4f8c1d",
"apitoken": "RZQft_gJGOJDskx6L6SxREJCvOKw0hclLjHUCNLS",
},
"hexaneuro.biz.id": {
"zone": "16273869fda58585fc435e4582a5ff56",
"apitoken": "y4wV0um-bvrVTvFVPrNrGEi590bPowvosRyNiGMn"
 },   
"mypanel.tech": {
"zone": "9c5460deca7c84273b46f2f047783636",
"apitoken": "0IBfmlUlCkYqoFPWYaqCmqI3_vWxkrFNbxrQjzX2"
}, 
"kedai-panel.me": {
"zone": "3ab91ea96368234719c9de7d260742e2",
"apitoken": "O22A19W7trZZ52bAXtF77aUVdGDdAk8PjQqwM7qv"
}, 
"control-pannel.site": {
"zone": "20c517d7dcc25d9cf516f5c4cf2d21ba",
"apitoken": "mAA84Qs4nJvLTaup0HTGrpVbgaSk-4vfUrcdHgCH"
}, 
"mypanelstore.xyz": {
"zone": "72f7362d7686d9158a8e389851fc379c", 
"apitoken": "V2y-I2o1s5E1tdCPpUSnT4FokV6WuxEUC2FqqVIX"
}, 
"digitalserver.biz.id": {
"zone": "24dec03ff55093ab3a2d1dc926c372df", 
"apitoken": "EnmTeuJUzFF_xmnDnTAlwdxajP5ogeJKH9wy-SiR"
}, 
"serverpanell.biz.id": {
"zone": "aac5555d4f60fcf48c9e901b938fffc0", 
"apitoken": "qd8OolI2_GIu3HLsTZvdk242ggDdD3_IGXMMSQ7P"
}, 
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}
}
if (!global.menuVideoIndex) {
    global.menuVideoIndex = 0;
    }
global.kiw = '`'

global.stockMarket = {
    AAPL: { name: "Apple", price: 150000, description: "Saham teknologi dari Apple Inc.", change: 0 },
    TSLA: { name: "Tesla", price: 200000, description: "Saham otomotif dari Tesla Inc.", change: 0 },
    AMZN: { name: "Amazon", price: 100000, description: "Saham e-commerce dari Amazon Inc.", change: 0 },
    AANZ: { name:"❀SalwaCantik❀", price: 1000000, description: "Saham Hosting Terbesar Se Asia Tenggara.", change: 0 },
};
global.dailyLottery = {
    tickets: [], // Daftar tiket yang dibeli
    prizes: [
        { type: 'saldo', amount: 5000 }, // Hadiah saldo
        { type: 'saldo', amount: 10000 },
        { type: 'item', name: 'Voucher Diskon 50%' }, // Hadiah item
        { type: 'kosong', message: 'Coba lagi besok!' } // Hadiah kosong
    ],
    ticketPrice: 2000, // Harga per tiket
    drawTime: '21:00' // Waktu undian
};
global.duels = [];
global.spinNames = [];
global.db.pushContacts = {};
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})